'use client'
// Social scheduler — /dashboard/org/social
// Two-week calendar of Instagram/Facebook posts + an approvals board. Anyone on
// staff can draft; only a director/admin can approve (enforced again server-side
// in /api/social/posts/[id]). Approved posts publish automatically via the
// publish cron. Layout follows the approved mockup (Sintra-style tiles, two-week
// calendar, slide-over); colors follow the dashboard's light slate/teal standard.
import { useEffect, useMemo, useRef, useState, Suspense, type ReactNode } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import toast, { Toaster } from 'react-hot-toast'
import { upload as blobUpload } from '@vercel/blob/client'
import { normalizeReel } from '@/lib/normalizeReel'
import InsightsView from './InsightsView'
import ChirpPanel, { type ChirpMsg } from './ChirpPanel'
import ReelBuilder from './ReelBuilder'
import MusicDrawer from './MusicDrawer'
import { rememberPhotoVersions } from '@/lib/postImgVersion'
import LooksLibrary from './LooksLibrary'
import PlayersTray, { planList, type ClearedData, type ReelDraft } from './PlayersTray'
import { feedJpeg, storyJpeg, uploadJpeg, postPngUrl } from './playerMedia'
import ReelMaker, { type ReelSetup } from '@/components/ReelMaker'
import { POST_STYLES, styleLabel, FAVORITE_STYLES, SEASON_LOOKS, seasonOf } from '@/lib/socialPosts'
import { lookFor, daysUntil, playerCaption, rollCallCaption, squadCaption, squadHandles, collabFor, firstOf, baseLook, type ClearedPlayer, type PostPlayerLink } from '@/lib/playerPostText'
import ChirpAvatar from '@/components/ChirpAvatar'
import { buildIdeas, localDayKey, LEAGUES, AUDIENCE_LABEL, PHASE_LABEL, leagueName, type Idea, type IdeaEvent, type DayIdeas } from '@/lib/socialIdeas'
import { ChevronLeft, ChevronRight, Plus, X, Link2, ThumbsUp, Instagram, Facebook, Image as ImageIcon, Heart, MessageCircle, Send, Check, AlertTriangle, Trash2, RotateCcw, Zap, ListPlus, Clock, ExternalLink, Download, Play, Film, Sparkles, Lightbulb, Layers, ArrowLeft, ArrowRight, Music, Pause, Search } from 'lucide-react'

type Status = 'draft' | 'scheduled' | 'publishing' | 'published' | 'failed' | 'canceled'
interface Account { id: string; platform: 'instagram' | 'facebook'; label: string; status: string; lastError: string; tokenExpiresAt: string | null }
interface Post {
  id: string; socialAccountId: string; caption: string; mediaUrls: string; scheduledFor: string; status: Status
  approvedByUserId: string; lastError: string; publishedAt: string | null; firstComment: string; groupId: string; permalink: string; importedAt: string | null; mediaType: 'image' | 'video' | 'carousel'; placement: 'feed' | 'story'; thumbnailUrl: string
  socialAccount?: { id: string; platform: string; label: string; status: string }
  audio?: Song
  /** Instagram Collab invite on this post (lib/socialPlayers). */
  collab?: { usernames: string[]; tags?: string[]; dropped?: string; droppedTags?: string }
}
/** Compose opened from the "Cleared to post" tray: everything filled in. */
interface ComposeSeed {
  key: string; caption: string; slides: Media[]
  /** The 9:16 Story version of the feed graphic (the Story copy uses it instead of the 4:5). */
  storyUrl?: string
  placements: Placement[]; storyTiming: StoryTiming; collab: string[]; player: PostPlayerLink
  /** Squad Reels: handles the 3 Collab slots couldn't take, tagged in the Reel instead. */
  tags?: string[]
  note: string; dayKey: string; countdown: boolean
  /** Reel made without music: open Instagram's trending songs on the post. */
  pickSong?: boolean
}
// An Instagram song on a Reel (Meta Audio API; src/lib/socialAudio.ts).
type Song = { audioId: string; title: string; artist: string; cover: string; durationMs: number; audioVolume: number; videoVolume: number; dropped?: string }
const sameSong = (a?: Song | null, b?: Song | null) => (a?.audioId || '') === (b?.audioId || '') && (a?.audioVolume ?? 100) === (b?.audioVolume ?? 100) && (a?.videoVolume ?? 100) === (b?.videoVolume ?? 100)
const mmss = (ms: number) => { const t = Math.round(ms / 1000); return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}` }

const STATUS_LABEL: Record<string, string> = { draft: 'Needs approval', scheduled: 'Scheduled', publishing: 'Publishing…', published: 'Published', failed: 'Failed', canceled: 'Canceled' }
const STATUS_TEXT: Record<string, string> = { draft: 'text-amber-700', scheduled: 'text-emerald-700', publishing: 'text-emerald-700', published: 'text-slate-500', failed: 'text-rose-600', canceled: 'text-slate-400' }
const QUICK_TIMES: [number, number][] = [[9, 0], [11, 0], [12, 30], [18, 30]]
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
interface QueueSlot { dow: number; h: number; m: number }
interface QueueInfo { slots: QueueSlot[]; tzOffsetMin: number; next: string[] }
interface PostMetrics { reach: number; impressions: number; likes: number; comments: number; saves: number; shares: number; interactions: number; fetchedAt: string }
interface Rollup { reach: number; interactions: number; withData: number; posts: number }
interface Insights { latest: Record<string, PostMetrics>; window: { days: number; current: Rollup; previous: Rollup } | null }
type Media = { url: string; mediaType: 'image' | 'video'; thumbnailUrl?: string; durationSec?: number; width?: number; height?: number
  /** Made by our Reel makers with one of our tracks baked in: an Instagram song on top mutes it. */
  builtIn?: boolean }
type Placement = 'feed' | 'story'
interface IdeaSettings { leagues: string[]; show: boolean; dismissed: string[] }
interface IdeaSource { events: IdeaEvent[]; settings: IdeaSettings; site: string }
// Audience colors for idea cards (a left bar + label). Text labels always ride
// along, so color is never the only signal.
const AUD_CLS: Record<string, { bar: string; text: string; chip: string }> = {
  clubs: { bar: 'bg-violet-600', text: 'text-violet-700', chip: 'bg-violet-50 text-violet-700' },
  players: { bar: 'bg-orange-600', text: 'text-orange-700', chip: 'bg-orange-50 text-orange-700' },
  parents: { bar: 'bg-sky-700', text: 'text-sky-800', chip: 'bg-sky-50 text-sky-800' },
  all: { bar: 'bg-slate-500', text: 'text-slate-600', chip: 'bg-slate-100 text-slate-700' },
}
const hhmm = (t: { h: number; m: number }) => { const d = new Date(); d.setHours(t.h, t.m, 0, 0); return fmtTime(d) }
const kindLabel = (p: { mediaType?: string; placement?: string; socialAccount?: { platform: string } }) => p.placement === 'story' ? 'Story' : p.mediaType === 'carousel' ? 'Carousel' : p.mediaType === 'video' ? (p.socialAccount?.platform === 'instagram' ? 'Reel' : 'Video') : ''
const fmtNum = (n: number) => n >= 10000 ? `${(n / 1000).toFixed(n >= 100000 ? 0 : 1)}K` : n.toLocaleString()
const delta = (cur: number, prev: number) => prev > 0 ? `${cur >= prev ? '+' : ''}${Math.round(((cur - prev) / prev) * 100)}%` : ''

const startOfWeek = (d: Date) => { const x = new Date(d); x.setHours(0, 0, 0, 0); const dow = (x.getDay() + 6) % 7; x.setDate(x.getDate() - dow); return x }
const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
const sameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
const fmtTime = (d: Date) => d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
const fmtDate = (d: Date) => d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })
const fmtLong = (d: Date) => d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' }) + ' at ' + fmtTime(d)
const toLocalInput = (d: Date) => { const p = (n: number) => (n < 10 ? '0' : '') + n; return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}` }
const media = (p: { mediaUrls: string }): string[] => { try { const a = JSON.parse(p.mediaUrls || '[]'); return Array.isArray(a) ? a : [] } catch { return [] } }
// Carousel slides are stored as a URL list; a slide's kind comes from its file
// extension (video uploads keep their .mp4/.mov name). Same rule as src/lib/social.ts.
const isVid = (u: string) => /\.(mp4|mov|m4v|webm)(\?|#|$)/i.test(u || '')
const toSlides = (p: Post): Media[] => media(p).map((url, i) => ({ url, mediaType: p.mediaType === 'carousel' ? (isVid(url) ? 'video' : 'image') : p.mediaType === 'video' ? 'video' : 'image', thumbnailUrl: i === 0 ? p.thumbnailUrl || undefined : undefined }))
const slidesBody = (sl: Media[]) => ({ mediaUrls: sl.map(x => x.url), mediaType: sl.length > 1 ? 'carousel' : sl[0]?.mediaType || 'image', thumbnailUrl: sl[0]?.mediaType === 'video' ? sl[0].thumbnailUrl || '' : '' })
const firstLine = (s: string) => (s.split('\n').find(l => l.trim()) || 'Untitled').slice(0, 60)

async function api(url: string, init?: RequestInit) {
  const res = await fetch(url, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) } })
  const d = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(d.error || `Request failed (${res.status})`)
  return d
}

function PlatformBadge({ platform, size = 16 }: { platform: string; size?: number }) {
  const ig = platform === 'instagram'
  return <span className={`inline-grid place-items-center rounded-full border-2 border-white ${ig ? 'bg-pink-600' : 'bg-blue-500'}`} style={{ width: size + 4, height: size + 4 }}>{ig ? <Instagram size={size - 6} className="text-white" /> : <Facebook size={size - 6} className="text-white" />}</span>
}

function Thumb({ post }: { post: Post }) {
  const first = media(post)[0] || ''
  const isVideo = post.mediaType === 'video' || (post.mediaType === 'carousel' && isVid(first))
  const src = isVideo ? (post.thumbnailUrl || '') : first
  const n = post.mediaType === 'carousel' ? media(post).length : 0
  return (
    <div className={`relative flex-none w-11 h-11 rounded-xl overflow-hidden grid place-items-center ${src ? 'bg-slate-200' : isVideo ? 'bg-slate-800 text-white' : 'bg-slate-100 border border-dashed border-slate-300 text-slate-400'}`}>
      {src ? <img src={src} alt="" className="w-full h-full object-cover" /> : isVideo ? <Film size={15} /> : <ImageIcon size={15} />}
      {isVideo && src && !n && <span className="absolute inset-0 grid place-items-center text-white drop-shadow"><Play size={14} fill="currentColor" /></span>}
      {n > 1 && <span className="absolute top-0.5 left-0.5 rounded bg-black/65 text-white text-[9px] font-bold px-1 inline-flex items-center gap-0.5"><Layers size={9} />{n}</span>}
      <span className="absolute -right-1 -bottom-1"><PlatformBadge platform={post.socialAccount?.platform || ''} /></span>
    </div>
  )
}

export default function SocialPage() { return <Suspense fallback={<div className="min-h-screen bg-slate-50 p-10 text-center text-slate-400">Loading…</div>}><SocialInner /></Suspense> }

function SocialInner() {
  const { data: session, status } = useSession()
  const router = useRouter(); const search = useSearchParams()
  const role = (session?.user as any)?.role as string | undefined
  const canApprove = role === 'director' || role === 'admin'

  const [posts, setPosts] = useState<Post[]>([])
  const [accounts, setAccounts] = useState<Account[]>([])
  const [configured, setConfigured] = useState(true)
  const [queue, setQueue] = useState<QueueInfo>({ slots: [], tzOffsetMin: new Date().getTimezoneOffset(), next: [] })
  const [insights, setInsights] = useState<Insights>({ latest: {}, window: null })
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState<'week' | 'queue' | 'insights'>('week')
  const [rangeStart, setRangeStart] = useState(() => startOfWeek(new Date()))
  const [drawer, setDrawer] = useState<{ kind: 'post'; id: string; mode: 'preview' | 'edit' } | { kind: 'new'; when: Date; idea?: Idea; seed?: ComposeSeed } | { kind: 'idea'; idea: Idea } | { kind: 'chirp' } | { kind: 'accounts' } | { kind: 'music' } | null>(null)
  const [ideaSrc, setIdeaSrc] = useState<IdeaSource | null>(null)
  const [fitFor, setFitFor] = useState<string>('')
  const [chirpMsgs, setChirpMsgs] = useState<ChirpMsg[]>([])
  const [cleared, setCleared] = useState<ClearedData | null>(null)
  // Post image URLs carry each player's photo version, so a changed photo shows right away.
  if (cleared?.players) rememberPhotoVersions(cleared.players)
  const [playerBusy, setPlayerBusy] = useState('')
  const [reel, setReel] = useState<{ p: ClearedPlayer; look: string; when: Date; days: number | null; squad?: ClearedPlayer[]; looks?: string[]; setup?: Partial<ReelSetup>; draftId?: string } | null>(null)
  const [reelDrafts, setReelDrafts] = useState<ReelDraft[]>([])
  // Looks library (LooksLibrary): the org's starred looks lead every look menu.
  const [lookFavs, setLookFavs] = useState<string[]>(FAVORITE_STYLES)
  const [looksOpen, setLooksOpen] = useState(false)
  const dragId = useRef<string | null>(null)
  const today = new Date()

  useEffect(() => {
    if (status === 'loading') return
    if (!session) { router.replace('/login'); return }
    load()
  }, [status, session])

  useEffect(() => {
    const c = search.get('connected'); const e = search.get('error')
    if (c) { toast.success(`${c} account${c === '1' ? '' : 's'} connected`); router.replace('/dashboard/org/social') }
    if (e) { toast.error(e); router.replace('/dashboard/org/social') }
  }, [search])

  async function load() {
    try {
      const [p, a, q, ins, ide, cl, rd, lk] = await Promise.all([api('/api/social/posts'), api('/api/social/accounts'), api(`/api/social/queue?tz=${new Date().getTimezoneOffset()}`).catch(() => null), api('/api/social/insights/summary').catch(() => null), api('/api/social/ideas').catch(() => null), api('/api/social/players').catch(() => null), api('/api/social/reel-drafts').catch(() => null), api('/api/social/looks').catch(() => null)])
      setPosts(p.posts || []); setAccounts(a.accounts || []); setConfigured(a.configured !== false)
      if (q) setQueue(q)
      if (ins) setInsights(ins)
      if (ide) setIdeaSrc(ide)
      if (cl) setCleared(cl)
      if (rd) setReelDrafts(rd.drafts || [])
      if (lk && Array.isArray(lk.favorites)) setLookFavs(lk.favorites)
    } catch (e: any) { toast.error(e.message) } finally { setLoading(false) }
  }

  const byId = (id: string) => posts.find(p => p.id === id)
  const needsReview = posts.filter(p => p.status === 'draft').length
  const scheduledCount = posts.filter(p => p.status === 'scheduled').length
  const published28 = posts.filter(p => p.status === 'published' && p.publishedAt && Date.now() - new Date(p.publishedAt).getTime() < 28 * 864e5).length

  // Content ideas for the two weeks on screen. Days that already have a post get
  // none; feed ideas land on the org's queue days at the queue time.
  const ideasByDay = useMemo<Record<string, DayIdeas>>(() => {
    if (!ideaSrc || !ideaSrc.settings.show) return {}
    const slotTime: Record<number, { h: number; m: number }> = {}
    for (const s of [...queue.slots].sort((a, b) => a.h * 60 + a.m - (b.h * 60 + b.m))) if (!slotTime[s.dow]) slotTime[s.dow] = { h: s.h, m: s.m }
    return buildIdeas({
      events: ideaSrc.events, from: localDayKey(rangeStart), to: localDayKey(addDays(rangeStart, 13)), today: localDayKey(new Date()),
      leagues: ideaSrc.settings.leagues, dismissed: new Set(ideaSrc.settings.dismissed), site: ideaSrc.site,
      takenDays: new Set(posts.filter(p => p.status !== 'canceled').map(p => localDayKey(new Date(p.scheduledFor)))),
      feedDows: queue.slots.map(s => s.dow), slotTime,
    })
  }, [ideaSrc, rangeStart, posts, queue.slots])
  async function saveIdeaSettings(patch: Partial<IdeaSettings> & { dismiss?: string }) {
    if (!ideaSrc) return
    const { dismiss, ...rest } = patch
    const next = { ...ideaSrc.settings, ...rest, dismissed: dismiss ? [...ideaSrc.settings.dismissed, dismiss] : ideaSrc.settings.dismissed }
    setIdeaSrc({ ...ideaSrc, settings: next })
    try { await api('/api/social/ideas', { method: 'PUT', body: JSON.stringify(patch) }) } catch (e: any) { toast.error(e.message) }
  }
  function draftFromIdea(idea: Idea) {
    const [y, m, d] = idea.date.split('-').map(Number)
    let when = new Date(y, m - 1, d, idea.time.h, idea.time.m)
    if (when < new Date()) { when = new Date(Date.now() + 60 * 60000); when.setMinutes(Math.ceil(when.getMinutes() / 5) * 5, 0, 0) }
    setDrawer({ kind: 'new', when, idea })
  }

  async function patch(id: string, body: any, okMsg?: string) {
    try { await api(`/api/social/posts/${id}`, { method: 'PATCH', body: JSON.stringify(body) }); if (okMsg) toast.success(okMsg); await load(); return true }
    catch (e: any) { toast.error(e.message); return false }
  }
  async function remove(id: string, msg: string) {
    try { await api(`/api/social/posts/${id}`, { method: 'DELETE' }); toast.success(msg); setDrawer(null); await load() } catch (e: any) { toast.error(e.message) }
  }
  async function approve(p: Post) {
    if (new Date(p.scheduledFor) < new Date()) { toast.error('That time has passed — pick a new date first'); setDrawer({ kind: 'post', id: p.id, mode: 'edit' }); return }
    const when = new Date(p.scheduledFor)
    const siblings = p.groupId ? posts.filter(x => x.groupId === p.groupId && x.id !== p.id && x.status === 'draft').length : 0
    if (await patch(p.id, { action: 'approve' }, `Approved${siblings ? ` (+${siblings} more account${siblings === 1 ? '' : 's'})` : ''} — publishes ${fmtDate(when)} at ${fmtTime(when)}`)) setDrawer(null)
  }
  async function moveTo(id: string, day: Date) {
    const p = byId(id); if (!p) return
    if (p.status === 'published' || p.status === 'publishing') { toast.error('Published posts can’t be moved'); return }
    const old = new Date(p.scheduledFor); const nw = new Date(day); nw.setHours(old.getHours(), old.getMinutes(), 0, 0)
    if (nw < new Date()) { toast.error('That day has already passed'); return }
    await patch(id, { scheduledFor: nw.toISOString() }, `Moved to ${fmtDate(nw)} · keeps ${fmtTime(nw)}`)
  }
  async function publishNow(p: Post) {
    try {
      const d = await api(`/api/social/posts/${p.id}`, { method: 'PATCH', body: JSON.stringify({ action: 'publish-now' }) })
      toast.success(d.warning ? `Published — ${d.warning}` : 'Published — it’s live'); setDrawer(null); await load()
    } catch (e: any) { toast.error(e.message); await load() }
  }
  function newPostOn(day: Date) { const d = new Date(day); d.setHours(11, 0, 0, 0); setDrawer({ kind: 'new', when: d }) }

  // ── cleared players (the "Cleared to post" tray) ──
  const liveAccounts = accounts.filter(a => a.status !== 'disconnected')
  // Days a player post can go out: from today (if there's still time) up to the day
  // before the event starts, at the queue slot for that weekday, else 6:30 PM.
  function playerDays(p: ClearedPlayer): Date[] {
    const out: Date[] = []; const now = new Date()
    const start = new Date(p.event.start + 'T00:00:00')
    for (let d = new Date(now.getFullYear(), now.getMonth(), now.getDate()); d < start && out.length < 90; d = addDays(d, 1)) {
      const slot = queue.slots.filter(s => s.dow === d.getDay()).sort((a, b) => a.h * 60 + a.m - (b.h * 60 + b.m))[0]
      const at = new Date(d); at.setHours(slot ? slot.h : 18, slot ? slot.m : 30, 0, 0)
      if (at.getTime() > now.getTime() + 30 * 60000) out.push(at)
    }
    return out
  }
  const takenKeys = () => new Set(posts.filter(p => p.status !== 'canceled').map(p => localDayKey(new Date(p.scheduledFor))))
  /** The first day before the event with nothing scheduled; else the first day; else an hour from now. */
  function whenFor(p: ClearedPlayer): Date {
    const days = playerDays(p); const taken = takenKeys()
    const at = days.find(d => !taken.has(localDayKey(d))) || days[0]
    if (at) return at
    const d = new Date(Date.now() + 60 * 60000); d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0); return d
  }
  const daysAt = (p: ClearedPlayer, when: Date) => { const n = daysUntil(localDayKey(when), p.event.start); return n != null && n >= 0 ? n : null }
  const storySub = (p: ClearedPlayer) => [p.event.dates, p.event.location].filter(Boolean).join(' · ')
  const lookLabel = (s: string) => styleLabel(s)
  const fileSlug = (p: ClearedPlayer, s: string) => `${firstOf(p.playerName)}-${s}`.toLowerCase().replace(/[^a-z0-9-]+/g, '-')
  const seedFor = (p: ClearedPlayer, look: string, when: Date, days: number | null, kind: PostPlayerLink['kind'], slides: Media[], extra: Partial<ComposeSeed> = {}): ComposeSeed => ({
    key: `${p.id}-${look}-${kind}-${Date.now()}`,
    caption: playerCaption(p, look, days, ideaSrc?.site || ''),
    slides, placements: ['feed', 'story'], storyTiming: { mode: 'morning' }, collab: collabFor(p),
    player: { submissionIds: [p.id], tournamentId: p.tournamentId, style: look, kind, days },
    note: `${p.playerName}${p.jersey ? ` #${p.jersey}` : ''} · ${lookLabel(look)}${kind === 'reel' ? ' Reel' : kind === 'story' ? ' Story' : ''}`,
    dayKey: localDayKey(when), countdown: baseLook(look) === 'countdown', ...extra,
  })
  /** Post (feed + Story) or Story only: render the graphics, upload, open Compose filled in. */
  async function composePlayer(p: ClearedPlayer, look: string, mode: 'post' | 'story') {
    if (!liveAccounts.length) { toast.error('Connect an account first'); return }
    const when = whenFor(p); const days = daysAt(p, when)
    setPlayerBusy(`Building ${firstOf(p.playerName)}'s ${mode === 'story' ? 'Story' : 'post'}…`)
    try {
      const storyUrl = await uploadJpeg(await storyJpeg(p.token, look, days, { event: p.event.name, sub: storySub(p), handle: p.instagram }), `${fileSlug(p, look)}-story.jpg`)
      if (mode === 'story') {
        setDrawer({ kind: 'new', when, seed: seedFor(p, look, when, days, 'story', [{ url: storyUrl, mediaType: 'image', width: 1080, height: 1920 }], { placements: ['story'], collab: [] }) })
      } else {
        const feedUrl = await uploadJpeg(await feedJpeg(p.token, look, days), `${fileSlug(p, look)}.jpg`)
        setDrawer({ kind: 'new', when, seed: seedFor(p, look, when, days, 'post', [{ url: feedUrl, mediaType: 'image', width: 1080, height: 1350 }], { storyUrl }) })
      }
    } catch (e: any) { toast.error(e.message) } finally { setPlayerBusy('') }
  }
  // A saved Reel draft for exactly these players (Bo, Oct 18 2026: "when I save a draft,
  // it doesn't seem to keep the draft saved when I come back to it": he came back through
  // the player's Reel button, which started fresh). Reel and Squad Reel now pick it up.
  const draftFor = (ids: string[]) => reelDrafts.find(d => d.playerIds.length === ids.length && ids.every(id => d.playerIds.includes(id)))
  function reelPlayer(p: ClearedPlayer, look: string, fresh = false) {
    if (!liveAccounts.length) { toast.error('Connect an account first'); return }
    const d = fresh ? undefined : draftFor([p.id])
    if (d) { openReelDraft(d); return }
    const when = whenFor(p); setReel({ p, look, when, days: daysAt(p, when) })
  }
  /** Squad Reel: 2–4 cleared players from one event, each in the look picked in the tray. */
  function squadReel(list: ClearedPlayer[], looks: string[]) {
    if (!liveAccounts.length) { toast.error('Connect an account first'); return }
    if (list.length < 2 || list.length > 4) { toast.error('Pick 2 to 4 players'); return }
    if (new Set(list.map(p => p.tournamentId)).size > 1) { toast.error('Pick players from the same event'); return }
    const d = draftFor(list.map(p => p.id))
    if (d) { openReelDraft(d); return }
    const when = whenFor(list[0]); setReel({ p: list[0], look: looks[0], when, days: daysAt(list[0], when), squad: list, looks })
  }
  /** ReelMaker hands back the recorded MP4: upload it and open Compose with it. */
  async function useReel(video: Blob, poster: Blob | null, durationSec: number, opts: { igSong: boolean; day?: string; order?: number[]; saveDraft?: boolean }) {
    if (!reel) return
    const { p, look } = reel
    // The squad in the order it was arranged in the Reel maker (caption and Collab follow it).
    const squad = reel.squad && opts.order?.length === reel.squad.length ? opts.order.map(i => reel.squad![i]) : reel.squad
    let { when, days } = reel
    // The day picked in the Reel maker for a Countdown: post then (today = in 10 minutes,
    // ready to approve or publish right away), so the number on the graphic is right.
    if (opts.day && (opts.day !== localDayKey(when) || opts.day === localDayKey(new Date()))) {
      const [y, m, d] = opts.day.split('-').map(Number)
      when = opts.day === localDayKey(new Date()) ? (() => { const t = new Date(Date.now() + 10 * 60000); t.setMinutes(Math.ceil(t.getMinutes() / 5) * 5, 0, 0); return t })() : new Date(y, m - 1, d, when.getHours(), when.getMinutes())
      days = daysAt(p, when)
    }
    const thumbnailUrl = poster ? await uploadJpeg(poster, `${fileSlug(p, look)}-cover.jpg`).catch(() => '') : ''
    const name = `${fileSlug(p, look)}-reel.mp4`
    // multipart: one big PUT over ~16 MB now fails at once in Chrome ("Failed to fetch", Oct 18 2026:
    // a 30-second squad Reel sat on "Uploading the Reel..." while the client retried); 8 MB parts go through.
    const up = await blobUpload(name, new File([video], name, { type: 'video/mp4' }), { access: 'public', handleUploadUrl: '/api/social/upload-video', multipart: true })
    // The browser records a fragmented MP4 with no audio track when there's no built-in
    // song; Instagram rejects that (2207082). Re-mux it server-side into a standard MP4.
    const vurl = await normalizeReel(up.url, why => toast.error(`Couldn't finish the video for Instagram (${why}). Facebook will take it; Instagram may not.`, { duration: 8000 }))
    const media: Media[] = [{ url: vurl, mediaType: 'video', thumbnailUrl, durationSec, width: 1080, height: 1920, builtIn: !opts.igSong }]
    // Collab takes 3: the shared club first, then families; the rest are tagged in the Reel.
    const h = squad && squad.length > 1 ? squadHandles(squad) : null
    const seed = squad && squad.length > 1 && h ? seedFor(p, look, when, days, 'reel', media, {
      pickSong: opts.igSong, caption: squadCaption(squad, ideaSrc?.site || ''), collab: h.collab, tags: h.tags,
      player: { submissionIds: squad.map(x => x.id), tournamentId: p.tournamentId, style: look, kind: 'reel', days },
      note: `Squad Reel · ${squad.map(x => firstOf(x.playerName)).join(', ')}`, countdown: (reel.looks || []).some(l => baseLook(l) === 'countdown'),
    }) : seedFor(p, look, when, days, 'reel', media, { pickSong: opts.igSong })
    const draftId = reel.draftId
    if (opts.saveDraft) {
      // "Save as draft post": straight onto the calendar as a draft, filled in the way
      // Compose would be. Throws back to the Reel maker (which shows the error) on failure.
      if (when.getTime() < Date.now() + 2 * 60000) { when = new Date(Date.now() + 10 * 60000); when.setMinutes(Math.ceil(when.getMinutes() / 5) * 5, 0, 0) }
      const both = seed.placements.includes('feed') && seed.placements.includes('story')
      const storyAt = both ? storyTimeFor(seed.storyTiming || { mode: 'same' }, when) : when
      const toIg = liveAccounts.some(a => a.platform === 'instagram')
      await api('/api/social/posts', { method: 'POST', body: JSON.stringify({ socialAccountIds: liveAccounts.map(a => a.id), caption: seed.caption, ...slidesBody(seed.slides), placements: seed.placements, scheduledFor: when.toISOString(),
        ...(both && storyAt > new Date() && +storyAt !== +when ? { storyScheduledFor: storyAt.toISOString() } : {}), player: seed.player,
        ...(toIg && seed.collab?.length ? { collaborators: seed.collab } : {}), ...(toIg && seed.tags?.length ? { userTags: seed.tags } : {}) }) })
      setReel(null)
      if (draftId) deleteReelDraft(draftId, true)
      await load()
      toast.success(`Saved as a draft for ${fmtDate(when)} at ${fmtTime(when)}${opts.igSong ? ' — open it to pick the Instagram song before you approve' : ' — approve it on the calendar'}`, { duration: 7000 })
      return
    }
    setReel(null)
    if (draftId) deleteReelDraft(draftId, true)
    setDrawer({ kind: 'new', when, seed })
    toast.success(opts.igSong ? 'Reel ready — pick a trending song, then save' : 'Reel ready — check the post and save it')
  }
  /** "Save draft to finish later" in the Reel maker: keep its settings (no video yet). */
  async function saveReelSetup(setup: ReelSetup) {
    if (!reel) return
    const players = reel.squad || [reel.p]
    const label = reel.squad ? `Squad · ${reel.squad.map(x => firstOf(x.playerName)).join(', ')}` : `${firstOf(reel.p.playerName)} · ${lookLabel(reel.look)}`
    const d = await api('/api/social/reel-drafts', { method: 'POST', body: JSON.stringify({ id: reel.draftId, label, playerIds: players.map(x => x.id), look: reel.look, ...(reel.looks ? { looks: reel.looks } : {}), setup }) })
    setReelDrafts(d.drafts || []); setReel(null)
    toast.success('Draft saved — it\'s under Saved Reels in Cleared to post')
  }
  function openReelDraft(d: ReelDraft) {
    const all = cleared?.players || []
    const players = d.playerIds.map(id => all.find(x => x.id === id)).filter((x): x is ClearedPlayer => !!x)
    if (players.length !== d.playerIds.length) { toast.error('A player in this draft is no longer cleared to post'); return }
    if (!liveAccounts.length) { toast.error('Connect an account first'); return }
    const when = whenFor(players[0])
    setReel({ p: players[0], look: d.look || d.looks?.[0] || 'countdown-photo', when, days: daysAt(players[0], when), ...(players.length > 1 ? { squad: players, looks: d.looks || players.map(() => d.look) } : {}), setup: d.setup as Partial<ReelSetup>, draftId: d.id })
  }
  /** Star / unstar a look in the Looks library (saved for the whole org). */
  async function toggleLookFav(id: string) {
    const next = lookFavs.includes(id) ? lookFavs.filter(x => x !== id) : [...lookFavs, id]
    setLookFavs(next)
    try { const r = await api('/api/social/looks', { method: 'PUT', body: JSON.stringify({ favorites: next }) }); if (Array.isArray(r.favorites)) setLookFavs(r.favorites) }
    catch (e: any) { toast.error(e.message) }
  }
  /** Siblings (lib/siblings): link players so each gets the Siblings look naming the others. */
  async function linkSiblings(ids: string[], rel: string) {
    try {
      await api('/api/social/siblings', { method: 'POST', body: JSON.stringify({ ids, rel }) })
      const cl = await api('/api/social/players'); setCleared(cl)
      toast.success('Linked as siblings — pick "Siblings" as their look, or Reel to make them a set')
    } catch (e: any) { toast.error(e.message) }
  }
  async function unlinkSibling(id: string) {
    try { await api(`/api/social/siblings?id=${encodeURIComponent(id)}`, { method: 'DELETE' }); const cl = await api('/api/social/players'); setCleared(cl) }
    catch (e: any) { toast.error(e.message) }
  }
  /** "Start over" on a reopened draft: drop it and open a fresh Reel maker for the same players. */
  async function startReelOver() {
    if (!reel?.draftId) return
    const { p, look, squad, looks, draftId } = reel
    setReel(null)
    await deleteReelDraft(draftId, true)
    const when = whenFor(p)
    setTimeout(() => setReel({ p, look, when, days: daysAt(p, when), ...(squad ? { squad, looks } : {}) }), 0)
  }
  async function deleteReelDraft(id: string, quiet = false) {
    try { const r = await api(`/api/social/reel-drafts?id=${encodeURIComponent(id)}`, { method: 'DELETE' }); setReelDrafts(r.drafts || []) }
    catch (e: any) { if (!quiet) toast.error(e.message) }
  }
  /** "Plan all cleared players": one feed post + Story per player with nothing
   *  scheduled, each on its own open day before the event, plus a Roll Call carousel
   *  per event with 3+ cleared players. All drafts: nothing posts until approved. */
  async function planAll(only?: ClearedPlayer[]) {
    if (!cleared || !liveAccounts.length) return
    const { posts: todo, rollcalls } = planList(only || cleared.players)
    const ids = liveAccounts.map(a => a.id); const site = ideaSrc?.site || ''
    const taken = takenKeys(); const perDay: Record<string, number> = {}
    const total = todo.length + rollcalls.length
    let made = 0, skipped = 0
    // A free day; when every day already has something, double up at lunchtime on the
    // least-used day (players) or two days out (Roll Call).
    const pickDay = (p: ClearedPlayer, fallback: 'least' | 'late'): Date | null => {
      const days = playerDays(p)
      let at = days.find(d => !taken.has(localDayKey(d)))
      if (!at && days.length) {
        const d = fallback === 'late' ? days[Math.max(0, days.length - 2)] : [...days].sort((a, b) => (perDay[localDayKey(a)] || 0) - (perDay[localDayKey(b)] || 0))[0]
        at = new Date(d); at.setHours(12, 30, 0, 0); if (at < new Date()) at = d
      }
      if (at) { const k = localDayKey(at); taken.add(k); perDay[k] = (perDay[k] || 0) + 1 }
      return at || null
    }
    const idx: Record<string, number> = {}
    for (const p of todo) {
      setPlayerBusy(`Making ${made + skipped + 1} of ${total}…`)
      try {
        const when = pickDay(p, 'least')
        if (!when) { skipped++; continue }
        const i = idx[p.tournamentId] = (idx[p.tournamentId] ?? -1) + 1
        const look = lookFor(p.event.daysOut, i, SEASON_LOOKS[seasonOf(p.event.name, p.event.start)] || []); const n = daysAt(p, when)
        const [feed, story] = await Promise.all([feedJpeg(p.token, look, n), storyJpeg(p.token, look, n, { event: p.event.name, sub: storySub(p), handle: p.instagram })])
        const [feedUrl, storyUrl] = await Promise.all([uploadJpeg(feed, `${fileSlug(p, look)}.jpg`), uploadJpeg(story, `${fileSlug(p, look)}-story.jpg`)])
        await api('/api/social/posts', { method: 'POST', body: JSON.stringify({ socialAccountIds: ids, caption: playerCaption(p, look, n, site), mediaUrls: [feedUrl], mediaType: 'image', placements: ['feed', 'story'], scheduledFor: when.toISOString(), storyScheduledFor: storyTimeFor({ mode: 'morning' }, when).toISOString(), storyMediaUrl: storyUrl, collaborators: collabFor(p), player: { submissionIds: [p.id], tournamentId: p.tournamentId, style: look, kind: 'post', days: n } }) })
        made++
      } catch { skipped++ }
    }
    for (const list of rollcalls) {
      setPlayerBusy(`Making ${made + skipped + 1} of ${total} (Roll Call)…`)
      try {
        const group = list.slice(0, 10); const p0 = group[0]
        const when = pickDay(p0, 'late')
        if (!when) { skipped++; continue }
        const n = daysAt(p0, when)
        const blobs = await Promise.all(group.map(p => feedJpeg(p.token, 'rookie', n)))
        const urls = await Promise.all(blobs.map((b, i) => uploadJpeg(b, `${fileSlug(group[i], 'rookie')}.jpg`)))
        await api('/api/social/posts', { method: 'POST', body: JSON.stringify({ socialAccountIds: ids, caption: rollCallCaption(group, site), mediaUrls: urls, mediaType: 'carousel', placements: ['feed'], scheduledFor: when.toISOString(), player: { submissionIds: group.map(p => p.id), tournamentId: p0.tournamentId, style: 'rookie', kind: 'rollcall', days: n } }) })
        made++
      } catch { skipped++ }
    }
    setPlayerBusy('')
    await load()
    if (made) toast.success(`Made ${made} draft${made === 1 ? '' : 's'} — they're in Approvals${skipped ? ` · ${skipped} couldn't be made` : ''}`, { duration: 6000 })
    else toast.error('No drafts were made — the events may have started, or the graphics failed to build')
  }

  if (status === 'loading' || loading) return <div className="min-h-screen bg-slate-50 p-10 text-center text-slate-400">Loading…</div>

  const rangeEnd = addDays(rangeStart, 13)
  const rangeLabel = `${rangeStart.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} – ${rangeEnd.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`
  const dayStart = new Date(today); dayStart.setHours(0, 0, 0, 0)

  return (
    <div className="min-h-screen text-slate-800 bg-slate-50">
      <Toaster position="top-right" />

      {/* top bar */}
      <div className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur-xl">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-5 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <Link href="/" className="text-slate-500 hover:text-teal-700" title="Home"><ChevronLeft size={18} /></Link>
            <div className="min-w-0"><div className="font-extrabold text-sm leading-tight">Social scheduler</div><div className="text-xs text-slate-500 truncate hidden sm:block">Instagram &amp; Facebook · approve once, it publishes itself</div></div>
          </div>
          <div className="flex items-center gap-2">
          <button onClick={() => setLooksOpen(true)} className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:border-teal-400 text-slate-800 font-bold text-sm px-3 py-2.5" title="Every post look in folders (Everyday, Fall, Christmas, Siblings), previewed on a real player"><Layers size={15} className="text-teal-700" /> <span className="hidden sm:inline">Looks</span></button>
          <button onClick={() => setDrawer({ kind: 'music' })} className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:border-teal-400 text-slate-800 font-bold text-sm px-3 py-2.5" title="Your music for Reels: add, rename, sort into categories"><Music size={15} className="text-teal-700" /> <span className="hidden sm:inline">Music</span></button>
          <button onClick={() => setDrawer({ kind: 'chirp' })} className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:border-teal-400 text-slate-800 font-bold text-sm pl-1.5 pr-3 py-1.5" title="Brainstorm post ideas with Chirp"><ChirpAvatar size={26} /> <span className="hidden sm:inline">Ask Chirp</span><span className="sm:hidden">Chirp</span></button>
          <button onClick={() => newPostOn(addDays(today, 1))} disabled={!accounts.length} className="inline-flex items-center gap-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm px-4 py-2.5 disabled:opacity-40"><Plus size={15} strokeWidth={2.8} /> <span className="hidden sm:inline">Create post</span><span className="sm:hidden">Post</span></button>
          </div>
        </div>
      </div>

      <div className="max-w-[1240px] mx-auto px-4 sm:px-5 py-5 flex flex-col gap-4">
        {!configured && (
          <div className="rounded-2xl border border-amber-300 bg-amber-50 text-amber-800 text-sm px-4 py-3 flex gap-2"><AlertTriangle size={16} className="flex-none mt-0.5" /><span>The Meta app keys aren’t set yet (META_APP_ID / META_APP_SECRET in Vercel). Drafting works; connecting accounts and publishing won’t until they’re added — see SOCIAL-SCHEDULER.md.</span></div>
        )}

        {/* hero tiles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_auto] gap-3">
          <button onClick={() => setView('queue')} className="text-left rounded-2xl p-4 min-h-[120px] flex flex-col justify-between gap-4 bg-gradient-to-br from-teal-600 to-teal-500 text-white shadow-sm hover:brightness-105">
            <div className="flex items-center justify-between"><ThumbsUp size={20} /><span className="w-7 h-7 rounded-full bg-black/15 grid place-items-center"><ChevronRight size={14} /></span></div>
            <div><div className="text-3xl font-extrabold leading-none tabular-nums">{needsReview}</div><div className="font-extrabold">posts to review</div><div className="text-xs opacity-80 mt-0.5">Approve in one tap — nothing publishes without you</div></div>
          </button>
          <button onClick={() => setDrawer({ kind: 'accounts' })} title="Accounts & queue times" className="text-left rounded-2xl p-4 min-h-[120px] flex flex-col justify-between gap-4 bg-white border border-slate-200 hover:border-slate-300 shadow-sm">
            <div className="flex items-center justify-between text-slate-500"><Link2 size={20} /><span className="w-7 h-7 rounded-full bg-slate-100 grid place-items-center"><ChevronRight size={14} /></span></div>
            <div><div className="font-extrabold">{accounts.length ? `${accounts.length} account${accounts.length === 1 ? '' : 's'} connected` : 'No accounts connected yet'}</div><div className="text-xs text-slate-500 mt-0.5 truncate">{accounts.length ? accounts.map(a => a.label).join(' · ') : 'Connect your Instagram + Facebook to start scheduling'}</div></div>
          </button>
          <div className="flex gap-3 sm:col-span-2 lg:col-span-1">
            {(() => { const w = insights.window; const cur = w?.current; const prev = w?.previous; const has = !!cur && cur.withData > 0
              return <>
                <button onClick={() => setView('insights')} className="text-left flex-1 lg:min-w-[150px] rounded-2xl p-4 bg-white border border-slate-200 shadow-sm hover:border-teal-400" title={has ? `${cur!.withData} of ${cur!.posts} posts have insights so far` : 'Shows once the insights snapshot has run (every 4 hours) or after importing history'}>
                  <div className="flex items-baseline gap-2"><span className="text-2xl font-extrabold tabular-nums">{has ? fmtNum(cur!.reach) : '—'}</span>{has && prev && prev.withData > 0 && <span className={`text-xs font-bold ${cur!.reach >= prev.reach ? 'text-emerald-600' : 'text-rose-600'}`}>{delta(cur!.reach, prev.reach)}</span>}</div>
                  <div className="text-xs text-slate-500">People reached · {w?.days || 28} days</div>
                  <div className="text-[11px] font-bold text-teal-700 mt-1">See insights ›</div>
                </button>
                <button onClick={() => setView('insights')} className="text-left flex-1 lg:min-w-[150px] rounded-2xl p-4 bg-white border border-slate-200 shadow-sm hover:border-teal-400" title={`${scheduledCount} scheduled · ${published28} published in 28 days`}>
                  <div className="flex items-baseline gap-2"><span className="text-2xl font-extrabold tabular-nums">{has ? fmtNum(cur!.interactions) : '—'}</span>{has && prev && prev.withData > 0 && <span className={`text-xs font-bold ${cur!.interactions >= prev.interactions ? 'text-emerald-600' : 'text-rose-600'}`}>{delta(cur!.interactions, prev.interactions)}</span>}</div>
                  <div className="text-xs text-slate-500">Interactions · {w?.days || 28} days</div>
                  <div className="text-[11px] font-bold text-teal-700 mt-1">Top posts ›</div>
                </button>
              </> })()}
          </div>
        </div>

        {/* toolbar */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className={`flex items-center gap-2 ${view === 'insights' ? 'invisible' : ''}`}>
            <button onClick={() => setRangeStart(addDays(rangeStart, -14))} className="w-8 h-8 rounded-lg border border-slate-300 bg-white grid place-items-center text-slate-500 hover:text-slate-900" aria-label="Previous two weeks"><ChevronLeft size={15} /></button>
            <h2 className="text-lg sm:text-xl font-extrabold">{rangeLabel}</h2>
            <button onClick={() => setRangeStart(addDays(rangeStart, 14))} className="w-8 h-8 rounded-lg border border-slate-300 bg-white grid place-items-center text-slate-500 hover:text-slate-900" aria-label="Next two weeks"><ChevronRight size={15} /></button>
            <button onClick={() => setRangeStart(startOfWeek(new Date()))} className="text-sm font-bold text-slate-600 hover:text-slate-900 px-2">Today</button>
          </div>
          <div className="inline-flex p-1 gap-0.5 rounded-xl bg-slate-100 border border-slate-200">
            {(['week', 'queue', 'insights'] as const).map(v => <button key={v} onClick={() => setView(v)} className={`px-3 py-1.5 rounded-lg text-sm font-bold ${view === v ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}>{v === 'week' ? 'Calendar' : v === 'queue' ? 'Approvals' : 'Insights'}</button>)}
          </div>
          <div className={`${view === 'insights' ? 'hidden' : 'hidden md:flex'} gap-3 text-xs text-slate-500 items-center`}><span><i className="inline-block w-2 h-2 rounded-full bg-amber-500 mr-1.5" />Needs approval</span><span><i className="inline-block w-2 h-2 rounded-full bg-emerald-500 mr-1.5" />Scheduled</span><span><i className="inline-block w-2 h-2 rounded-full bg-slate-400 mr-1.5" />Published</span><span><i className="inline-block w-2 h-2 rounded-full bg-rose-500 mr-1.5" />Failed</span><span><Lightbulb size={11} className="inline text-teal-600 mr-1" />Dashed = idea</span><span>· Drag a post to another day</span></div>
        </div>

        {/* ideas bar */}
        {view === 'week' && ideaSrc && (
          <div className="flex items-center gap-1.5 flex-wrap -mt-1">
            <button onClick={() => saveIdeaSettings({ show: !ideaSrc.settings.show })} aria-pressed={ideaSrc.settings.show} className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold ${ideaSrc.settings.show ? 'border-teal-500 bg-teal-50 text-teal-800' : 'border-slate-300 bg-white text-slate-500 hover:text-slate-900'}`}><Lightbulb size={13} /> {ideaSrc.settings.show ? 'Ideas on' : 'Show ideas'}</button>
            {ideaSrc.settings.show && (['lacrosse', 'other'] as const).map(g => (
              <span key={g} className="contents">
                <span className="text-[10px] font-extrabold uppercase tracking-wide text-slate-400 ml-2">{g === 'lacrosse' ? 'Lacrosse' : 'Other sports'}</span>
                {LEAGUES.filter(l => l.group === g).map(l => { const on = ideaSrc.settings.leagues.includes(l.k); return (
                  <button key={l.k} title={l.fit} aria-pressed={on} onClick={() => { setFitFor(l.k); saveIdeaSettings({ leagues: on ? ideaSrc.settings.leagues.filter(x => x !== l.k) : [...ideaSrc.settings.leagues, l.k] }) }}
                    className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-bold ${on ? 'border-teal-500 bg-teal-50 text-teal-800' : 'border-slate-300 bg-white text-slate-500 hover:text-slate-900'}`}>{on && <Check size={11} />}{l.n}</button>) })}
              </span>
            ))}
            {ideaSrc.settings.show && fitFor && <div className="basis-full text-xs text-slate-500 mt-0.5"><b className="text-slate-700">{leagueName(fitFor)}:</b> {LEAGUES.find(l => l.k === fitFor)?.fit}</div>}
          </div>
        )}

        {/* cleared players */}
        {view === 'week' && cleared && <PlayersTray data={cleared} canPost={liveAccounts.length > 0} busy={playerBusy} onPost={(p, l) => composePlayer(p, l, 'post')} onReel={reelPlayer} onSquad={squadReel} onStory={(p, l) => composePlayer(p, l, 'story')} onPlanAll={planAll} drafts={reelDrafts} onOpenDraft={openReelDraft} onDeleteDraft={id => deleteReelDraft(id)} onLinkSiblings={linkSiblings} onUnlinkSibling={unlinkSibling} favorites={lookFavs} />}

        {/* calendar */}
        {view === 'week' && (
          <div className="flex flex-col gap-3">
            {[0, 1].map(w => (
              <div key={w} className="grid grid-cols-1 md:grid-cols-7 gap-2">
                {Array.from({ length: 7 }, (_, i) => addDays(rangeStart, w * 7 + i)).map(day => {
                  const dayPosts = posts.filter(p => p.status !== 'canceled' && sameDay(new Date(p.scheduledFor), day)).sort((a, b) => +new Date(a.scheduledFor) - +new Date(b.scheduledFor))
                  const isToday = sameDay(day, today); const isPast = day < dayStart
                  const di = ideasByDay[localDayKey(day)]; const dayIdeas = di?.ideas || []; const markers = di?.markers || []
                  return (
                    <div key={+day}
                      onDragOver={e => { if (dragId.current) { e.preventDefault(); e.currentTarget.classList.add('!border-teal-400', '!bg-teal-400/10') } }}
                      onDragLeave={e => e.currentTarget.classList.remove('!border-teal-400', '!bg-teal-400/10')}
                      onDrop={e => { e.preventDefault(); e.currentTarget.classList.remove('!border-teal-400', '!bg-teal-400/10'); if (dragId.current) moveTo(dragId.current, day); dragId.current = null }}
                      className={`group rounded-2xl p-2.5 flex-col gap-2 md:min-h-[200px] bg-white border transition ${isToday ? 'border-teal-500 shadow-[inset_0_0_0_1px_rgb(20,184,166)]' : 'border-slate-200'} ${isPast ? 'opacity-70' : ''} ${dayPosts.length || dayIdeas.length || markers.length ? 'flex' : 'hidden md:flex'}`}>
                      <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                        <span>{day.toLocaleDateString(undefined, { weekday: 'short' })} <span className="text-slate-900">{day.getDate()}</span>{isToday && <span className="text-teal-600"> · Today</span>}</span>
                        {!isPast && accounts.length > 0 && <button onClick={() => newPostOn(day)} className="flex-none w-5 h-5 rounded-md border border-dashed border-slate-300 grid place-items-center text-slate-400 md:opacity-0 group-hover:opacity-100 hover:text-slate-900" title="New post this day"><Plus size={11} /></button>}
                      </div>
                      {di?.badge && <div className="-mt-1.5 min-w-0">{di.badge.live ? <span className="inline-block rounded bg-slate-800 text-white px-1.5 py-px text-[10px] font-extrabold uppercase tracking-wide">{di.badge.text}</span> : <div className="truncate text-[10px] font-semibold text-slate-400" title={di.badge.text}>{di.badge.text}</div>}</div>}
                      {markers.map((mk, i) => <div key={i} className={`text-[10.5px] leading-tight rounded-md px-1.5 py-1 ${mk.clash ? 'bg-amber-50 text-amber-900' : 'bg-slate-100 text-slate-600'} ${mk.kind === 'quiet' ? 'text-slate-400' : ''}`}>{mk.lg && <b className={`mr-1 text-[9.5px] tracking-wide ${mk.clash ? 'text-amber-700' : 'text-teal-700'}`}>{leagueName(mk.lg)}</b>}{mk.label}{mk.kind === 'quiet' ? ' · stay quiet' : ''}</div>)}
                      {dayPosts.map(p => (
                        <div key={p.id} draggable={p.status !== 'published' && p.status !== 'publishing'} onDragStart={() => { dragId.current = p.id }} onDragEnd={() => { dragId.current = null }} onClick={() => setDrawer({ kind: 'post', id: p.id, mode: 'preview' })}
                          className="rounded-xl bg-slate-50 border border-slate-200 p-2 flex gap-2 items-center cursor-pointer hover:-translate-y-px hover:border-slate-300 hover:shadow-md transition">
                          <Thumb post={p} />
                          <div className="min-w-0 flex-1"><div className="text-xs font-bold leading-tight line-clamp-2">{kindLabel(p) && <span className="text-slate-500">{kindLabel(p)}{p.audio ? ' ♪' : ''} · </span>}{firstLine(p.caption || (p.placement === 'story' ? 'Story' : ''))}</div><div className={`text-[11px] font-bold mt-0.5 flex flex-wrap gap-x-1.5 ${STATUS_TEXT[p.status]}`}>{STATUS_LABEL[p.status]}<span className="text-slate-500">{fmtTime(new Date(p.scheduledFor))}</span></div></div>
                        </div>
                      ))}
                      {dayIdeas.map(idea => { const c = AUD_CLS[idea.aud] || AUD_CLS.all; return (
                        <button key={idea.key} onClick={() => setDrawer({ kind: 'idea', idea })} className={`relative text-left rounded-xl border border-dashed pl-3 pr-2 py-1.5 flex flex-col gap-0.5 hover:border-slate-400 hover:shadow-sm transition ${idea.weight === 'story' || idea.quiet ? 'bg-slate-50 border-slate-300' : 'bg-white border-slate-300'}`}>
                          <span className={`absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-full ${idea.quiet ? 'bg-slate-300' : c.bar}`} />
                          <span className="flex items-center gap-1 text-[10px] text-slate-500"><Lightbulb size={11} className="text-teal-600 flex-none" />{idea.quiet ? 'Suggestion' : idea.fmt}{idea.lg ? ` · ${leagueName(idea.lg)}` : idea.src === 'moment' && !idea.quiet ? ' · Moment' : ''}</span>
                          <span className={`text-xs font-bold leading-tight ${idea.quiet ? 'text-slate-500 font-semibold' : 'text-slate-800'}`}>{idea.title}</span>
                          {!idea.quiet && <span className={`text-[10.5px] font-bold ${c.text}`}>{AUDIENCE_LABEL[idea.aud]}</span>}
                        </button>) })}
                      {!dayPosts.length && !dayIdeas.length && !isPast && <div className="mt-auto text-[11px] text-slate-400 text-center py-3 border border-dashed border-slate-200 rounded-xl">Nothing scheduled</div>}
                    </div>
                  )
                })}
              </div>
            ))}
            {!posts.length && <div className="text-center text-sm text-slate-500 py-6">{accounts.length ? 'No posts yet — hit Create post, or the + on any day.' : 'Connect an account first, then start scheduling.'}</div>}
          </div>
        )}

        {/* approvals board */}
        {view === 'insights' && <InsightsView canRefresh={canApprove} onOpenPost={id => setDrawer({ kind: 'post', id, mode: 'preview' })} />}

        {view === 'queue' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[{ t: 'Needs approval', f: (p: Post) => p.status === 'draft' }, { t: 'Scheduled', f: (p: Post) => p.status === 'scheduled' || p.status === 'failed' || p.status === 'publishing' }, { t: 'Published', f: (p: Post) => p.status === 'published' }].map(col => {
              const list = posts.filter(col.f).sort((a, b) => +new Date(a.scheduledFor) - +new Date(b.scheduledFor))
              return (
                <div key={col.t} className="rounded-2xl bg-white border border-slate-200 p-3 flex flex-col gap-2.5 min-h-[200px]">
                  <div className="flex items-center justify-between px-1 pb-1 text-sm font-extrabold"><span>{col.t}</span><span className="text-xs text-slate-500 bg-slate-100 rounded-full px-2 py-0.5">{list.length}</span></div>
                  {!list.length && <div className="text-[11px] text-slate-400 text-center py-4 border border-dashed border-slate-200 rounded-xl">Nothing here</div>}
                  {list.map(p => (
                    <div key={p.id} onClick={() => setDrawer({ kind: 'post', id: p.id, mode: 'preview' })} className="rounded-2xl bg-slate-50 border border-slate-200 p-2.5 flex flex-col gap-2 cursor-pointer hover:border-slate-300">
                      <div className="flex gap-2 items-center"><Thumb post={p} /><div className="min-w-0 flex-1"><div className="text-xs font-bold truncate">{firstLine(p.caption)}</div><div className="text-[11px] text-slate-500">{p.socialAccount?.label} · {fmtDate(new Date(p.scheduledFor))} · {fmtTime(new Date(p.scheduledFor))}</div></div></div>
                      <div className="text-xs text-slate-600 line-clamp-2 whitespace-pre-line">{p.caption}</div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] text-slate-500">{p.approvedByUserId ? 'Approved' : p.status === 'draft' ? (canApprove ? 'Waiting on you' : 'Waiting on a director') : ''}</span>
                        {p.status === 'draft' && canApprove && <button onClick={e => { e.stopPropagation(); approve(p) }} className="rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5">Approve</button>}
                        {p.status === 'failed' && <span className="text-[11px] font-bold text-rose-600">Failed · open to retry</span>}
                        {(p.status === 'scheduled' || p.status === 'publishing') && <span className="text-[11px] font-bold text-emerald-700">Auto-publishes</span>}
                        {p.status === 'published' && <span className="text-[11px] font-bold text-slate-500">Live</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )
            })}
          </div>
        )}

        <p className="text-center text-xs text-slate-400 pt-2">Publishing checks every 15 minutes. Insights snapshot every 4 hours.</p>
      </div>

      {/* drawer */}
      {drawer && <div className="fixed inset-0 z-40 bg-slate-900/40" onClick={() => setDrawer(null)} />}
      <div className={`fixed top-0 right-0 bottom-0 z-50 w-full sm:w-[460px] bg-white border-l border-slate-200 shadow-2xl flex flex-col transition-transform duration-200 ${drawer ? 'translate-x-0' : 'translate-x-full'}`}>
        {drawer?.kind === 'post' && byId(drawer.id) && <PostDrawer reelEvents={(ideaSrc?.events || []).filter(e => e.end >= localDayKey(new Date()))} reelSite={ideaSrc?.site} post={byId(drawer.id)!} metrics={insights.latest[drawer.id]} siblings={posts.filter(x => x.groupId && x.groupId === byId(drawer.id)!.groupId && x.id !== drawer.id)} queue={queue} mode={drawer.mode} setMode={m => setDrawer({ ...drawer, mode: m })} canApprove={canApprove} onClose={() => setDrawer(null)} onApprove={approve} onPublishNow={publishNow} onPatch={patch} onDelete={remove} />}
        {drawer?.kind === 'new' && <ComposeDrawer key={drawer.idea?.key || drawer.seed?.key || 'blank'} seed={drawer.seed} reelEvents={(ideaSrc?.events || []).filter(e => e.end >= localDayKey(new Date()))} reelSite={ideaSrc?.site} when={drawer.when} idea={drawer.idea} accounts={accounts} queue={queue} canApprove={canApprove} onClose={() => setDrawer(drawer.idea?.src === 'chirp' ? { kind: 'chirp' } : null)} onSaved={async () => { setDrawer(null); await load() }} />}
        {drawer?.kind === 'chirp' && <ChirpPanel msgs={chirpMsgs} setMsgs={setChirpMsgs} site={ideaSrc?.site} onClose={() => setDrawer(null)} onDraft={idea => { if (!accounts.length) { toast.error('Connect an account first'); return } draftFromIdea(idea) }} />}
        {drawer?.kind === 'idea' && <IdeaDrawer idea={drawer.idea} canDraft={accounts.length > 0} onClose={() => setDrawer(null)} onDraft={() => draftFromIdea(drawer.idea)} onDismiss={() => { saveIdeaSettings({ dismiss: drawer.idea.key }); setDrawer(null); toast('Idea hidden') }} />}
        {drawer?.kind === 'music' && <MusicDrawer onClose={() => setDrawer(null)} />}
        {drawer?.kind === 'accounts' && <AccountsDrawer accounts={accounts} configured={configured} queue={queue} canManage={canApprove} onClose={() => setDrawer(null)} onChanged={load} />}
      </div>

      {/* a cleared player's Reel: recorded here, then handed to Compose */}
      {reel && <ReelMaker key={(reel.draftId || '') + (reel.squad ? reel.squad.map(x => x.id).join('-') : `${reel.p.id}-${reel.look}`)} src={postPngUrl(reel.p.token, reel.look, reel.days)} style={reel.look}
        label={reel.squad ? `Squad · ${reel.squad.map(x => firstOf(x.playerName)).join(', ')}` : `${firstOf(reel.p.playerName)} · ${lookLabel(reel.look)}`}
        event={reel.p.event.name || 'Game day'} sub={storySub(reel.p)} days={reel.days} fileName={reel.squad ? `squad-${reel.squad.map(x => firstOf(x.playerName)).join('-')}`.toLowerCase().replace(/[^a-z0-9-]+/g, '-') : fileSlug(reel.p, reel.look)} token={reel.p.token}
        squad={reel.squad?.map((x, i) => ({ token: x.token, first: firstOf(x.playerName), style: reel.looks?.[i] || reel.look }))}
        eventStart={reel.p.event.start} postDay={localDayKey(reel.when)}
        initialSong="ig" onUse={useReel} onSaveSetup={saveReelSetup} initialSetup={reel.setup}
        draftNote={reel.draftId ? (() => { const d = reelDrafts.find(x => x.id === reel.draftId); return d ? `Your saved draft from ${new Date(d.savedAt).toLocaleString(undefined, { weekday: 'short', hour: 'numeric', minute: '2-digit' })}` : 'Your saved draft' })() : undefined}
        onStartOver={reel.draftId ? startReelOver : undefined} favorites={lookFavs} onClose={() => setReel(null)} />}

      {looksOpen && <LooksLibrary players={cleared?.players || []} favorites={lookFavs} onToggleFavorite={toggleLookFav} onClose={() => setLooksOpen(false)}
        onPost={(p, look) => { setLooksOpen(false); composePlayer(p, look, 'post') }} onReel={(p, look) => { setLooksOpen(false); reelPlayer(p, look, true) }} />}
    </div>
  )
}

/* ---------------- drawers ---------------- */
function DrawerHead({ title, onClose, children }: { title: string; onClose: () => void; children?: ReactNode }) {
  return <div className="flex items-center justify-between gap-2 px-4 py-3.5 border-b border-slate-200"><h3 className="font-extrabold text-sm">{title}</h3><div className="flex items-center gap-2">{children}<button onClick={onClose} className="w-8 h-8 rounded-lg border border-slate-300 bg-white grid place-items-center text-slate-500 hover:text-slate-900" aria-label="Close"><X size={14} /></button></div></div>
}
const inputCls = 'w-full rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-500'
const labelCls = 'block text-[11px] font-extrabold uppercase tracking-wide text-slate-500 mb-1.5'

function NativePreview({ platform, label, caption, imgSrc: firstSrc, when, mediaType: firstType = 'image', placement = 'feed', poster: firstPoster, slides, song }: { platform: string; label: string; caption: string; imgSrc?: string; when: Date; mediaType?: 'image' | 'video' | 'carousel'; placement?: Placement; poster?: string; slides?: Media[]; song?: Song | null }) {
  const ig = platform === 'instagram'
  const handle = label.replace(/^@/, '')
  const isStory = placement === 'story'
  // Carousel: swipe through the slides here. Facebook shows only the photos (it
  // can't mix video into a multi-photo post), and a Story shows slide 1.
  const deck = !isStory && slides && slides.length > 1 ? (ig ? slides : slides.filter(x => x.mediaType === 'image').length ? slides.filter(x => x.mediaType === 'image') : slides.slice(0, 1)) : null
  const [at, setAt] = useState(0)
  const cur = deck ? deck[Math.min(at, deck.length - 1)] : null
  const imgSrc = cur ? cur.url : firstSrc
  const mediaType = cur ? cur.mediaType : firstType === 'carousel' ? (slides?.[0]?.mediaType || 'image') : firstType
  const poster = cur ? cur.thumbnailUrl : firstPoster
  const isVideo = mediaType === 'video'
  const frame = isStory || (ig && isVideo) ? 'aspect-[9/16] max-h-[420px] mx-auto' : ig ? 'aspect-square' : isVideo ? 'aspect-square' : 'aspect-[1.91/1]'
  // "Play with song" (Bo: "Am I able to preview this with the music?"): Instagram only
  // mixes its song in when it publishes, so this plays the Reel and the song together
  // here, at the volumes set on the post. Instagram may start the song elsewhere.
  const vid = useRef<HTMLVideoElement | null>(null)
  const songEl = useRef<HTMLAudioElement | null>(null)
  const [mix, setMix] = useState<'' | 'loading' | 'playing'>('')
  const canMix = ig && isVideo && !isStory && !deck && !!song && !!imgSrc
  const stopMix = () => { songEl.current?.pause(); vid.current?.pause(); setMix('') }
  useEffect(() => () => { songEl.current?.pause() }, [])
  async function playMix() {
    if (!song || !vid.current) return
    if (mix === 'playing') { stopMix(); return }
    setMix('loading')
    try {
      const d = await api(`/api/social/audio?id=${encodeURIComponent(song.audioId)}`)
      const url = d.audio?.[0]?.previewUrl
      if (!url) throw new Error("Instagram didn't send this song's audio")
      songEl.current?.pause()
      const a = new Audio(url); songEl.current = a
      a.volume = Math.max(0, Math.min(1, song.audioVolume / 100))
      const v = vid.current
      v.currentTime = 0; v.volume = Math.max(0, Math.min(1, song.videoVolume / 100)); v.muted = song.videoVolume === 0
      v.onended = () => { a.pause(); setMix('') }
      v.onpause = () => { if (!v.ended) { a.pause(); setMix('') } }
      await Promise.all([a.play(), v.play()])
      setMix('playing')
    } catch (e: any) { toast.error(e.message || "Couldn't play the song"); setMix('') }
  }
  const mediaEl = !imgSrc ? <span>{isVideo ? 'NO VIDEO YET' : 'NO PHOTO YET'}</span>
    : isVideo ? <video ref={vid} src={imgSrc} poster={poster || undefined} controls playsInline className="w-full h-full object-contain bg-black" />
    : <img src={imgSrc} alt="" className="w-full h-full object-cover" />
  if (isStory) {
    return (
      <div className="flex-none rounded-2xl overflow-hidden border border-slate-200 bg-slate-900 text-white">
        <div className="flex items-center gap-2.5 px-3 py-2.5"><div className="w-8 h-8 rounded-full ring-2 ring-pink-500 bg-gradient-to-br from-teal-400 to-indigo-500" /><div><div className="text-sm font-extrabold">{handle}</div><div className="text-[11px] text-slate-300">Story · {ig ? 'Instagram' : 'Facebook'} · gone after 24 h</div></div></div>
        <div className={`${frame} bg-black grid place-items-center text-slate-400 text-xs tracking-widest w-full`}>{mediaEl}</div>
        <div className="px-3 py-2 text-[11px] text-slate-400">Stories don't carry a caption — the video is the whole post.</div>
      </div>
    )
  }
  return (
    // flex-none: the drawer body is a flex column, and without it a tall Reel preview was
    // squeezed to fit the window and its overflow clipped, hiding "Play with song" and
    // the caption on shorter screens (Bo, Oct 18 2026).
    <div className="flex-none rounded-2xl overflow-hidden border border-slate-200 bg-white">
      <div className="flex items-center gap-2.5 px-3 py-2.5"><div className="w-8 h-8 rounded-full bg-gradient-to-br from-teal-400 to-indigo-500" /><div><div className="text-sm font-extrabold">{handle}</div><div className="text-[11px] text-slate-500">{ig ? (deck ? `Instagram carousel · ${deck.length} slides` : isVideo ? (song ? <span className="inline-flex items-center gap-1"><Music size={10} />{song.title}{song.artist ? ` · ${song.artist}` : ''}</span> : 'Instagram Reel · also shows in the feed') : 'Instagram post') : `${fmtDate(when)} · Public${deck ? ` · ${deck.length} photos` : ''}`}</div></div></div>
      {!ig && <div className="px-3 pb-2.5 text-sm whitespace-pre-wrap leading-snug">{caption || <span className="text-slate-500">No caption yet</span>}</div>}
      <div className={`${frame} relative bg-slate-200 grid place-items-center text-slate-500 text-xs tracking-widest`}>{mediaEl}
        {deck && deck.length > 1 && <>
          <span className="absolute top-2 right-2 rounded-full bg-black/60 text-white text-[10px] font-bold px-2 py-0.5 tracking-normal">{Math.min(at, deck.length - 1) + 1}/{deck.length}</span>
          {at > 0 && <button type="button" onClick={() => setAt(at - 1)} className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 shadow grid place-items-center text-slate-700" aria-label="Previous slide"><ChevronLeft size={15} /></button>}
          {at < deck.length - 1 && <button type="button" onClick={() => setAt(at + 1)} className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 shadow grid place-items-center text-slate-700" aria-label="Next slide"><ChevronRight size={15} /></button>}
        </>}
      </div>
      {canMix && <div className="px-3 pt-2.5 flex items-center gap-2 flex-wrap"><button type="button" onClick={playMix} disabled={mix === 'loading'} className="inline-flex items-center gap-1.5 rounded-lg bg-pink-600 hover:bg-pink-700 text-white text-xs font-bold px-3 py-1.5 disabled:opacity-50">{mix === 'playing' ? <Pause size={12} /> : <Play size={12} fill="currentColor" />}{mix === 'playing' ? 'Stop' : mix === 'loading' ? 'Loading song…' : 'Play with song'}</button><span className="text-[11px] text-slate-500">A preview: Instagram adds the song when it publishes and may start it at a different spot.</span></div>}
      {deck && deck.length > 1 && ig && <div className="flex justify-center gap-1 pt-2">{deck.map((_, i) => <span key={i} className={`w-1.5 h-1.5 rounded-full ${i === Math.min(at, deck.length - 1) ? 'bg-sky-500' : 'bg-slate-300'}`} />)}</div>}
      {ig ? <><div className="flex gap-3.5 px-3 pt-2.5 text-slate-700"><Heart size={20} /><MessageCircle size={20} /><Send size={20} /></div><div className="px-3 pt-1.5 pb-3 text-sm whitespace-pre-wrap leading-snug"><b>{handle}</b> {caption}</div></>
        : <div className="flex justify-around px-3 py-2 border-t border-slate-200 text-xs font-bold text-slate-500"><span>Like</span><span>Comment</span><span>Share</span></div>}
    </div>
  )
}

async function probeVideo(file: File): Promise<{ durationSec: number; width: number; height: number; poster: Blob | null }> {
  const url = URL.createObjectURL(file)
  try {
    const v = document.createElement('video'); v.preload = 'metadata'; v.muted = true; v.playsInline = true; v.src = url
    await new Promise<void>((res, rej) => { v.onloadedmetadata = () => res(); v.onerror = () => rej(new Error('That video can\'t be read by the browser — export it as MP4 (H.264) and try again')) })
    const durationSec = v.duration || 0
    // Poster frame ~1 s in (or the midpoint of a very short clip) for the calendar
    // thumbnail and the Reel cover.
    await new Promise<void>(res => { v.onseeked = () => res(); v.currentTime = Math.min(1, durationSec / 2) })
    const canvas = document.createElement('canvas'); const k = Math.min(1, 720 / Math.max(v.videoWidth, v.videoHeight))
    canvas.width = Math.round(v.videoWidth * k); canvas.height = Math.round(v.videoHeight * k)
    canvas.getContext('2d')?.drawImage(v, 0, 0, canvas.width, canvas.height)
    const poster = await new Promise<Blob | null>(r => canvas.toBlob(r, 'image/jpeg', 0.85))
    return { durationSec, width: v.videoWidth, height: v.videoHeight, poster }
  } finally { URL.revokeObjectURL(url) }
}

async function uploadImage(f: Blob, name: string): Promise<string> {
  const fd = new FormData(); fd.append('file', new File([f], name, { type: f.type || 'image/jpeg' }))
  const res = await fetch('/api/upload', { method: 'POST', body: fd }); const d = await res.json().catch(() => ({}))
  if (!res.ok || !d.url) throw new Error(d.error || 'Upload failed')
  // Meta fetches the image by URL, so a data: URL fallback would never publish.
  if (d.inlineFallback || String(d.url).startsWith('data:')) throw new Error('Image storage is unavailable right now — try again in a minute')
  return d.url
}

/** Uploads one photo or video (video: probe → poster frame → Blob upload) and
 *  returns it as a Media. Throws with a readable message. Shared by the main
 *  media box and the carousel "add slide" button. */
async function uploadOne(f: File, setBusy: (s: string) => void): Promise<Media> {
  if (f.type.startsWith('video/')) {
    if (!/mp4|quicktime/.test(f.type)) throw new Error('Use an MP4 (or .mov) — that\'s what Instagram and Facebook accept')
    setBusy('Reading video…')
    const info = await probeVideo(f)
    if (info.durationSec < 3) throw new Error('Videos need to be at least 3 seconds')
    if (info.durationSec > 15 * 60) throw new Error('Reels max out at 15 minutes')
    let thumbnailUrl = ''
    if (info.poster) { setBusy('Saving cover frame…'); thumbnailUrl = await uploadImage(info.poster, 'cover.jpg') }
    setBusy('Uploading video… 0%')
    const blob = await blobUpload(f.name.replace(/[^\w.\-]+/g, '_'), f, {
      access: 'public', handleUploadUrl: '/api/social/upload-video', multipart: true,   // big single PUTs fail; see useReel
      onUploadProgress: (p: { percentage: number }) => setBusy(`Uploading video… ${Math.round(p.percentage)}%`),
    })
    // Re-mux to a progressive, Instagram-ingestible MP4 (MediaRecorder/phone files can be
    // fragmented MP4, which Instagram rejects with 2207082). Falls back to the original URL.
    setBusy('Finishing video…')
    const vurl = await normalizeReel(blob.url)
    return { url: vurl, mediaType: 'video', thumbnailUrl, durationSec: info.durationSec, width: info.width, height: info.height }
  }
  setBusy('Uploading photo…')
  const url = await uploadImage(f, f.name)
  return { url, mediaType: 'image' }
}

/** Carousel slides under the main media box: reorder, remove, add (up to 10). */
function SlidesStrip({ slides, setSlides }: { slides: Media[]; setSlides: (s: Media[]) => void }) {
  const [busy, setBusy] = useState('')
  const ref = useRef<HTMLInputElement>(null)
  const move = (i: number, d: number) => { const j = i + d; if (j < 0 || j >= slides.length) return; const n = [...slides]; [n[i], n[j]] = [n[j], n[i]]; setSlides(n) }
  async function add(files: File[]) {
    let cur = [...slides]
    for (const f of files) {
      if (cur.length >= 10) { toast.error('Carousels max out at 10 slides'); break }
      try { cur = [...cur, await uploadOne(f, setBusy)]; setSlides(cur) }
      catch (e: any) { toast.error(String(e?.message || 'Upload failed').replace(/^Error:\s*/, '')) }
    }
    setBusy('')
  }
  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex gap-2 overflow-x-auto pb-1">
        {slides.map((m, i) => (
          <div key={m.url + i} className="relative flex-none w-16">
            <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-200 grid place-items-center">
              {m.mediaType === 'video' ? (m.thumbnailUrl ? <img src={m.thumbnailUrl} alt="" className="w-full h-full object-cover" /> : <Film size={16} className="text-slate-500" />) : <img src={m.url} alt="" className="w-full h-full object-cover" />}
            </div>
            <span className="absolute top-0.5 left-0.5 rounded bg-black/65 text-white text-[9px] font-bold px-1">{i + 1}{m.mediaType === 'video' ? ' ▶' : ''}</span>
            {slides.length > 1 && <button type="button" onClick={() => setSlides(slides.filter((_, k) => k !== i))} className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-white border border-slate-300 grid place-items-center text-slate-500 hover:text-rose-600" aria-label={`Remove slide ${i + 1}`}><X size={11} /></button>}
            <div className="flex justify-between mt-0.5">
              <button type="button" disabled={i === 0} onClick={() => move(i, -1)} className="w-6 h-5 rounded border border-slate-200 grid place-items-center text-slate-500 disabled:opacity-30" aria-label="Move left"><ArrowLeft size={11} /></button>
              <button type="button" disabled={i === slides.length - 1} onClick={() => move(i, 1)} className="w-6 h-5 rounded border border-slate-200 grid place-items-center text-slate-500 disabled:opacity-30" aria-label="Move right"><ArrowRight size={11} /></button>
            </div>
          </div>
        ))}
        {slides.length < 10 && <button type="button" disabled={!!busy} onClick={() => ref.current?.click()} className="flex-none w-16 h-16 rounded-lg border-[1.5px] border-dashed border-slate-300 text-slate-500 hover:text-teal-700 hover:border-teal-400 grid place-items-center text-[10px] font-bold leading-tight text-center px-1">{busy ? '…' : <span className="flex flex-col items-center gap-0.5"><Plus size={14} />{slides.length === 1 ? 'Make carousel' : 'Add slide'}</span>}</button>}
      </div>
      {busy && <div className="text-[11px] font-bold text-teal-700">{busy}</div>}
      <input ref={ref} type="file" accept="image/*,video/mp4,video/quicktime" multiple hidden onChange={e => { const fs = Array.from(e.target.files || []); if (fs.length) add(fs); e.target.value = '' }} />
    </div>
  )
}

function MediaBox({ media, onChange }: { media?: Media; onChange: (m: Media) => void }) {
  const [busy, setBusy] = useState<string>('')
  const ref = useRef<HTMLInputElement>(null)
  async function pick(f: File) {
    try {
      const m = await uploadOne(f, setBusy)
      onChange(m)
      toast.success(m.mediaType === 'video' ? `Video added · ${Math.round(m.durationSec || 0)}s` : 'Photo added')
    } catch (e: any) { toast.error(String(e?.message || 'Upload failed').replace(/^Error:\s*/, '')) } finally { setBusy('') }
  }
  const dur = media?.durationSec ? `${Math.floor(media.durationSec / 60)}:${String(Math.round(media.durationSec % 60)).padStart(2, '0')}` : ''
  return (
    <div onClick={() => !busy && ref.current?.click()} className={`rounded-2xl border-[1.5px] border-dashed border-slate-300 bg-slate-50 cursor-pointer text-center text-xs text-slate-500 relative ${media?.url ? 'overflow-hidden' : 'p-4'}`}>
      {busy ? <div className="p-4 font-bold text-teal-700">{busy}</div>
        : media?.url ? (media.mediaType === 'video'
          ? <><video src={media.url} poster={media.thumbnailUrl || undefined} controls playsInline onClick={e => e.stopPropagation()} className="w-full max-h-72 object-contain bg-black block" /><span className="absolute top-2 left-2 rounded-md bg-black/70 text-white text-[10px] font-bold px-1.5 py-0.5 inline-flex items-center gap-1"><Film size={10} /> {dur}{media.width && media.height ? ` · ${media.width}×${media.height}` : ''}</span></>
          : <img src={media.url} alt="" className="w-full max-h-56 object-cover block" />)
        : <>Click to add the photo or video (Canva export)<div className="text-[11px] text-slate-400 mt-1">JPG/PNG for a post · MP4 for a Reel or Story</div></>}
      <input ref={ref} type="file" accept="image/*,video/mp4,video/quicktime" hidden onChange={e => { const f = e.target.files?.[0]; if (f) pick(f); e.target.value = '' }} />
    </div>
  )
}

/** Instagram's own music for a Reel. Searches /api/social/audio (trending when
 *  the box is empty), previews a clip, and sets the song + the two volumes. */
function MusicPicker({ song, setSong, autoOpen, videoVolume = 30 }: { song: Song | null; setSong: (s: Song | null) => void; autoOpen?: boolean; videoVolume?: number }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [list, setList] = useState<{ audioId: string; title: string; artist: string; cover: string; durationMs: number; previewUrl: string }[]>([])
  const [playing, setPlaying] = useState('')
  const audioEl = useRef<HTMLAudioElement | null>(null)
  useEffect(() => () => { audioEl.current?.pause() }, [])
  async function search(query: string) {
    setBusy(true); setErr('')
    try { const d = await api(`/api/social/audio?q=${encodeURIComponent(query)}`); setList(d.audio || []) }
    catch (e: any) { setErr(e.message); setList([]) } finally { setBusy(false) }
  }
  function toggle(id: string, url: string) {
    if (!url) { toast('No preview for this one'); return }
    if (playing === id) { audioEl.current?.pause(); setPlaying(''); return }
    audioEl.current?.pause()
    const a = new Audio(url); audioEl.current = a; a.onended = () => setPlaying(''); a.play().then(() => setPlaying(id)).catch(() => toast.error("Couldn't play the preview"))
  }
  const openPicker = () => { setOpen(true); if (!list.length) search('') }
  // A player Reel made without music opens straight onto Instagram's trending list.
  useEffect(() => { if (autoOpen && !song) openPicker() }, []) // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div>
      <label className={labelCls}>Instagram music <span className="normal-case tracking-normal font-semibold text-slate-400">· licensed by Instagram, Reels only</span></label>
      {song ? (
        <div className="rounded-xl border border-slate-200 bg-white p-2.5 flex flex-col gap-2">
          <div className="flex items-center gap-2.5">
            {song.cover ? <img src={song.cover} alt="" className="w-10 h-10 rounded-lg object-cover flex-none" /> : <span className="w-10 h-10 rounded-lg bg-pink-50 text-pink-600 grid place-items-center flex-none"><Music size={16} /></span>}
            <div className="min-w-0 flex-1"><div className="text-sm font-bold truncate">{song.title}</div><div className="text-xs text-slate-500 truncate">{song.artist}{song.durationMs ? ` · ${mmss(song.durationMs)}` : ''}</div></div>
            <button type="button" onClick={openPicker} className="text-xs font-bold text-teal-700 hover:underline">Change</button>
            <button type="button" onClick={() => setSong(null)} className="w-7 h-7 rounded-lg grid place-items-center text-slate-400 hover:text-rose-600" aria-label="Remove song"><X size={14} /></button>
          </div>
          {([['Song volume', 'audioVolume'], ["Video's own sound", 'videoVolume']] as const).map(([lab, k]) => (
            <label key={k} className="flex items-center gap-2 text-[11px] text-slate-600"><span className="w-28 flex-none">{lab}</span><input type="range" min={0} max={100} step={5} value={song[k]} onChange={e => setSong({ ...song, [k]: Number(e.target.value) })} className="flex-1 accent-teal-600" /><span className="w-8 text-right tabular-nums">{song[k]}</span></label>
          ))}
          {song.dropped && <div className="text-[11px] text-amber-700">Last time this song couldn't be attached: {song.dropped}</div>}
        </div>
      ) : !open && <button type="button" onClick={openPicker} className="inline-flex items-center gap-1.5 rounded-xl border border-dashed border-slate-300 px-3 py-2 text-xs font-bold text-slate-600 hover:border-pink-400 hover:text-pink-700"><Music size={14} /> Add a song from Instagram</button>}
      {open && (
        <div className="mt-2 rounded-2xl border border-slate-200 bg-slate-50 p-2.5 flex flex-col gap-2">
          <div className="flex gap-2"><div className="relative flex-1"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" /><input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); search(q) } }} placeholder="Search songs or artists — empty shows trending" className={inputCls + ' !pl-8 !py-2 text-xs'} /></div>
            <button type="button" onClick={() => search(q)} disabled={busy} className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold px-3 disabled:opacity-50">{busy ? '…' : 'Search'}</button>
            <button type="button" onClick={() => { audioEl.current?.pause(); setPlaying(''); setOpen(false) }} className="w-8 rounded-xl text-slate-500 hover:bg-slate-200 grid place-items-center" aria-label="Close music search"><X size={14} /></button></div>
          {err && <div className="text-xs text-rose-700 bg-rose-50 rounded-lg px-2.5 py-2">{err}</div>}
          {!err && !busy && !list.length && <div className="text-xs text-slate-500 px-1">No songs found{q ? ` for "${q}"` : ''}. Instagram only shares part of its library with outside apps.</div>}
          <div className="flex flex-col gap-1 max-h-72 overflow-y-auto">
            {list.map(t => (
              <div key={t.audioId} className="flex items-center gap-2.5 rounded-xl bg-white border border-slate-200 p-1.5">
                <button type="button" onClick={() => toggle(t.audioId, t.previewUrl)} className="relative w-9 h-9 rounded-lg overflow-hidden flex-none bg-slate-200 grid place-items-center" aria-label={playing === t.audioId ? 'Pause preview' : 'Play preview'}>
                  {t.cover && <img src={t.cover} alt="" className="absolute inset-0 w-full h-full object-cover" />}
                  <span className="relative w-6 h-6 rounded-full bg-black/55 text-white grid place-items-center">{playing === t.audioId ? <Pause size={11} /> : <Play size={11} fill="currentColor" />}</span>
                </button>
                <div className="min-w-0 flex-1"><div className="text-xs font-bold truncate">{t.title || 'Untitled'}</div><div className="text-[11px] text-slate-500 truncate">{t.artist}{t.durationMs ? ` · ${mmss(t.durationMs)}` : ''}</div></div>
                <button type="button" onClick={() => { audioEl.current?.pause(); setPlaying(''); setSong({ audioId: t.audioId, title: t.title, artist: t.artist, cover: t.cover, durationMs: t.durationMs, audioVolume: song?.audioVolume ?? 100, videoVolume: song?.videoVolume ?? videoVolume }); setOpen(false) }} className="rounded-lg border border-teal-500 text-teal-700 hover:bg-teal-50 text-xs font-bold px-2.5 py-1">Use</button>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="text-[11px] text-slate-500 mt-1.5">Instagram adds the song when it publishes (it doesn't let apps preview the finished Reel). Facebook and Stories keep the video's own sound. If Instagram pulls the song before then, the Reel still goes out and the post says so.</div>
    </div>
  )
}

type StoryTiming = { mode: 'same' } | { mode: 'offset'; minutes: number } | { mode: 'morning' } | { mode: 'custom'; at: Date }
function storyTimeFor(t: StoryTiming, feed: Date): Date {
  if (t.mode === 'offset') return new Date(feed.getTime() + t.minutes * 60000)
  if (t.mode === 'morning') { const d = new Date(feed); d.setDate(d.getDate() + 1); d.setHours(9, 0, 0, 0); return d }
  if (t.mode === 'custom') return t.at
  return feed
}
interface EditProps { autoSong?: boolean; reelEvents?: IdeaEvent[]; reelSite?: string; song?: Song | null; setSong?: (s: Song | null) => void; slides?: Media[]; setSlides?: (s: Media[]) => void; storyTiming?: StoryTiming; setStoryTiming?: (t: StoryTiming) => void; aiInit?: string; platforms?: string[]; caption: string; setCaption: (s: string) => void; firstComment: string; setFirstComment: (s: string) => void; when: Date; setWhen: (d: Date) => void; media?: Media; setMedia: (m: Media) => void; placements?: Placement[]; setPlacements?: (p: Placement[]) => void; queue: QueueInfo; accounts?: Account[]; acctIds?: string[]; setAcctIds?: (ids: string[]) => void; showFirstComment: boolean; storyOnly?: boolean }
function EditFields({ autoSong, reelEvents, reelSite, song, setSong, slides, setSlides, storyTiming, setStoryTiming, aiInit, platforms, caption, setCaption, firstComment, setFirstComment, when, setWhen, media, setMedia, placements, setPlacements, queue, accounts, acctIds, setAcctIds, showFirstComment, storyOnly }: EditProps) {
  const past = when < new Date()
  const [ai, setAi] = useState<{ open: boolean; brief: string; busy: boolean; options: { label: string; caption: string }[]; hashtags: string }>({ open: !!aiInit, brief: aiInit || '', busy: false, options: [], hashtags: '' })
  const plats = platforms || (accounts ? Array.from(new Set(accounts.filter(a => acctIds?.includes(a.id)).map(a => a.platform))) : ['instagram'])
  async function writeWithAI() {
    setAi(a => ({ ...a, busy: true }))
    try {
      const d = await api('/api/social/caption-assist', { method: 'POST', body: JSON.stringify({ brief: ai.brief, current: caption, platforms: plats, mediaType: media?.mediaType || 'image', placement: placements?.includes('feed') === false ? 'story' : 'feed', imageUrl: media?.mediaType === 'video' ? media.thumbnailUrl : media?.url }) })
      setAi(a => ({ ...a, busy: false, options: d.options || [], hashtags: d.hashtags || '' }))
    } catch (e: any) { toast.error(e.message); setAi(a => ({ ...a, busy: false })) }
  }
  // Opened from an idea: draft straight away so the three options are waiting.
  useEffect(() => { if (aiInit && !storyOnly) writeWithAI() }, []) // eslint-disable-line react-hooks/exhaustive-deps
  const isVideo = media?.mediaType === 'video'
  const carousel = (slides?.length || 0) > 1
  const hasIg = !accounts || accounts.some(a => acctIds?.includes(a.id) && a.platform === 'instagram')
  const hasFb = plats.includes('facebook')
  const both = !!placements && placements.includes('feed') && placements.includes('story')
  const [reelOpen, setReelOpen] = useState(false)
  const nextQueue = queue.next.map(s => new Date(s)).find(d => d > new Date())
  return (
    <>
      {accounts && setAcctIds && (
        <div><label className={labelCls}>Post to</label>
          <div className="flex flex-wrap gap-1.5">{accounts.map(a => { const on = acctIds?.includes(a.id); return (
            <button key={a.id} type="button" onClick={() => setAcctIds(on ? (acctIds || []).filter(x => x !== a.id) : [...(acctIds || []), a.id])} className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-xs font-bold transition ${on ? 'border-teal-500 bg-teal-50 text-teal-800' : 'border-slate-300 text-slate-500 hover:text-slate-900'}`}>
              <span className={`w-4 h-4 rounded-full grid place-items-center ${a.platform === 'instagram' ? 'bg-pink-600' : 'bg-blue-500'}`}>{a.platform === 'instagram' ? <Instagram size={10} className="text-white" /> : <Facebook size={10} className="text-white" />}</span>{a.label}{on && <Check size={12} />}
            </button>) })}</div>
          {(acctIds?.length || 0) > 1 && <div className="text-[11px] text-slate-500 mt-1.5">One post per account — approving one approves the set.</div>}
        </div>
      )}
      <div><div className="flex items-center justify-between mb-1.5"><label className={labelCls + ' !mb-0'}>{carousel ? `Carousel · ${slides!.length} slides` : isVideo ? 'Video' : 'Photo or video'}</label><button type="button" onClick={() => setReelOpen(true)} className="inline-flex items-center gap-1 text-xs font-bold rounded-lg px-2 py-1 text-pink-700 hover:bg-pink-50" title="Turn photos into a Reel with music"><Film size={13} /> Make a Reel</button></div><MediaBox media={media} onChange={setMedia} />
        {reelOpen && <ReelBuilder initialPhotos={(slides || (media ? [media] : [])).filter(x => x.mediaType === 'image').map(x => x.url)} events={reelEvents || []} site={reelSite} onClose={() => setReelOpen(false)} onDone={r => { const m: Media = { ...r, builtIn: true }; if (setSlides) setSlides([m]); else setMedia(m); setReelOpen(false) }} />}
        {slides && setSlides && media?.url && !storyOnly && <div className="mt-2"><SlidesStrip slides={slides} setSlides={setSlides} /></div>}
        {carousel && <div className="text-[11px] text-slate-500 mt-1.5 flex flex-col gap-0.5">
          <span>Instagram crops every slide to slide 1's shape — keep them the same size (e.g. all 1080×1350).</span>
          {hasFb && slides!.some(x => x.mediaType === 'video') && <span className="text-amber-700">Facebook posts the photos as one multi-photo post — video slides are left out there.</span>}
        </div>}
      </div>
      {placements && setPlacements && media?.url && (
        <div><label className={labelCls}>Post as</label>
          <div className="flex flex-wrap gap-1.5">
            {([['feed', carousel ? 'Carousel · feed' : isVideo ? (hasIg ? 'Reel · feed' : 'Video post') : 'Feed post'], ['story', carousel ? 'Story (slide 1)' : 'Story']] as [Placement, string][]).map(([pl, lab]) => { const on = placements.includes(pl); const tooLong = pl === 'story' && isVideo && (media.durationSec || 0) > 60
              return <button key={pl} type="button" disabled={tooLong} title={tooLong ? 'Stories max out at 60 seconds' : ''} onClick={() => setPlacements(on ? placements.filter(x => x !== pl) : [...placements, pl])} className={`rounded-full border px-3 py-1.5 text-xs font-bold disabled:opacity-40 ${on ? 'border-teal-500 bg-teal-50 text-teal-800' : 'border-slate-300 text-slate-500 hover:text-slate-900'}`}>{lab}{on && <Check size={12} className="inline ml-1" />}</button> })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1.5">{isVideo && (media.durationSec || 0) > 60 ? 'Over 60 s, so it can go out as a Reel but not a Story.' : carousel ? 'Pick both and the Story gets slide 1 (a Story takes one photo or video).' : 'Pick both to publish it to the feed and your Story.'}{isVideo && media.width && media.height && Math.abs(media.width / media.height - 9 / 16) > 0.05 ? ` This is ${media.width}×${media.height} — Reels and Stories are 9:16, so it'll show with bars.` : ''}</div>
        </div>
      )}
      {setSong && isVideo && !carousel && plats.includes('instagram') && !storyOnly && (!placements || placements.includes('feed')) && <MusicPicker song={song || null} setSong={setSong} autoOpen={autoSong} videoVolume={media?.builtIn ? 0 : 30} />}
      {!storyOnly && <div>
        <div className="flex items-center justify-between mb-1.5"><label className={labelCls + ' !mb-0'}>Caption</label><button type="button" onClick={() => setAi(a => ({ ...a, open: !a.open }))} className={`inline-flex items-center gap-1 text-xs font-bold rounded-lg px-2 py-1 ${ai.open ? 'bg-violet-100 text-violet-800' : 'text-violet-700 hover:bg-violet-50'}`}><Sparkles size={13} /> Write with AI</button></div>
        <textarea value={caption} onChange={e => setCaption(e.target.value)} maxLength={2200} rows={5} className={inputCls + ' resize-y leading-snug'} placeholder="Write the caption…" /><div className="text-right text-[11px] text-slate-500 mt-1 tabular-nums">{caption.length}/2200</div>
        {ai.open && (
          <div className="mt-2 rounded-2xl border border-violet-200 bg-violet-50/60 p-3 flex flex-col gap-2">
            <div className="text-xs text-violet-900 font-bold flex items-center gap-1.5"><Sparkles size={13} /> {caption.trim() ? 'Improve this caption' : 'Draft a caption'}<span className="font-normal text-violet-700"> · reads the cover frame and your upcoming events</span></div>
            <div className="flex gap-2 items-start"><textarea value={ai.brief} rows={ai.brief.includes('\n') ? 5 : 1} onChange={e => setAi(a => ({ ...a, brief: e.target.value }))} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !ai.brief.includes('\n') && !ai.busy) { e.preventDefault(); writeWithAI() } }} placeholder="Optional: what's the angle? e.g. 31 days out, the bracket is taking shape" className={inputCls + ' !bg-white resize-y text-xs leading-snug'} /><button type="button" onClick={writeWithAI} disabled={ai.busy} className="rounded-xl bg-violet-600 hover:bg-violet-700 text-white text-xs font-bold px-3 py-2 flex-none disabled:opacity-50">{ai.busy ? 'Writing…' : ai.options.length ? 'Again' : 'Write'}</button></div>
            {ai.options.map((o, i) => (
              <button key={i} type="button" onClick={() => { setCaption(o.caption); toast.success(`Using "${o.label}"`) }} className="text-left rounded-xl bg-white border border-slate-200 hover:border-violet-400 px-3 py-2.5">
                <div className="text-[10px] font-extrabold uppercase tracking-wide text-violet-700 mb-1">{o.label}</div>
                <div className="text-sm whitespace-pre-wrap leading-snug text-slate-800">{o.caption}</div>
              </button>
            ))}
            {ai.hashtags && showFirstComment && <button type="button" onClick={() => { setFirstComment(ai.hashtags); toast.success('Hashtags added as the first comment') }} className="text-left rounded-xl bg-white border border-slate-200 hover:border-violet-400 px-3 py-2.5"><div className="text-[10px] font-extrabold uppercase tracking-wide text-violet-700 mb-1">Hashtags → first comment</div><div className="text-xs text-slate-600 leading-snug">{ai.hashtags}</div></button>}
          </div>
        )}
      </div>}
      <div>
        <label className={labelCls}>Publish date</label>
        <input type="datetime-local" value={toLocalInput(when)} onChange={e => e.target.value && setWhen(new Date(e.target.value))} className={inputCls + (past ? ' !border-rose-400 !bg-rose-50' : '')} />
        {past && <div className="text-xs font-bold text-rose-600 mt-1.5">This date has passed. Pick a new one.</div>}
        {both && <div className="text-[11px] text-slate-500 mt-1">{storyTiming && setStoryTiming ? 'This is the feed post’s time — the Story’s is below.' : ''}</div>}
        <div className="flex flex-wrap gap-1.5 mt-2">{nextQueue && <button type="button" onClick={() => setWhen(nextQueue)} className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-bold ${+when === +nextQueue ? 'border-teal-500 text-teal-700 bg-teal-50' : 'border-teal-300 text-teal-700 hover:bg-teal-50'}`}><ListPlus size={12} /> Next queue slot · {fmtDate(nextQueue)} {fmtTime(nextQueue)}</button>}{QUICK_TIMES.map(([h, m]) => { const d = new Date(when); d.setHours(h, m, 0, 0); const on = when.getHours() === h && when.getMinutes() === m; return <button key={`${h}:${m}`} type="button" onClick={() => setWhen(d)} className={`rounded-full border px-2.5 py-1 text-xs font-bold ${on ? 'border-teal-500 text-teal-700 bg-teal-50' : 'border-slate-300 text-slate-500 hover:text-slate-900'}`}>{fmtTime(d)}</button> })}</div>
      </div>
      {both && storyTiming && setStoryTiming && (() => { const st = storyTimeFor(storyTiming, when); const stPast = st < new Date()
        const opts: [string, StoryTiming][] = [['Same time', { mode: 'same' }], ['+2 hours', { mode: 'offset', minutes: 120 }], ['+4 hours', { mode: 'offset', minutes: 240 }], ['Next morning 9:00', { mode: 'morning' }]]
        const isOn = (t: StoryTiming) => t.mode === storyTiming.mode && (t.mode !== 'offset' || (storyTiming.mode === 'offset' && storyTiming.minutes === t.minutes))
        return (
          <div><label className={labelCls}>Story goes out</label>
            <div className="flex flex-wrap gap-1.5">
              {opts.map(([lab, t]) => <button key={lab} type="button" onClick={() => setStoryTiming(t)} className={`rounded-full border px-2.5 py-1 text-xs font-bold ${isOn(t) ? 'border-teal-500 text-teal-700 bg-teal-50' : 'border-slate-300 text-slate-500 hover:text-slate-900'}`}>{lab}</button>)}
              <button type="button" onClick={() => setStoryTiming({ mode: 'custom', at: st })} className={`rounded-full border px-2.5 py-1 text-xs font-bold ${storyTiming.mode === 'custom' ? 'border-teal-500 text-teal-700 bg-teal-50' : 'border-slate-300 text-slate-500 hover:text-slate-900'}`}>Pick a time</button>
            </div>
            {storyTiming.mode === 'custom' && <input type="datetime-local" value={toLocalInput(storyTiming.at)} onChange={e => e.target.value && setStoryTiming({ mode: 'custom', at: new Date(e.target.value) })} className={inputCls + ' mt-2' + (stPast ? ' !border-rose-400 !bg-rose-50' : '')} />}
            <div className={`text-[11px] mt-1.5 ${stPast ? 'text-rose-600 font-bold' : 'text-slate-500'}`}>Story: {fmtDate(st)} at {fmtTime(st)}{stPast ? ' — that time has passed' : storyTiming.mode !== 'same' ? ' · a later Story gives the post a second look' : ''}</div>
          </div>) })()}
      {showFirstComment && !storyOnly && <div><label className={labelCls}>First comment <span className="normal-case tracking-normal font-semibold text-slate-400">· hashtags go here, posted right after publish</span></label><textarea value={firstComment} onChange={e => setFirstComment(e.target.value)} maxLength={2200} rows={2} className={inputCls + ' resize-y leading-snug'} placeholder="#lacrosse #floridalacrosse #monstermash" /></div>}
    </>
  )
}

function PostDrawer({ reelEvents, reelSite, post, metrics, siblings, queue, mode, setMode, canApprove, onClose, onApprove, onPublishNow, onPatch, onDelete }: { reelEvents?: IdeaEvent[]; reelSite?: string; post: Post; metrics?: PostMetrics; siblings: Post[]; queue: QueueInfo; mode: 'preview' | 'edit'; setMode: (m: 'preview' | 'edit') => void; canApprove: boolean; onClose: () => void; onApprove: (p: Post) => void; onPublishNow: (p: Post) => Promise<void>; onPatch: (id: string, body: any, msg?: string) => Promise<boolean>; onDelete: (id: string, msg: string) => void }) {
  const [caption, setCaption] = useState(post.caption)
  const [firstComment, setFirstComment] = useState(post.firstComment || '')
  const [confirmNow, setConfirmNow] = useState(false); const [publishing, setPublishing] = useState(false)
  const [when, setWhen] = useState(new Date(post.scheduledFor))
  const [slides, setSlides] = useState<Media[]>(toSlides(post))
  const [song, setSong] = useState<Song | null>(post.audio || null)
  const med: Media | undefined = slides[0]
  const setMed = (m: Media) => setSlides([m, ...slides.slice(1)])
  const img = med?.url
  const [confirmDel, setConfirmDel] = useState(false)
  useEffect(() => { setCaption(post.caption); setFirstComment(post.firstComment || ''); setWhen(new Date(post.scheduledFor)); setSlides(toSlides(post)); setSong(post.audio || null); setConfirmDel(false); setConfirmNow(false) }, [post.id, post.status, post.caption, post.scheduledFor, post.mediaUrls, post.firstComment, post.thumbnailUrl, post.mediaType])
  const a = post.socialAccount || { platform: 'instagram', label: '' }
  const editable = post.status === 'draft' || post.status === 'scheduled' || post.status === 'failed'
  const dirty = !sameSong(song, post.audio) || caption !== post.caption || firstComment !== (post.firstComment || '') || +when !== +new Date(post.scheduledFor) || slides.map(x => x.url).join('|') !== media(post).join('|') || (med?.thumbnailUrl || '') !== (post.thumbnailUrl || '')
  const save = () => onPatch(post.id, { caption, firstComment, scheduledFor: when.toISOString(), ...slidesBody(slides), ...(!sameSong(song, post.audio) ? { audio: song } : {}) }, 'Saved')
  const isStory = post.placement === 'story'
  const draftSiblings = siblings.filter(s => s.status === 'draft').length
  const statusLine = post.status === 'draft' ? <div className="rounded-xl bg-amber-50 text-amber-800 text-xs font-bold px-3 py-2.5">Needs approval · scheduled for {fmtLong(when)}</div>
    : post.status === 'scheduled' ? <div className="rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-2.5 flex gap-2"><Check size={14} className="flex-none mt-px" />Approved · publishes automatically {fmtLong(when)}</div>
    : post.status === 'failed' ? <div className="rounded-xl bg-rose-50 text-rose-700 text-xs font-bold px-3 py-2.5">{post.lastError || 'Publish failed'}</div>
    : post.status === 'published' ? <div className="rounded-xl bg-slate-100 text-slate-600 text-xs font-bold px-3 py-2.5 flex items-center gap-2 flex-wrap">{post.lastError && <span className="basis-full text-amber-700 font-semibold">{post.lastError}</span>}<span>Published {post.publishedAt ? fmtLong(new Date(post.publishedAt)) : ''}{post.importedAt ? ' · imported' : ''}</span>{post.permalink && <a href={post.permalink} target="_blank" rel="noreferrer" className="ml-auto inline-flex items-center gap-1 text-teal-700 hover:underline">Open on {a.platform === 'instagram' ? 'Instagram' : 'Facebook'} <ExternalLink size={12} /></a>}</div>
    : <div className="rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold px-3 py-2.5">{post.lastError || (post.mediaType === 'video' && a.platform === 'instagram' ? 'Publishing — Instagram is processing the video…' : 'Publishing right now…')}</div>
  return (
    <>
      <DrawerHead title={`${STATUS_LABEL[post.status]} · ${a.platform === 'instagram' ? 'Instagram' : 'Facebook'}${kindLabel(post) ? ` ${kindLabel(post)}` : ''}`} onClose={onClose}>
        {editable && <div className="inline-flex p-1 gap-0.5 rounded-xl bg-slate-100 border border-slate-200">{(['preview', 'edit'] as const).map(m => <button key={m} onClick={() => setMode(m)} className={`px-3 py-1 rounded-lg text-xs font-bold capitalize ${mode === m ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}>{m}</button>)}</div>}
      </DrawerHead>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3.5">
        {statusLine}
        {post.collab && a.platform === 'instagram' && <div className="text-xs text-slate-600 flex flex-col gap-0.5">
          {post.collab.usernames.length > 0 && <div><span className="font-bold text-slate-700">Collab invite:</span> {post.collab.usernames.map(u => '@' + u).join(', ')}{post.collab.dropped && <span className="text-amber-700"> · not sent: {post.collab.dropped}</span>}</div>}
          {!!post.collab.tags?.length && <div><span className="font-bold text-slate-700">Tagged:</span> {post.collab.tags.map(u => '@' + u).join(', ')}{post.collab.droppedTags && <span className="text-amber-700"> · not tagged: {post.collab.droppedTags}</span>}</div>}
        </div>}
        {mode === 'preview' || !editable ? <NativePreview platform={a.platform} label={a.label} caption={caption} imgSrc={img} when={when} mediaType={med?.mediaType || post.mediaType} placement={post.placement} poster={med?.thumbnailUrl} slides={slides} song={song} />
          : <EditFields platforms={[a.platform]} caption={caption} setCaption={setCaption} firstComment={firstComment} setFirstComment={setFirstComment} when={when} setWhen={setWhen} media={med} setMedia={setMed} slides={slides} setSlides={setSlides} song={song} setSong={setSong} reelEvents={reelEvents} reelSite={reelSite} queue={queue} showFirstComment={a.platform === 'instagram'} storyOnly={isStory} />}
        {post.status === 'published' && (metrics
          ? <div className="grid grid-cols-4 gap-2">{[['Reached', metrics.reach], ['Likes', metrics.likes], ['Comments', metrics.comments], [a.platform === 'instagram' ? 'Saves' : 'Shares', a.platform === 'instagram' ? metrics.saves : metrics.shares]].map(([l, v]) => <div key={String(l)} className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2"><div className="text-lg font-extrabold tabular-nums">{fmtNum(Number(v))}</div><div className="text-[10px] uppercase tracking-wide text-slate-500 font-bold">{l}</div></div>)}<div className="col-span-4 text-[11px] text-slate-500">Insights as of {fmtDate(new Date(metrics.fetchedAt))} {fmtTime(new Date(metrics.fetchedAt))} · refreshes every 4 hours</div></div>
          : <div className="text-xs text-slate-500">No insights yet — the next snapshot runs within 4 hours.</div>)}
        {mode === 'preview' && post.firstComment && <div className="text-xs text-slate-400"><span className="font-bold text-slate-500 uppercase tracking-wide text-[10px] mr-1.5">First comment</span>{post.firstComment}</div>}
        {siblings.length > 0 && <div className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2.5 text-xs text-slate-600 flex flex-wrap items-center gap-2"><span className="font-bold text-slate-700">Also going to</span>{siblings.map(s => <span key={s.id} className="inline-flex items-center gap-1"><PlatformBadge platform={s.socialAccount?.platform || ''} size={12} />{s.socialAccount?.label}{s.placement === 'story' ? ' Story' : ''} <span className={STATUS_TEXT[s.status]}>· {STATUS_LABEL[s.status]}</span></span>)}</div>}
        {!img && editable && <div className="text-xs text-slate-500">A photo or video is required — Instagram won’t accept a text-only post, and the automation will mark this failed without one.</div>}
        {post.status === 'publishing' && <div className="text-xs text-slate-500">{a.platform === 'instagram' && post.mediaType === 'video' ? 'Instagram usually finishes a video in 1–2 minutes and this updates on its own. ' : ''}If it's been more than a few minutes, <b>Check now</b> looks on the account and settles it — Published if it's live, safe-to-retry if it never went out.</div>}
      </div>
      <div className="px-4 py-3 border-t border-slate-200 flex flex-wrap gap-2">
        {post.status === 'draft' && canApprove && <button onClick={async () => { if (dirty && !(await save())) return; onApprove({ ...post, scheduledFor: when.toISOString() }) }} disabled={!img || when < new Date()} className="rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-4 py-2.5 disabled:opacity-40">Approve &amp; schedule{draftSiblings ? ` · ${draftSiblings + 1} accounts` : ''}</button>}
        {editable && canApprove && img && !confirmNow && <button onClick={() => setConfirmNow(true)} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-sm px-3 py-2.5 inline-flex items-center gap-1.5" title="Publish this instant instead of waiting for the scheduled time"><Zap size={14} /> Publish now</button>}
        {editable && canApprove && confirmNow && <span className="inline-flex items-center gap-2 text-xs"><span className="text-slate-700 font-bold">Post to {a.label} right now?</span><button disabled={publishing} onClick={async () => { setPublishing(true); if (dirty && !(await save())) { setPublishing(false); return } await onPublishNow(post); setPublishing(false) }} className="rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold px-3 py-1.5 disabled:opacity-50">{publishing ? 'Publishing…' : 'Yes, publish'}</button><button onClick={() => setConfirmNow(false)} className="text-slate-500 font-bold px-2">Not yet</button></span>}
        {post.status === 'failed' && canApprove && <button onClick={async () => { if (dirty && !(await save())) return; const at = when < new Date() ? new Date(Date.now() + 5 * 60000) : when; if (await onPatch(post.id, { action: 'retry', scheduledFor: at.toISOString() }, `Re-queued for ${fmtDate(at)} ${fmtTime(at)}`)) onClose() }} className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm px-4 py-2.5 inline-flex items-center gap-1.5"><RotateCcw size={14} /> Retry</button>}
        {editable && dirty && <button onClick={async () => { if (await save()) setMode('preview') }} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-sm px-4 py-2.5">Save changes</button>}
        {post.status === 'scheduled' && canApprove && <button onClick={() => onPatch(post.id, { action: 'unapprove' }, 'Moved back to needs approval').then(ok => ok && onClose())} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-sm px-4 py-2.5">Unapprove</button>}
        {editable && !confirmDel && <button onClick={() => setConfirmDel(true)} className="rounded-xl text-rose-600 hover:bg-rose-50 font-bold text-sm px-3 py-2.5 inline-flex items-center gap-1.5 ml-auto"><Trash2 size={14} /> {post.status === 'draft' ? 'Decline' : 'Delete'}</button>}
        {editable && confirmDel && <span className="ml-auto inline-flex items-center gap-2 text-xs"><span className="text-slate-600">Remove this post?</span><button onClick={() => onDelete(post.id, 'Removed')} className="rounded-lg bg-rose-500 text-white font-bold px-3 py-1.5">Yes, remove</button><button onClick={() => setConfirmDel(false)} className="text-slate-500 font-bold px-2">Keep</button></span>}
        {post.status === 'publishing' && canApprove && <button onClick={() => onPatch(post.id, { action: 'cancel' }, "Stopped. It won't go out.").then(ok => ok && onClose())} className="rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm px-4 py-2.5">Stop it</button>}
        {post.status === 'publishing' && <button onClick={() => onPatch(post.id, { action: 'check' }).then(ok => ok && toast('Checked the account — status updated'))} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-sm px-4 py-2.5 inline-flex items-center gap-1.5"><RotateCcw size={14} /> Check now</button>}
        {!editable && <button onClick={onClose} className="rounded-xl text-slate-600 hover:bg-slate-100 font-bold text-sm px-4 py-2.5 ml-auto">Close</button>}
      </div>
    </>
  )
}

function ComposeDrawer({ reelEvents, reelSite, when: init, idea, seed, accounts, queue, canApprove, onClose, onSaved }: { reelEvents?: IdeaEvent[]; reelSite?: string; when: Date; idea?: Idea; seed?: ComposeSeed; accounts: Account[]; queue: QueueInfo; canApprove: boolean; onClose: () => void; onSaved: () => Promise<void> }) {
  const [caption, setCaption] = useState(seed?.caption || ''); const [firstComment, setFirstComment] = useState(''); const [when, setWhen] = useState(init); const [slides, setSlides] = useState<Media[]>(seed?.slides || []); const med: Media | undefined = slides[0]; const setMed = (m: Media) => setSlides([m, ...slides.slice(1)]); const [storyTiming, setStoryTiming] = useState<StoryTiming>(seed?.storyTiming || { mode: 'same' }); const [song, setSong] = useState<Song | null>(null); const [placements, setPlacements] = useState<Placement[]>(seed?.placements || (idea?.weight === 'story' ? ['story'] : ['feed'])); const [acctIds, setAcctIds] = useState<string[]>(accounts.filter(a => a.status !== 'disconnected').map(a => a.id)); const [busy, setBusy] = useState(false)
  // A cleared player's post: who to invite as Instagram Collaborators (toggleable), and
  // the 9:16 Story graphic, kept only while the feed graphic is the one it was made for.
  const [collab, setCollab] = useState<string[]>(seed?.collab || [])
  const [tags, setTags] = useState<string[]>(seed?.tags || [])
  const storyMediaUrl = seed?.storyUrl && slides.length === 1 && slides[0]?.url === seed.slides[0]?.url ? seed.storyUrl : ''
  const toIg = accounts.some(a => acctIds.includes(a.id) && a.platform === 'instagram')
  const img = med?.url; const storyOnly = placements.length === 1 && placements[0] === 'story'
  const nextQueue = queue.next.map(s => new Date(s)).find(d => d > new Date())
  const [cMode, setCMode] = useState<'edit' | 'preview'>('edit')
  const previewAcct = accounts.find(a => acctIds.includes(a.id) && a.platform === 'instagram') || accounts.find(a => acctIds.includes(a.id)) || accounts[0]
  async function create(approve: boolean, at: Date = when) {
    if (!acctIds.length) { toast.error('Pick at least one account'); return }
    if (!placements.length) { toast.error('Pick Feed, Story, or both'); return }
    if (!storyOnly && !caption.trim()) { toast.error('Add a caption first'); return }
    if (!img) { toast.error('Add a photo or video first'); return }
    if (at < new Date()) { toast.error('Pick a future date'); return }
    const both = placements.includes('feed') && placements.includes('story')
    const storyAt = both ? storyTimeFor(storyTiming, at) : at
    if (storyAt < new Date()) { toast.error('The Story time has passed — pick a later one'); return }
    setBusy(true)
    try {
      const d = await api('/api/social/posts', { method: 'POST', body: JSON.stringify({ socialAccountIds: acctIds, caption, firstComment, ...slidesBody(slides), placements, scheduledFor: at.toISOString(), ...(song && slides.length === 1 && med?.mediaType === 'video' && placements.includes('feed') ? { audio: song } : {}), ...(both && +storyAt !== +at ? { storyScheduledFor: storyAt.toISOString() } : {}),
        ...(seed ? { player: seed.player } : {}), ...(collab.length && toIg && placements.includes('feed') ? { collaborators: collab } : {}), ...(tags.length && toIg && placements.includes('feed') ? { userTags: tags } : {}), ...(storyMediaUrl && placements.includes('story') ? { storyMediaUrl } : {}) }) })
      const n = acctIds.length * placements.length; const acctNote = (n > 1 ? ` (${n} posts)` : '') + (both && +storyAt !== +at ? ` · Story ${fmtDate(storyAt)} ${fmtTime(storyAt)}` : '')
      if (approve) { await api(`/api/social/posts/${d.post.id}`, { method: 'PATCH', body: JSON.stringify({ action: 'approve' }) }); toast.success(`Scheduled${acctNote} — publishes ${fmtDate(at)} at ${fmtTime(at)}`) }
      else toast.success(`Saved${acctNote} — waiting on approval`)
      await onSaved()
    } catch (e: any) { toast.error(e.message) } finally { setBusy(false) }
  }
  return (
    <>
      <DrawerHead title={seed ? 'New post · cleared player' : idea ? 'New post · from an idea' : 'New post'} onClose={onClose}>
        {img && <div className="inline-flex p-1 gap-0.5 rounded-xl bg-slate-100 border border-slate-200">{(['edit', 'preview'] as const).map(m => <button key={m} onClick={() => setCMode(m)} className={`px-3 py-1 rounded-lg text-xs font-bold capitalize ${cMode === m ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'}`}>{m}</button>)}</div>}
      </DrawerHead>
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3.5">
        {cMode === 'preview' && img && previewAcct ? <>
          {placements.includes('feed') && <div><div className={labelCls}>{slides.length > 1 ? 'Carousel' : med?.mediaType === 'video' && previewAcct.platform === 'instagram' ? 'Reel' : 'Feed post'} · {previewAcct.label}</div><NativePreview platform={previewAcct.platform} label={previewAcct.label} caption={caption} imgSrc={img} when={when} mediaType={med?.mediaType} placement="feed" poster={med?.thumbnailUrl} slides={slides} song={previewAcct.platform === 'instagram' && slides.length === 1 ? song : null} /></div>}
          {placements.includes('story') && <div><div className={labelCls}>Story · {previewAcct.label}</div><NativePreview platform={previewAcct.platform} label={previewAcct.label} caption="" imgSrc={storyMediaUrl || img} when={when} mediaType={storyMediaUrl ? 'image' : med?.mediaType} placement="story" poster={med?.thumbnailUrl} /></div>}
          {firstComment && placements.includes('feed') && <div className="text-xs text-slate-500"><span className="font-bold uppercase tracking-wide text-[10px] mr-1.5">First comment</span>{firstComment}</div>}
        </> : <>{seed && (
          <div className="rounded-xl bg-teal-50 border border-teal-200 px-3 py-2.5 text-xs text-teal-900 flex flex-col gap-1.5">
            <div className="font-bold">Cleared player · {seed.note}</div>
            {seed.collab.length > 0 && placements.includes('feed') ? <>
              <div className="flex flex-wrap items-center gap-1.5"><span className="font-semibold">Instagram Collab invite</span>{seed.collab.map(u => { const on = collab.includes(u); return <button key={u} type="button" onClick={() => setCollab(on ? collab.filter(x => x !== u) : [...collab, u])} className={`rounded-full border px-2 py-0.5 font-bold ${on ? 'border-teal-500 bg-white text-teal-800' : 'border-slate-300 text-slate-400 line-through'}`}>@{u}{on && <Check size={11} className="inline ml-1" />}</button> })}</div>
              {!!seed.tags?.length && <div className="flex flex-wrap items-center gap-1.5"><span className="font-semibold">Tagged in the Reel</span>{seed.tags.map(u => { const on = tags.includes(u); return <button key={u} type="button" onClick={() => setTags(on ? tags.filter(x => x !== u) : [...tags, u])} className={`rounded-full border px-2 py-0.5 font-bold ${on ? 'border-teal-500 bg-white text-teal-800' : 'border-slate-300 text-slate-400 line-through'}`}>@{u}{on && <Check size={11} className="inline ml-1" />}</button> })}</div>}
              <div className="text-teal-800/80">{toIg ? `They get an invite on Instagram; once they accept, the post shows on their profile too.${seed.tags?.length ? ' Instagram allows 3 Collabs, so everyone else is tagged: they get a notification and it shows under their Tagged tab.' : ''} The handles are in the caption either way.` : 'Collab invites are Instagram only. Pick the Instagram account to send them.'}</div>
            </> : seed.collab.length === 0 && seed.player.kind !== 'story' ? <div className="text-teal-800/80">The family didn't give an Instagram handle, so there's no Collab invite.</div> : null}
            {storyMediaUrl && placements.includes('story') && <div className="text-teal-800/80">The Story uses the full-screen 9:16 version.</div>}
            {seed.pickSong && <div className="text-pink-800 font-semibold">This Reel has no music yet: pick a song from Instagram's trending list below. Instagram adds it to the Reel when it publishes (the Story and Facebook copies stay silent).</div>}
            {seed.countdown && localDayKey(when) !== seed.dayKey && <div className="text-amber-800 font-bold">The countdown on this graphic was made for {fmtDate(new Date(seed.dayKey + 'T12:00:00'))}. Posting on a different day? Make it again from the tray so the number matches.</div>}
          </div>
        )}{idea && <IdeaNote idea={idea} onUseStarter={idea.cap && !storyOnly ? () => { setCaption(idea.cap); toast.success('Starter caption added — edit away') } : undefined} />}<EditFields autoSong={!!seed?.pickSong} aiInit={idea?.brief} caption={caption} setCaption={setCaption} firstComment={firstComment} setFirstComment={setFirstComment} when={when} setWhen={setWhen} media={med} setMedia={setMed} slides={slides} setSlides={setSlides} song={song} setSong={setSong} reelEvents={reelEvents} reelSite={reelSite} storyTiming={storyTiming} setStoryTiming={setStoryTiming} placements={placements} setPlacements={setPlacements} storyOnly={storyOnly} queue={queue} accounts={accounts} acctIds={acctIds} setAcctIds={setAcctIds} showFirstComment={accounts.some(a => acctIds.includes(a.id) && a.platform === 'instagram')} /></>}
        <div className="rounded-xl bg-teal-50 border border-teal-200 text-teal-800 text-xs px-3 py-2.5 flex gap-2"><AlertTriangle size={14} className="flex-none mt-px" />{canApprove ? 'Save as a draft to review later, or approve now and it publishes itself at the scheduled time.' : 'Saves as a draft. A director approves it before the automation will publish it.'}</div>
      </div>
      <div className="px-4 py-3 border-t border-slate-200 flex flex-wrap gap-2">
        <button onClick={() => create(false)} disabled={busy} className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm px-4 py-2.5 disabled:opacity-50">Save as draft</button>
        {canApprove && <button onClick={() => create(true)} disabled={busy} className="rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-4 py-2.5 disabled:opacity-50">Save &amp; approve</button>}
        {nextQueue && <button onClick={() => create(canApprove, nextQueue)} disabled={busy} title={`Next open queue slot: ${fmtDate(nextQueue)} ${fmtTime(nextQueue)}`} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-sm px-3 py-2.5 inline-flex items-center gap-1.5 disabled:opacity-50"><ListPlus size={14} /> Add to queue</button>}
        <button onClick={onClose} className="rounded-xl text-slate-600 hover:bg-slate-100 font-bold text-sm px-4 py-2.5 ml-auto">Cancel</button>
      </div>
    </>
  )
}

function IdeaDrawer({ idea, canDraft, onClose, onDraft, onDismiss }: { idea: Idea; canDraft: boolean; onClose: () => void; onDraft: () => void; onDismiss: () => void }) {
  const c = AUD_CLS[idea.aud] || AUD_CLS.all
  const [y, m, d] = idea.date.split('-').map(Number)
  const day = new Date(y, m - 1, d)
  return (
    <>
      <DrawerHead title={`Idea · ${day.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}`} onClose={onClose} />
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        <div>
          <h3 className="text-lg font-extrabold leading-snug">{idea.title}</h3>
          <div className="flex flex-wrap gap-1.5 mt-2 text-[11px] font-bold">
            {!idea.quiet && <span className={`rounded-full px-2 py-0.5 ${c.chip}`}>{AUDIENCE_LABEL[idea.aud]}</span>}
            {idea.eventShort && idea.phase !== 'off' && <span className="rounded-full px-2 py-0.5 bg-slate-800 text-white">{idea.phase === 'live' ? `${idea.eventShort} · game day` : idea.phase === 'recap' ? `${idea.eventShort} recap` : `${idea.days}d · ${idea.eventShort}`}</span>}
            <span className="rounded-full px-2 py-0.5 bg-slate-100 text-slate-600">{PHASE_LABEL[idea.phase]}</span>
            {idea.lg && <span className="rounded-full px-2 py-0.5 bg-teal-50 text-teal-800">{leagueName(idea.lg)} tie-in</span>}
          </div>
        </div>
        <div><div className={labelCls}>Why this day</div><p className="text-sm text-slate-700 leading-relaxed">{idea.why}</p></div>
        {!idea.quiet && <div className="grid grid-cols-2 gap-px bg-slate-200 border border-slate-200 rounded-xl overflow-hidden text-sm">
          {[['Audience', AUDIENCE_LABEL[idea.aud]], ['Format', idea.fmt], ['Post as', idea.weight === 'story' ? 'Story' : idea.fmt === 'Reel' ? 'Feed (Reel)' : 'Feed'], ['Suggested time', hhmm(idea.time)]].map(([k, v]) => <div key={k} className="bg-white px-3 py-2"><div className="text-[11px] text-slate-500">{k}</div><div className="font-bold">{v}</div></div>)}
        </div>}
        <div><div className={labelCls}>Hook</div><div className="text-base font-bold border-l-[3px] border-teal-600 pl-2.5">{idea.hook}</div></div>
        {idea.shots.length > 0 && <div><div className={labelCls}>What to shoot or pull</div><ul className="list-disc pl-5 text-sm text-slate-700 flex flex-col gap-1">{idea.shots.map((s, i) => <li key={i}>{s}</li>)}</ul></div>}
        {idea.cap && <div><div className={labelCls}>Caption starter</div><div className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2.5 text-sm text-slate-700 whitespace-pre-wrap">{idea.cap}</div></div>}
        <p className="text-[11px] text-slate-400">Ideas are suggestions. Nothing is scheduled until you draft it, add the photo or video, and approve it.</p>
      </div>
      <div className="px-4 py-3 border-t border-slate-200 flex flex-wrap gap-2">
        {idea.quiet ? <button onClick={onClose} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-sm px-4 py-2.5">Got it</button>
          : <button onClick={onDraft} disabled={!canDraft} title={canDraft ? '' : 'Connect an account first'} className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm px-4 py-2.5 inline-flex items-center gap-1.5 disabled:opacity-40"><Sparkles size={14} /> Draft with AI</button>}
        <button onClick={onDismiss} className="rounded-xl text-slate-500 hover:bg-slate-100 font-bold text-sm px-3 py-2.5 ml-auto">Not for us</button>
      </div>
    </>
  )
}

function IdeaNote({ idea, onUseStarter }: { idea: Idea; onUseStarter?: () => void }) {
  return (
    <div className="rounded-2xl border border-teal-200 bg-teal-50/60 px-3 py-2.5 text-xs text-slate-700 flex flex-col gap-1.5">
      <div className="font-bold text-teal-900 flex items-center gap-1.5"><Lightbulb size={13} /> {idea.title} <span className="font-normal text-teal-800">· {AUDIENCE_LABEL[idea.aud]} · {idea.fmt}</span></div>
      {idea.shots.length > 0 && <div><span className="font-bold text-slate-600">Add: </span>{idea.shots.join(' · ')}</div>}
      {idea.weight === 'story' && idea.hook && <div><span className="font-bold text-slate-600">Sticker text: </span>{idea.hook}</div>}
      {idea.fmt === 'Carousel' && <div className="text-slate-600">Add the first slide, then “Make carousel” to add the rest (up to 10).</div>}
      {onUseStarter && <button type="button" onClick={onUseStarter} className="self-start text-teal-800 font-bold hover:underline">Use the starter caption instead</button>}
    </div>
  )
}

function AccountsDrawer({ accounts, configured, queue, canManage, onClose, onChanged }: { accounts: Account[]; configured: boolean; queue: QueueInfo; canManage: boolean; onClose: () => void; onChanged: () => Promise<void> }) {
  const [confirmId, setConfirmId] = useState<string | null>(null)
  const [importing, setImporting] = useState(false)
  async function importHistory() {
    setImporting(true)
    try {
      const d = await api('/api/social/import-history', { method: 'POST', body: JSON.stringify({ limit: 60 }) })
      const errs = (d.accounts || []).filter((a: any) => a.error)
      toast.success(d.imported ? `Imported ${d.imported} post${d.imported === 1 ? '' : 's'} · ${d.snapshotted} with insights` : 'Nothing new to import — already up to date')
      errs.forEach((a: any) => toast.error(`${a.account}: ${a.error}`))
      await onChanged()
    } catch (e: any) { toast.error(e.message) } finally { setImporting(false) }
  }
  const [slots, setSlots] = useState<QueueSlot[]>(queue.slots)
  const [savingSlots, setSavingSlots] = useState(false)
  useEffect(() => { setSlots(queue.slots) }, [queue.slots])
  const slotsDirty = JSON.stringify(slots) !== JSON.stringify(queue.slots)
  async function saveSlots() {
    setSavingSlots(true)
    try { await api('/api/social/queue', { method: 'PUT', body: JSON.stringify({ slots, tzOffsetMin: new Date().getTimezoneOffset() }) }); toast.success('Queue times saved'); await onChanged() } catch (e: any) { toast.error(e.message) } finally { setSavingSlots(false) }
  }
  async function disconnect(id: string) {
    try { await api(`/api/social/accounts?id=${encodeURIComponent(id)}`, { method: 'DELETE' }); toast.success('Disconnected — its scheduled posts moved back to needs approval'); setConfirmId(null); await onChanged() } catch (e: any) { toast.error(e.message) }
  }
  return (
    <>
      <DrawerHead title="Accounts & queue times" onClose={onClose} />
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        <div className={labelCls}>Connected accounts</div>
        {!accounts.length && <div className="text-sm text-slate-500">Nothing connected yet.</div>}
        {accounts.map(a => {
          const days = a.tokenExpiresAt ? Math.round((new Date(a.tokenExpiresAt).getTime() - Date.now()) / 864e5) : null
          const healthy = a.status === 'active'
          return (
            <div key={a.id} className="rounded-2xl bg-slate-50 border border-slate-200 p-3 flex items-center gap-3">
              <span className={`w-10 h-10 rounded-xl grid place-items-center flex-none ${a.platform === 'instagram' ? 'bg-pink-600' : 'bg-blue-500'}`}>{a.platform === 'instagram' ? <Instagram size={18} className="text-white" /> : <Facebook size={18} className="text-white" />}</span>
              <div className="min-w-0 flex-1"><div className="text-sm font-extrabold truncate">{a.label}</div><div className="text-[11px] text-slate-500 truncate">{a.platform === 'instagram' ? 'Instagram' : 'Facebook Page'}{days !== null ? ` · access renews in ${days} days` : ''}{!healthy && a.lastError ? ` · ${a.lastError}` : ''}</div></div>
              <span className={`text-[11px] font-bold ${healthy ? 'text-emerald-700' : 'text-rose-600'}`}>{healthy ? 'Healthy' : a.status}</span>
              {canManage && (confirmId === a.id
                ? <button onClick={() => disconnect(a.id)} className="text-[11px] font-bold rounded-lg bg-rose-500 text-white px-2 py-1">Confirm</button>
                : <button onClick={() => setConfirmId(a.id)} className="text-slate-400 hover:text-rose-600" title="Disconnect"><X size={15} /></button>)}
            </div>
          )
        })}
        {canManage && (
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="text-sm font-extrabold mb-1">{accounts.length ? 'Add another account' : 'Connect Instagram + Facebook'}</div>
            <div className="text-xs text-slate-500 mb-3">You’ll be sent to Meta to sign in as the Page admin. Every Page you manage (and the Instagram account linked to it) gets connected. Because these are your own accounts there’s no app-review wait.</div>
            {configured ? <a href="/api/social/connect" className="inline-flex rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm px-4 py-2.5">Continue with Meta</a>
              : <div className="text-xs text-amber-800">Add META_APP_ID and META_APP_SECRET in Vercel first — see SOCIAL-SCHEDULER.md.</div>}
          </div>
        )}
        {canManage && accounts.length > 0 && (
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 flex items-center gap-3">
            <div className="min-w-0 flex-1"><div className="text-sm font-extrabold">Import post history</div><div className="text-xs text-slate-500">Pulls the last 60 posts from each account into the calendar, with reach and likes, so insights cover everything — not just posts made here. Safe to run again; it only adds what's new.</div></div>
            <button onClick={importHistory} disabled={importing} className="rounded-xl bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 font-bold text-xs px-3 py-2 inline-flex items-center gap-1.5 flex-none disabled:opacity-50"><Download size={13} /> {importing ? 'Importing…' : 'Import'}</button>
          </div>
        )}
        <div className={labelCls + ' mt-3'}>Queue times</div>
        <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3 flex flex-col gap-2">
          <div className="text-xs text-slate-500 flex gap-2"><Clock size={14} className="flex-none mt-px" /><span>"Add to queue" drops a post into the next one of these that's still open. Times are in your local time zone.</span></div>
          {slots.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <select value={s.dow} disabled={!canManage} onChange={e => setSlots(slots.map((x, j) => j === i ? { ...x, dow: +e.target.value } : x))} className={inputCls + ' !w-auto !py-1.5'}>{DOW.map((d, di) => <option key={di} value={di}>{d}</option>)}</select>
              <input type="time" disabled={!canManage} value={`${String(s.h).padStart(2, '0')}:${String(s.m).padStart(2, '0')}`} onChange={e => { const [h, m] = e.target.value.split(':').map(Number); if (!isNaN(h)) setSlots(slots.map((x, j) => j === i ? { ...x, h, m: m || 0 } : x)) }} className={inputCls + ' !w-auto !py-1.5'} />
              {canManage && <button onClick={() => setSlots(slots.filter((_, j) => j !== i))} className="text-slate-400 hover:text-rose-600 ml-auto" title="Remove"><X size={15} /></button>}
            </div>
          ))}
          {canManage && <div className="flex gap-2 pt-1"><button onClick={() => setSlots([...slots, { dow: 2, h: 11, m: 0 }])} className="rounded-lg bg-white border border-slate-300 text-slate-700 text-xs font-bold px-3 py-1.5 inline-flex items-center gap-1"><Plus size={12} /> Add time</button>{slotsDirty && <button onClick={saveSlots} disabled={savingSlots || !slots.length} className="rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold px-3 py-1.5 disabled:opacity-50">{savingSlots ? 'Saving…' : 'Save queue times'}</button>}</div>}
          {queue.next.length > 0 && <div className="text-[11px] text-slate-500 pt-1">Next open: {queue.next.slice(0, 3).map(s => `${fmtDate(new Date(s))} ${fmtTime(new Date(s))}`).join(' · ')}</div>}
        </div>
      </div>
      <div className="px-4 py-3 border-t border-slate-200 flex"><button onClick={onClose} className="rounded-xl text-slate-600 hover:bg-slate-100 font-bold text-sm px-4 py-2.5 ml-auto">Close</button></div>
    </>
  )
}
