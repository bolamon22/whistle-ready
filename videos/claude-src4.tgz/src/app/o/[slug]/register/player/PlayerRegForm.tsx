'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import toast, { Toaster } from 'react-hot-toast'
import { CheckCircle2, Shield, ChevronDown, Check, Camera, Download, ExternalLink, Link2, Printer } from 'lucide-react'
import { cardPrintCss, CARD_PRINT_NOTE } from '@/lib/cardPrint'
import { USA_LACROSSE_LABEL, USA_LACROSSE_SHORT, USA_LACROSSE_LOOKUP, USA_LACROSSE_LOOKUP_TEXT } from '@/lib/usaLacrosse'
import { uploadPlayerPhoto, uploadClubLogo } from '@/lib/photoClient'
import { cleanCardLink, qrLabelFor } from '@/lib/cardLink'
import { track } from '@/lib/track'
import type { PassCardData, CardTheme } from '@/lib/playerPassCard'
import { SAMPLE_PLAYER } from '@/lib/samplePlayerCard'
import CardPreview from './CardPreview'
import ParentAccountOffer from '@/components/ParentAccountOffer'
import HowToVideoLink from '@/components/HowToVideoLink'
import WaiverPrefillBar from '@/components/WaiverPrefillBar'
import type { AccountOffer } from '@/lib/parentWaiverFields'
import { TERMS_VERSION } from '@/lib/termsVersion'

type Fields = { gender: boolean; grade: boolean; teamName: boolean; parent2: boolean; hotelQuestion: boolean; newsletter: boolean; playerPass?: boolean; position?: boolean; homeTown?: boolean }
const inputCls = 'w-full border border-slate-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400'
const labelCls = 'block text-sm font-medium text-slate-700 mb-1'
const GRADES = ['K', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
export const POSITIONS = ['Attack', 'Midfield', 'Defense', 'Goalie', 'FOGO', 'LSM', 'Multiple / not sure']

// `id` distinguishes two teams a club gave the same name -- see the note in
// tournaments/[id]/player-waiver/page.tsx. The dropdown's value is the id; the
// name is what gets submitted and printed on the card.
export type ClubOption = { name: string; logoUrl?: string; basedIn?: string; teams: { id: string; name: string; division: string }[] }

// WHY WE ASK WHERE A FAMILY IS FROM: the county sports commissions that fund these
// events pay on out-of-area visitors, and the grant agreements require the
// REGISTRATION FORM to capture it -- it cannot be reconstructed afterwards. See
// the hotel question above it, which exists for the same reason.
//
// The cost of asking is the thing to manage, not whether to ask. Three separate
// mitigations, in order of how much work each saves a parent:
//   1. prefilled from the club's own home town the moment they pick their team,
//      so most families only confirm;
//   2. proper autoComplete, so a phone offers the saved address in one tap;
//   3. a state dropdown rather than free text, which also keeps the grant report
//      from having to reconcile "FL", "Fla." and "Florida".
const US_STATES: [string, string][] = [
  ['AL', 'Alabama'], ['AK', 'Alaska'], ['AZ', 'Arizona'], ['AR', 'Arkansas'], ['CA', 'California'],
  ['CO', 'Colorado'], ['CT', 'Connecticut'], ['DE', 'Delaware'], ['DC', 'District of Columbia'],
  ['FL', 'Florida'], ['GA', 'Georgia'], ['HI', 'Hawaii'], ['ID', 'Idaho'], ['IL', 'Illinois'],
  ['IN', 'Indiana'], ['IA', 'Iowa'], ['KS', 'Kansas'], ['KY', 'Kentucky'], ['LA', 'Louisiana'],
  ['ME', 'Maine'], ['MD', 'Maryland'], ['MA', 'Massachusetts'], ['MI', 'Michigan'], ['MN', 'Minnesota'],
  ['MS', 'Mississippi'], ['MO', 'Missouri'], ['MT', 'Montana'], ['NE', 'Nebraska'], ['NV', 'Nevada'],
  ['NH', 'New Hampshire'], ['NJ', 'New Jersey'], ['NM', 'New Mexico'], ['NY', 'New York'],
  ['NC', 'North Carolina'], ['ND', 'North Dakota'], ['OH', 'Ohio'], ['OK', 'Oklahoma'], ['OR', 'Oregon'],
  ['PA', 'Pennsylvania'], ['PR', 'Puerto Rico'], ['RI', 'Rhode Island'], ['SC', 'South Carolina'],
  ['SD', 'South Dakota'], ['TN', 'Tennessee'], ['TX', 'Texas'], ['UT', 'Utah'], ['VT', 'Vermont'],
  ['VA', 'Virginia'], ['WA', 'Washington'], ['WV', 'West Virginia'], ['WI', 'Wisconsin'], ['WY', 'Wyoming'],
]

/**
 * Pull a city and state out of a club's free-text "based in".
 *
 * Returns null rather than guessing. "Coral Springs, FL" and "Coral Springs,
 * Florida" both resolve; "South Florida" and "Tri-State" do not, and a family
 * from one of those clubs simply types their own town -- which beats prefilling
 * a made-up city into a field that ends up in a county's grant report.
 */
function parseBasedIn(raw: string | undefined): { city: string; state: string } | null {
  const m = /^\s*(.+?)\s*,\s*([A-Za-z.\s]+?)\s*$/.exec(String(raw || ''))
  if (!m) return null
  const city = m[1].trim()
  const t = m[2].replace(/\./g, '').trim().toLowerCase()
  const hit = US_STATES.find(([code, name]) => code.toLowerCase() === t || name.toLowerCase() === t)
  return city && hit ? { city, state: hit[0] } : null
}
export type FormHeader = { logoUrl: string; title: string; eyebrow?: string }
/**
 * A REAL card, loaded by token, shown as the example.
 *
 * Carries its own two QR urls rather than reusing the form's, because the whole
 * point is that the example is that player's actual card -- their link and the
 * org's, not a placeholder pointing back at this page.
 */
export type SampleCard = { card: Omit<PassCardData, 'qrDataUrl' | 'qr2DataUrl'>; qrUrl: string; qr2Url: string }

/** What the live card preview needs that the form doesn't collect: event + org branding, and the event QR. */
export type CardContext = { tournamentName: string; tournamentLogoUrl: string; tournamentDates: string; location: string; orgName: string; orgLogoUrl: string; orgSite: string; eventQrUrl: string; eventQrLabel: string; theme: CardTheme }

// Club identity beside the picker and in the header: the club's logo when its director uploaded
// one at team registration, otherwise an initials badge in a color picked from the name.
const BADGE_COLORS = ['bg-teal-600', 'bg-blue-600', 'bg-indigo-600', 'bg-violet-600', 'bg-rose-600', 'bg-orange-500', 'bg-emerald-600', 'bg-slate-700']
function initials(name: string) { const w = name.trim().split(/\s+/).filter(Boolean); return ((w[0]?.[0] || '') + (w[1]?.[0] || '')).toUpperCase() || '?' }
function badgeColor(name: string) { let h = 0; for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return BADGE_COLORS[h % BADGE_COLORS.length] }
function ClubMark({ name, logoUrl, size }: { name: string; logoUrl?: string; size: 'sm' | 'lg' }) {
  const box = size === 'lg' ? 'w-10 h-10 rounded-lg text-sm' : 'w-7 h-7 rounded-md text-[11px]'
  if (logoUrl) return <img src={logoUrl} alt="" className={`${box} object-contain bg-white p-0.5`} />
  return <span className={`${box} ${badgeColor(name)} text-white font-extrabold flex items-center justify-center`}>{initials(name)}</span>
}
const OTHER = '__other'

// The club picker is a custom dropdown (not a native <select>) so each row can show the club's
// logo. Keyboard: arrows move, Enter/Space picks, Escape closes, typing a letter jumps.
function ClubPicker({ clubs, value, otherName, onChange }: { clubs: ClubOption[]; value: string; otherName: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(-1)
  const ref = useRef<HTMLDivElement>(null)
  const listRef = useRef<HTMLUListElement>(null)
  const options: { value: string; label: string; logoUrl?: string }[] = [...clubs.map(c => ({ value: c.name, label: c.name, logoUrl: c.logoUrl })), { value: OTHER, label: 'Other / not listed' }]
  const selected = clubs.find(c => c.name === value)
  useEffect(() => {
    if (!open) return
    const onDoc = (e: MouseEvent | TouchEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener('mousedown', onDoc); document.addEventListener('touchstart', onDoc)
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('touchstart', onDoc) }
  }, [open])
  useEffect(() => {
    if (!open || active < 0) return
    listRef.current?.children[active]?.scrollIntoView?.({ block: 'nearest' })
  }, [open, active])
  const openAt = (i: number) => { setActive(i); setOpen(true) }
  const pick = (v: string) => { onChange(v); setOpen(false) }
  const onKeyDown = (e: React.KeyboardEvent) => {
    const cur = active >= 0 ? active : Math.max(0, options.findIndex(o => o.value === value))
    if (e.key === 'ArrowDown') { e.preventDefault(); openAt(open ? Math.min(options.length - 1, cur + 1) : cur) }
    else if (e.key === 'ArrowUp') { e.preventDefault(); openAt(open ? Math.max(0, cur - 1) : cur) }
    else if (e.key === 'Home' && open) { e.preventDefault(); setActive(0) }
    else if (e.key === 'End' && open) { e.preventDefault(); setActive(options.length - 1) }
    else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); if (open && active >= 0) pick(options[active].value); else openAt(cur) }
    else if (e.key === 'Escape' && open) { e.preventDefault(); setOpen(false) }
    else if (e.key.length === 1 && /\S/.test(e.key)) {
      const k = e.key.toLowerCase(), start = open ? cur + 1 : 0
      const i = [...options.keys()].map(j => (start + j) % options.length).find(j => options[j].label.toLowerCase().startsWith(k))
      if (i !== undefined) { if (open) setActive(i); else pick(options[i].value) }
    }
  }
  const mark = value === OTHER && !otherName.trim()
    ? <span className="w-7 h-7 rounded-md bg-slate-100 text-slate-400 flex items-center justify-center"><Shield size={15} /></span>
    : value ? <ClubMark name={selected ? selected.name : otherName} logoUrl={selected?.logoUrl} size="sm" />
    : <span className="w-7 h-7 rounded-md bg-slate-100 text-slate-400 flex items-center justify-center"><Shield size={15} /></span>
  const label = value === OTHER ? 'Other / not listed' : selected ? selected.name : 'Select your club…'
  return (
    <div ref={ref} className="relative">
      <button type="button" role="combobox" aria-expanded={open} aria-haspopup="listbox" aria-controls="club-picker-list" onClick={() => (open ? setOpen(false) : openAt(Math.max(0, options.findIndex(o => o.value === value))))} onKeyDown={onKeyDown}
        className={`${inputCls} pl-11 pr-9 text-left flex items-center ${open ? 'ring-2 ring-teal-400 border-teal-400' : ''}`}>
        <span className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none">{mark}</span>
        <span className={`truncate ${value ? 'text-slate-900' : 'text-slate-500'}`}>{label}</span>
        <ChevronDown size={16} className={`absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <ul ref={listRef} id="club-picker-list" role="listbox" className="absolute z-20 left-0 right-0 mt-1 max-h-72 overflow-y-auto bg-white border border-slate-200 rounded-xl shadow-lg p-1.5">
          {options.map((o, i) => {
            const isSel = o.value === value
            return (
              <li key={o.value} role="option" aria-selected={isSel} onMouseEnter={() => setActive(i)} onMouseDown={e => e.preventDefault()} onClick={() => pick(o.value)}
                className={`flex items-center gap-2.5 px-2 py-2 rounded-lg cursor-pointer text-sm select-none ${active === i ? 'bg-teal-50 text-teal-900' : 'text-slate-800'} ${o.value === OTHER ? 'text-slate-500' : ''}`}>
                {o.value === OTHER
                  ? <span className="w-7 h-7 rounded-md bg-slate-100 text-slate-400 flex items-center justify-center"><Shield size={15} /></span>
                  : <ClubMark name={o.label} logoUrl={o.logoUrl} size="sm" />}
                <span className="truncate">{o.label}</span>
                {isSel && <Check size={16} className="ml-auto text-teal-600 flex-none" />}
              </li>
            )
          })}
        </ul>
      )}
    </div>
  )
}

// The player card extras (tournament forms with the org's "Player pass" switch on): an
// optional photo, and the link the card's QR code should open. Both can be changed later
// from the card page. Photo prep + upload live in src/lib/photoClient.ts.
/** Yours / Example switch above the live card. Two render sites, one control. */
function CardViewSwitch({ view, onPick, className = '' }: { view: 'example' | 'yours'; onPick: (v: 'example' | 'yours') => void; className?: string }) {
  const btn = (v: 'example' | 'yours', label: string) => (
    <button type="button" onClick={() => onPick(v)} aria-pressed={view === v}
      className={`px-2.5 py-1 rounded-full text-[11.5px] font-bold transition-colors ${view === v ? 'bg-slate-900 text-white' : 'text-slate-500 hover:text-slate-700'}`}>
      {label}
    </button>
  )
  return (
    <div className={`inline-flex items-center gap-0.5 rounded-full bg-slate-100 p-0.5 ${className}`}>
      {btn('yours', 'Yours')}
      {btn('example', 'Example')}
    </div>
  )
}

function CardFields({ photoUrl, cardLink, onPhoto, onLink, preview, qrText, qr2Text, theme, clubLogo, view, onPickView }: {
  photoUrl: string; cardLink: string; onPhoto: (url: string) => void; onLink: (url: string) => void
  preview: Omit<PassCardData, 'qrDataUrl' | 'qr2DataUrl'>; qrText: string; qr2Text: string; theme: CardTheme
  /** Offer a club-logo upload when the chosen club has none (or was typed in). */
  clubLogo?: { clubName: string; url: string; onChange: (url: string) => void }
  view: 'example' | 'yours'; onPickView: (v: 'example' | 'yours') => void
}) {
  const [busy, setBusy] = useState(false)
  const [logoBusy, setLogoBusy] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const logoRef = useRef<HTMLInputElement>(null)
  async function pick(file: File) {
    setBusy(true)
    try { onPhoto(await uploadPlayerPhoto(file)) }
    catch (e: any) { toast.error(e?.message || 'Could not upload the photo') }
    finally { setBusy(false); if (inputRef.current) inputRef.current.value = '' }
  }
  async function pickLogo(file: File) {
    if (!clubLogo) return
    setLogoBusy(true)
    try { clubLogo.onChange(await uploadClubLogo(file)) }
    catch (e: any) { toast.error(e?.message || 'Could not upload the logo') }
    finally { setLogoBusy(false); if (logoRef.current) logoRef.current.value = '' }
  }
  return (
    <div className="mb-4 pb-4 border-b border-slate-100">
      {/* On phones and tablets the live card sits right here; on wide screens it rides along in the side column. */}
      <div className="lg:hidden mb-4">
        <div className="flex justify-center mb-2"><CardViewSwitch view={view} onPick={onPickView} /></div>
        <CardPreview p={preview} qrText={qrText} qr2Text={qr2Text} theme={theme} className="w-56 mx-auto rounded-xl shadow-lg ring-1 ring-slate-200" />
        <p className="text-center text-xs text-slate-400 mt-2">
          {view === 'example' ? 'An example of a finished card. Yours builds itself as you type.' : 'Your card builds itself as you type.'}
        </p>
      </div>
      {clubLogo && (
        <div className="flex items-center gap-4 mb-4">
          <button type="button" onClick={() => logoRef.current?.click()} disabled={logoBusy} aria-label={clubLogo.url ? 'Change club logo' : 'Add club logo'}
            className="relative flex-none w-16 h-16 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 overflow-hidden flex items-center justify-center text-slate-400 disabled:opacity-60">
            {clubLogo.url ? <img src={clubLogo.url} alt="" className="w-full h-full object-contain p-1" /> : <Shield size={22} />}
            {logoBusy && <span className="absolute inset-0 bg-white/75 flex items-center justify-center text-[10px] font-semibold text-slate-600">Uploading…</span>}
          </button>
          <div className="text-sm min-w-0">
            <div className="font-medium text-slate-700">{clubLogo.clubName ? `${clubLogo.clubName} logo` : 'Club logo'} <span className="text-slate-400 font-normal">(optional)</span></div>
            <p className="text-slate-500 text-xs mt-0.5 leading-relaxed">We don't have a logo for this club yet — add one and it goes on the card{clubLogo.clubName ? ' (and on every card for the club)' : ''}.</p>
            <div className="mt-1.5 flex gap-3 text-xs font-semibold">
              <button type="button" onClick={() => logoRef.current?.click()} disabled={logoBusy} className="text-teal-700 hover:underline">{clubLogo.url ? 'Change logo' : 'Add logo'}</button>
              {clubLogo.url && <button type="button" onClick={() => clubLogo.onChange('')} className="text-slate-500 hover:underline">Remove</button>}
            </div>
          </div>
          <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) pickLogo(f) }} />
        </div>
      )}
      <div className="flex items-center gap-4">
        <button type="button" onClick={() => inputRef.current?.click()} disabled={busy} aria-label={photoUrl ? 'Change player photo' : 'Add player photo'}
          className="relative flex-none w-24 h-24 rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 hover:bg-slate-100 overflow-hidden flex items-center justify-center text-slate-400 disabled:opacity-60">
          {photoUrl ? <img src={photoUrl} alt="" className="w-full h-full object-cover" /> : <Camera size={28} />}
          {busy && <span className="absolute inset-0 bg-white/75 flex items-center justify-center text-xs font-semibold text-slate-600">Uploading…</span>}
        </button>
        <div className="text-sm min-w-0">
          <div className="font-medium text-slate-700">Player photo <span className="text-slate-400 font-normal">(optional)</span></div>
          {/* Was "Take one now or pick from your photos", which reads like a
              passport application and got passport-looking photos. Naming action
              shots and celebrations gives permission for the picture a kid
              actually wants on their card (Bo, Sep 18 2026), and "swap it any
              time" removes the pressure to get it right at a red light. */}
          <p className="text-slate-500 text-xs mt-0.5 leading-relaxed">Goes on the player card. A headshot, an action shot, a goal celebration — whatever they&rsquo;d want on it. Swap it any time.</p>
          <div className="mt-1.5 flex gap-3 text-xs font-semibold">
            <button type="button" onClick={() => inputRef.current?.click()} disabled={busy} className="text-teal-700 hover:underline">{photoUrl ? 'Change photo' : 'Add photo'}</button>
            {photoUrl && <button type="button" onClick={() => onPhoto('')} className="text-slate-500 hover:underline">Remove</button>}
          </div>
        </div>
        <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) pick(f) }} />
      </div>
      <div className="mt-3">
        <label className={labelCls}><span className="inline-flex items-center gap-1.5"><Link2 size={14} className="text-slate-400" /> Link for the card's QR code <span className="text-slate-400 font-normal">(optional)</span></span></label>
        <input className={inputCls} value={cardLink} onChange={e => onLink(e.target.value)} inputMode="url" placeholder="Highlight reel, Instagram, Hudl… e.g. https://youtube.com/…" />
        <p className="text-xs text-slate-400 mt-1">Leave blank and the code opens the player's card.</p>
      </div>
    </div>
  )
}

export default function PlayerRegForm({ orgId, fields, waiverTitle, waiverHtml, confirmationTitle, confirmationHtml, teams, clubs, tournamentId, tournamentName, header, cardContext, sampleCard, howTo = false }: { orgId: string; fields: Fields; waiverTitle: string; waiverHtml: string; confirmationTitle: string; confirmationHtml: string; teams?: string[]; clubs?: ClubOption[]; tournamentId?: string; tournamentName?: string; header?: FormHeader; cardContext?: CardContext; sampleCard?: SampleCard
  /** Show the "Watch how" waiver video link (lib/howToVideos: only the org the video is branded for). */
  howTo?: boolean }) {
  // Tournament forms pass the registered clubs with their teams: the parent picks the club,
  // then the team on it, and we store "Club — Team" so staff rosters line up exactly.
  const clubMode = !!clubs && clubs.length > 0
  const [submitting, setSubmitting] = useState(false)
  const [done, setDone] = useState(false)
  const [passToken, setPassToken] = useState('')   // set when the submission got a player pass
  const [account, setAccount] = useState<AccountOffer | null>(null)   // "save your info": a password for the parent email, or already in their account
  const [d, setD] = useState<any>({
    playerName: '', playerEmail: '', usLacrosse: '', dob: '', gender: '', grade: '', teamName: '', teamOther: '', clubName: '', teamPick: '', notListed: false, jerseyNumber: '', position: '', photoUrl: '', cardLink: '', clubLogoUrl: '',
    parentName: '', parentEmail: '', parentPhone: '', homeCity: '', homeState: '',
    parent2Name: '', parent2Email: '', parent2Phone: '',
    emergencyName: '', emergencyPhone: '',
    hotel: '', hotelName: '', newsletter: false,
    agree: false, signature: '',
  })
  const set = (k: string, v: any) => setD((p: any) => ({ ...p, [k]: v }))
  // From the parent's account (WaiverPrefillBar): player and family details only, never the team, hotel or signature.
  const fillFromAccount = useCallback((v: Record<string, string>) => setD((p: any) => ({ ...p, ...v })), [])

  // BROWSERS FILL FORMS IN WAYS REACT CANNOT SEE.
  //
  // Chrome fills an SSR'd page the moment the HTML lands, which is before React has
  // hydrated and attached a single onChange; password managers and some mobile keyboards
  // write `.value` straight onto the node. Either way the field in front of the parent is
  // full and `d` is still empty, so everything derived from `d` is wrong: the card stayed
  // on the example next to a visibly filled-in form (Bo, Sep 18 2026) -- and, far worse,
  // the submit would have posted a blank player name.
  //
  // So reconcile the other way round: read what is actually in the inputs and push it into
  // state. Reproduced in Chromium by setting `.value` through the native setter with no
  // event; without this the state stays empty, with it the state and the card catch up.
  const formRef = useRef<HTMLFormElement>(null)
  const syncFromDom = useCallback(() => {
    const root = formRef.current
    if (!root) return
    const found: Record<string, string> = {}
    root.querySelectorAll<HTMLInputElement>('input[name], select[name], textarea[name]').forEach(el => {
      const type = (el as HTMLInputElement).type
      if (type === 'checkbox' || type === 'radio' || type === 'file') return
      if (el.value) found[el.name] = el.value
    })
    if (!Object.keys(found).length) return
    // ONLY EVER FILLS A BLANK. A late autofill must not stamp on something the parent
    // has already typed -- verified against exactly that sequence.
    setD((prev: any) => {
      let next = prev, changed = false
      for (const [k, v] of Object.entries(found)) {
        if (k in prev && typeof prev[k] === 'string' && prev[k] === '' && v !== '') {
          if (!changed) { next = { ...prev }; changed = true }
          next[k] = v
        }
      }
      return changed ? next : prev
    })
  }, [])
  useEffect(() => {
    syncFromDom()
    // The browser decides over the first second or so; check a few times rather than
    // guessing one moment, then stop.
    const timers = [60, 250, 700, 1500].map(ms => setTimeout(syncFromDom, ms))
    // Chrome flags an autofilled field with :-webkit-autofill; globals.css hangs a 1ms
    // keyframe off it purely so this event fires when no input event does.
    const onAnim = (e: AnimationEvent) => { if (e.animationName === 'wr-autofill') syncFromDom() }
    document.addEventListener('animationstart', onAnim, true)
    return () => { timers.forEach(clearTimeout); document.removeEventListener('animationstart', onAnim, true) }
  }, [syncFromDom])
  // Staff can hand a parent a link / QR with ?club=&team= (game-day check-in): preselect
  // them when they match a registered club/team, otherwise leave the pickers untouched.
  useEffect(() => {
    try {
      const sp = new URLSearchParams(window.location.search)
      const club = String(sp.get('club') || '').trim(), team = String(sp.get('team') || '').trim()
      if (!club && !team) return
      if (clubMode) {
        const c = clubs!.find(x => x.name === club)
        if (!c) return
        const t = team ? (c.teams.find(x => x.id === team) || c.teams.find(x => x.name === team))?.id || '' : ''
        setD((p: any) => ({ ...p, clubName: c.name, teamPick: t }))
      } else if (team && Array.isArray(teams) && teams.includes(team)) {
        setD((p: any) => ({ ...p, teamName: team }))
      }
    } catch { /* no window / bad params */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const selectedClub = clubMode ? clubs!.find(c => c.name === d.clubName) : undefined
  const clubTeams = selectedClub?.teams ?? []

  // Prefill home town from the club's base the moment a club is picked.
  //
  // ONLY INTO EMPTY FIELDS. A family that has already typed their own town --
  // and the ones who travel to play for an out-of-state club are exactly the
  // families the grant reporting cares about -- must never have it overwritten
  // by re-picking their team.
  useEffect(() => {
    const at = parseBasedIn(selectedClub?.basedIn)
    if (!at) return
    setD((prev: any) => (prev.homeCity || prev.homeState)
      ? prev
      : { ...prev, homeCity: at.city, homeState: at.state })
  }, [selectedClub?.basedIn])
  // The club's logo: from its team registration, else the one the family uploads on this form.
  const clubLogoUrl: string = selectedClub?.logoUrl || String(d.clubLogoUrl || '')
  const clubsShown: ClubOption[] = clubMode ? clubs!.map(c => c.name === d.clubName && !c.logoUrl && d.clubLogoUrl ? { ...c, logoUrl: d.clubLogoUrl } : c) : []
  // What the header chip shows as the parent picks: club (or the typed "other" name), then team.
  const typedOther = String(d.teamOther || '').trim()
  // One resolution of the picked option, reused everywhere below -- the card
  // label, the submitted team name and the division all have to agree.
  const pickedTeam = clubTeams.find(x => x.id === d.teamPick)
  const chipClub: string = selectedClub ? selectedClub.name : d.clubName === '__other' ? typedOther : ''
  const chipTeam: string = (() => {
    if (!selectedClub) return ''
    if (d.teamPick === '__other') return typedOther
    const t = pickedTeam
    return t ? (t.division ? `${t.name} · ${t.division}` : t.name) : ''
  })()
  // Live card preview (tournament forms with the org's "Player pass" switch on): built from
  // what they've typed so far, placeholders for the rest.
  const cardOn = !!(cardContext && fields.playerPass && tournamentId)
  const previewLink = cleanCardLink(d.cardLink)
  const preview: Omit<PassCardData, 'qrDataUrl' | 'qr2DataUrl'> | null = cardOn ? {
    code: '···-···',
    playerName: String(d.playerName || '').trim() || 'Player name',
    clubName: chipClub || 'Your club',
    teamName: selectedClub ? (d.teamPick === '__other' ? typedOther : String(pickedTeam?.name || '')) : '',
    division: selectedClub ? (pickedTeam?.division || '') : '',
    jersey: String(d.jerseyNumber || '').trim().replace(/^#/, ''),
    position: String(d.position || ''),
    photoUrl: d.photoUrl,
    clubLogoUrl,
    tournamentName: cardContext!.tournamentName || tournamentName || '',
    tournamentLogoUrl: cardContext!.tournamentLogoUrl,
    tournamentDates: cardContext!.tournamentDates,
    location: cardContext!.location,
    orgName: cardContext!.orgName,
    orgLogoUrl: cardContext!.orgLogoUrl,
    orgSite: cardContext!.orgSite,
    signedOn: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    qrLabel: previewLink ? qrLabelFor(previewLink) : 'My player card',
    qr2Label: cardContext!.eventQrLabel,
  } : null

  // THE EXAMPLE. A blank preview at the top of the form reads as an empty
  // template rather than a thing worth filling in; a finished one gives them
  // something to aim at (Bo, Sep 18 2026). It borrows the REAL event's logo,
  // dates and org, so it looks like a card from the weekend they are actually
  // registering for rather than a generic mock.
  const sample: Omit<PassCardData, 'qrDataUrl' | 'qr2DataUrl'> | null = !cardOn ? null : sampleCard ? sampleCard.card : {
    ...SAMPLE_PLAYER,
    tournamentName: cardContext!.tournamentName || tournamentName || '',
    tournamentLogoUrl: cardContext!.tournamentLogoUrl,
    tournamentDates: cardContext!.tournamentDates,
    location: cardContext!.location,
    orgName: cardContext!.orgName,
    orgLogoUrl: cardContext!.orgLogoUrl,
    orgSite: cardContext!.orgSite,
    signedOn: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    qr2Label: cardContext!.eventQrLabel,
  }
  // The example's own codes when it is a real card, so both QRs go where that
  // player's actually go.
  const sampleQr = sampleCard?.qrUrl || 'https://whistleready.app'
  const sampleQr2 = sampleCard?.qr2Url || (cardContext?.eventQrUrl || '')

  // Starts on the example and flips to theirs the moment they put something on
  // it -- which is the moment it becomes more interesting than the example.
  // `viewPinned` means they used the toggle themselves, and then we stop
  // deciding for them.
  const [cardView, setCardView] = useState<'example' | 'yours'>('example')
  const [viewPinned, setViewPinned] = useState(false)
  const hasOwnCard = !!String(d.playerName || '').trim() || !!d.photoUrl || !!String(d.jerseyNumber || '').trim()
  useEffect(() => {
    if (!viewPinned && hasOwnCard) setCardView('yours')
  }, [hasOwnCard, viewPinned])
  const pickView = (v: 'example' | 'yours') => { setViewPinned(true); setCardView(v) }
  const shownCard = cardView === 'example' && sample ? sample : preview

  const previewQr = previewLink || (typeof window !== 'undefined' ? `${window.location.origin}${window.location.pathname}` : '')
  // Tournament forms render their own header (logo + title) so the club chip can live in it.
  const headerEl = header ? (
    <>
      <header className="bg-[#0b1220] text-white">
        <div className={`${cardOn ? 'max-w-2xl lg:max-w-5xl' : 'max-w-2xl'} mx-auto px-6 py-6 flex flex-wrap items-center gap-3`}>
          {header.logoUrl && <img src={header.logoUrl} alt="" className="w-12 h-12 rounded-lg object-contain bg-white/95 p-1" />}
          <div className="min-w-0">
            <div className="text-xs uppercase tracking-[0.2em] text-teal-300">{header.eyebrow || 'Player Waiver'}</div>
            <h1 className="text-xl font-extrabold leading-tight">{header.title}</h1>
          </div>
          {chipClub && !done && (
            <div className="basis-full sm:basis-auto sm:ml-auto flex items-center gap-2.5 bg-white/10 border border-white/15 rounded-xl pl-2 pr-3 py-2 min-w-0">
              <ClubMark name={chipClub} logoUrl={clubLogoUrl || undefined} size="lg" />
              <div className="min-w-0">
                <div className="text-[10px] uppercase tracking-[0.16em] text-teal-300 leading-[14px]">Registering for</div>
                <div className="text-[15px] font-extrabold leading-tight truncate">{chipClub}</div>
                {chipTeam && <div className="text-xs text-slate-300 leading-snug truncate">{chipTeam}</div>}
              </div>
            </div>
          )}
        </div>
      </header>
      {!done && <p className={`${cardOn ? 'max-w-2xl lg:max-w-5xl' : 'max-w-2xl'} mx-auto px-6 pt-6 text-sm text-slate-500`}>All players must complete this waiver to compete. Required fields are marked *.{howTo && <> <HowToVideoLink id="waiver" label="See how it works" className="ml-1 align-middle" /></>}</p>}
    </>
  ) : null
  const resolvedTeam: string = (() => {
    const other = String(d.teamOther || '').trim()
    if (clubMode) {
      if (d.clubName === '__other') return other
      if (!d.clubName) return ''
      if (d.teamPick === '__other') return other ? `${d.clubName} — ${other}` : d.clubName
      // THE TEAM, NOT THE DIVISION. This read `pickedTeam.division || pickedTeam.name`,
      // so a parent who picked their team correctly off the dropdown had the waiver
      // filed under the division instead -- "LaxManiax — Girls High School A" rather
      // than "LaxManiax — HS Select". Every downstream join is on the team name
      // (club-director page, per-team roster counts, pools, check-in), so those
      // waivers matched no team and the club's registration page showed far fewer
      // players than the waiver list did. Measured on Monster Mash Sep 18 2026:
      // 14 of 24 waivers carried a division tag. The division is kept, on its own
      // field in the submitted data -- see submit() below.
      return pickedTeam ? `${d.clubName} — ${pickedTeam.name}` : d.clubName
    }
    return d.teamName === '__other' ? other : d.teamName
  })()

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!d.agree || !d.signature.trim()) { toast.error('Please agree to the waiver and sign'); return }
    if (fields.teamName && clubMode && !d.clubName) { toast.error('Please select your club'); return }
    if (fields.teamName && clubMode && d.clubName !== '__other' && clubTeams.length > 0 && !d.teamPick) { toast.error('Please select your team'); return }
    // Picking a registered team is the requirement; typing one is the exception, and it
    // has to be a deliberate one. Without this the "Other" option was the path of least
    // resistance and rosters fragmented across spellings of the same team.
    if ((d.clubName === '__other' || d.teamPick === '__other' || (d.teamName === '__other' && !!teams?.length)) && !d.notListed) {
      toast.error(d.clubName === '__other' ? 'Please check the club list first' : 'Please check your club\u2019s team list first'); return
    }
    if ((d.teamName === '__other' || d.clubName === '__other' || d.teamPick === '__other') && !String(d.teamOther || '').trim()) { toast.error('Please enter your team or club name'); return }
    setSubmitting(true)
    try {
      // "Other / not listed" stores the typed name, not the sentinel, so staff rosters read properly.
      const rest: any = { ...d }; delete rest.teamPick; delete rest.teamOther; delete rest.notListed
      // `division` rides along as its own field: teamName is the join key and has to be
      // the team, but the division is what the schedule and the brackets are built on,
      // so losing it would just move the problem. Blank when the team was typed in.
      const division = clubMode && d.teamPick && d.teamPick !== '__other' ? String(pickedTeam?.division || '') : ''
      const data = { ...rest, teamName: resolvedTeam, division, clubName: clubMode && d.clubName !== '__other' ? d.clubName : '', tournamentId: tournamentId || '', tournamentName: tournamentName || '', termsVersion: TERMS_VERSION }
      const res = await fetch('/api/org-forms/submit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ orgId, formType: 'player', data }) })
      if (res.ok) { const j = await res.json().catch(() => ({})); if (j.passToken) setPassToken(String(j.passToken)); if (j.account?.token || j.account?.linked) setAccount(j.account as AccountOffer); track('Player Waiver'); setDone(true); try { window.scrollTo({ top: 0 }) } catch {} }
      else { const e = await res.json().catch(() => ({})); toast.error(e.error || 'Submission failed') }
    } catch { toast.error('Submission failed') } finally { setSubmitting(false) }
  }

  const receiptRows: [string, string][] = [
    ['Player name', d.playerName], ['Player email', d.playerEmail], [USA_LACROSSE_SHORT, d.usLacrosse], ['Date of birth', d.dob],
    ['Gender', d.gender], ['Grade', d.grade], ['Team', resolvedTeam], ['Jersey #', d.jerseyNumber], ['Position', d.position],
    ['Parent', d.parentName], ['Parent email', d.parentEmail], ['Parent phone', d.parentPhone],
    ['Home town', [d.homeCity, d.homeState].filter(Boolean).join(', ')],
    ['Parent 2', d.parent2Name], ['Parent 2 email', d.parent2Email], ['Parent 2 phone', d.parent2Phone],
    ['Emergency contact', d.emergencyName], ['Emergency phone', d.emergencyPhone],
    ['Hotel / rental', d.hotel], ['Where staying', d.hotelName], ['Signature', d.signature],
  ]
  if (done) return (
    <>
    <style>{cardPrintCss('pass-card')}</style>
    {headerEl}
    <div className="max-w-xl mx-auto px-6 py-16">
      <div className="text-center">
        <CheckCircle2 size={48} className="mx-auto text-teal-500" />
        <h1 className="text-2xl font-extrabold text-slate-900 mt-4">{confirmationTitle}</h1>
        <div className="text-slate-500 mt-3 leading-relaxed" dangerouslySetInnerHTML={{ __html: confirmationHtml }} />
      </div>

      {/* Asked here, right under "you're registered", so it's seen before the card
          and the receipt. Not shown when someone else is signed in (the office at
          check-in): see lib/parentWaivers accountOffer. */}
      {account && <div className="print:hidden"><ParentAccountOffer offer={account} playerName={d.playerName} /></div>}

      {passToken && (
        <div className="mt-8 bg-[#0b1220] rounded-2xl p-5 text-white">
          <div className="text-xs uppercase tracking-[0.2em] text-teal-300 print:hidden">Player card</div>
          <p className="text-sm text-slate-300 mt-1 leading-relaxed print:hidden">Save it, print it, share it. Open the card to change the photo or the link its QR code opens &mdash; the link is in your confirmation email too.</p>
          <img id="pass-card" src={`/pass/${passToken}/card.png`} alt="Player card" width={720} height={1140} className="w-full max-w-[300px] mx-auto mt-4 rounded-xl shadow-2xl shadow-black/50 bg-white" />
          <div className="grid grid-cols-3 gap-2.5 max-w-[340px] mx-auto mt-4 print:hidden">
            <a href={`/pass/${passToken}/card.png`} download="player-card.png" className="inline-flex items-center justify-center gap-1.5 bg-teal-500 hover:bg-teal-400 text-[#0b1220] font-bold rounded-xl py-2.5 text-xs"><Download size={15} /> Save</a>
            {/* Printing is offered here as well as on the card page: this is the
                moment a parent has the card in front of them and is deciding what
                to do with it, and sending them elsewhere first loses most of them. */}
            <button type="button" onClick={() => window.print()} className="inline-flex items-center justify-center gap-1.5 bg-white/10 hover:bg-white/15 border border-white/15 font-semibold rounded-xl py-2.5 text-xs"><Printer size={15} /> Print</button>
            <a href={`/pass/${passToken}`} target="_blank" rel="noopener" className="inline-flex items-center justify-center gap-1.5 bg-white/10 hover:bg-white/15 border border-white/15 font-semibold rounded-xl py-2.5 text-xs"><ExternalLink size={15} /> Open</a>
          </div>
          <p className="text-[11.5px] text-slate-400 text-center mt-2.5 leading-relaxed print:hidden">{CARD_PRINT_NOTE}</p>
        </div>
      )}

      <div className="mt-8 bg-white border border-slate-200 rounded-2xl p-5">
        <h2 className="text-sm font-bold text-slate-800 mb-3 pb-2 border-b border-slate-100">Your submission</h2>
        <div className="grid sm:grid-cols-2 gap-x-8 gap-y-1.5">
          {receiptRows.filter(([, v]) => v && String(v).trim()).map(([label, v]) => (
            <div key={label} className="flex justify-between gap-4 text-sm border-b border-slate-50 py-1">
              <span className="text-slate-400">{label}</span><span className="text-slate-700 text-right">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
    </>
  )

  return (
    <>
    {headerEl}
    {/* Returning families: sign in or pick a player to fill this in. Outside the
        waiver's <form> so its own sign-in form isn't nested in it. */}
    <WaiverPrefillBar eventId={tournamentId} onFill={fillFromAccount} className={`${cardOn ? 'max-w-2xl lg:max-w-5xl' : 'max-w-2xl'} mx-auto px-6 pt-8 -mb-4`} />
    <div className={`${cardOn ? 'max-w-2xl lg:max-w-5xl lg:grid lg:grid-cols-[minmax(0,1fr)_300px] lg:gap-8 lg:items-start' : 'max-w-2xl'} mx-auto px-6 py-10`}>
    <form ref={formRef} onSubmit={submit} className="space-y-6 min-w-0">
      <Toaster position="top-right" />

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="text-base font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">Player information</h2>
        {shownCard && <CardFields photoUrl={d.photoUrl} cardLink={d.cardLink} onPhoto={u => set('photoUrl', u)} onLink={u => set('cardLink', u)} preview={shownCard} qrText={cardView === 'example' ? sampleQr : previewQr} qr2Text={cardView === 'example' ? sampleQr2 : cardContext!.eventQrUrl} theme={cardContext!.theme} view={cardView} onPickView={pickView}
          clubLogo={d.clubName && !selectedClub?.logoUrl ? { clubName: selectedClub ? selectedClub.name : '', url: d.clubLogoUrl, onChange: u => set('clubLogoUrl', u) } : undefined} />}
        <div className="grid sm:grid-cols-2 gap-4">
          <div><label className={labelCls}>Player full name *</label><input className={inputCls} name="playerName" value={d.playerName} onChange={e => set('playerName', e.target.value)} required /></div>
          <div><label className={labelCls}>Player email</label><input className={inputCls} type="email" name="playerEmail" value={d.playerEmail} onChange={e => set('playerEmail', e.target.value)} /></div>
          <div>
            <label className={labelCls}>{USA_LACROSSE_LABEL} *</label>
            <input className={inputCls} name="usLacrosse" value={d.usLacrosse} onChange={e => set('usLacrosse', e.target.value)} required />
            {/* Required field, and the number lives on a card in a drawer somewhere.
                Without this the parent abandons the form to go hunting. */}
            <a href={USA_LACROSSE_LOOKUP} target="_blank" rel="noopener noreferrer"
              className="text-xs text-teal-600 hover:text-teal-800 hover:underline mt-1 inline-block">{USA_LACROSSE_LOOKUP_TEXT} &rarr;</a>
          </div>
          <div><label className={labelCls}>Date of birth *</label><input className={inputCls} type="date" name="dob" value={d.dob} onChange={e => set('dob', e.target.value)} required /></div>
          {fields.gender && <div><label className={labelCls}>Gender *</label><select className={inputCls} name="gender" value={d.gender} onChange={e => set('gender', e.target.value)} required><option value="">Select…</option><option>Female</option><option>Male</option></select></div>}
          {fields.grade && <div><label className={labelCls}>Player grade *</label><select className={inputCls} name="grade" value={d.grade} onChange={e => set('grade', e.target.value)} required><option value="">Select…</option>{GRADES.map(g => <option key={g}>{g}</option>)}</select></div>}
          {fields.teamName && clubMode && (
            <>
              <div><label className={labelCls}>Club *</label>
                <ClubPicker clubs={clubsShown} value={d.clubName} otherName={typedOther} onChange={c => setD((p: any) => ({ ...p, clubName: c, teamPick: '', teamOther: '', notListed: false, clubLogoUrl: '' }))} />
              </div>
              {d.clubName && d.clubName !== '__other' && clubTeams.length > 0 && (
                <div><label className={labelCls}>Team *</label>
                  <select className={inputCls} name="teamPick" value={d.teamPick} onChange={e => setD((p: any) => ({ ...p, teamPick: e.target.value, teamOther: '', notListed: false }))} required>
                    <option value="">Select your team…</option>
                    {clubTeams.map(t => <option key={t.id} value={t.id}>{t.name}{t.division ? ` · ${t.division}` : ''}</option>)}
                    <option value="__other">Other / not listed</option>
                  </select>
                </div>
              )}
              {/* THE ESCAPE HATCH, WITH A SPEED BUMP.
                  A typed-in team matches no registration, so the player never lands on
                  their team's roster, schedule or check-in list. Three LaxManiax families
                  typed three different spellings of one team that was never registered
                  ("2033/2034 Select", "2033/2034 Select Team", "33/34 Lax Maniax") -- each
                  looked like a separate team to every count in the app. So before the free
                  text appears: show what the club actually registered, make each one a
                  one-tap correction, and require them to say the list has been checked. */}
              {(d.clubName === '__other' || d.teamPick === '__other') && (
                <div className="sm:col-span-2 rounded-lg border border-amber-300 bg-amber-50 p-3">
                  <p className="text-sm font-semibold text-amber-900">One more look before you type it in</p>
                  {d.clubName === '__other'
                    ? <p className="mt-1 text-xs text-amber-800 leading-relaxed">Every club registered for this event is in the list above{clubs && clubs.length ? ` \u2014 ${clubs.length} of them` : ''}. A club typed in by hand isn&rsquo;t connected to its registration, so the player won&rsquo;t show up on their team&rsquo;s roster.</p>
                    : <>
                        <p className="mt-1 text-xs text-amber-800 leading-relaxed">{selectedClub ? selectedClub.name : 'This club'} registered {clubTeams.length === 1 ? 'one team' : `these ${clubTeams.length} teams`} for this event &mdash; tap yours if it&rsquo;s here:</p>
                        <ul className="mt-2 flex flex-wrap gap-1.5">
                          {clubTeams.map(t => (
                            <li key={t.id}>
                              <button type="button" onClick={() => setD((p: any) => ({ ...p, teamPick: t.id, teamOther: '', notListed: false }))}
                                className="rounded-full bg-white border border-amber-300 px-2.5 py-1 text-xs font-medium text-amber-900 hover:border-amber-500 hover:bg-amber-100">
                                {t.name}{t.division ? ` \u00b7 ${t.division}` : ''}
                              </button>
                            </li>
                          ))}
                        </ul>
                        <p className="mt-2 text-xs text-amber-800 leading-relaxed">A team typed in by hand isn&rsquo;t connected to the roster, the schedule or game-day check-in.</p>
                      </>}
                  <label className="mt-3 flex items-start gap-2 text-xs font-semibold text-amber-900 cursor-pointer">
                    <input type="checkbox" className="mt-0.5 accent-amber-600" checked={!!d.notListed} onChange={e => set('notListed', e.target.checked)} />
                    <span>I&rsquo;ve checked the list &mdash; {d.clubName === '__other' ? 'my club isn\u2019t' : 'my team isn\u2019t'} there.</span>
                  </label>
                  {d.notListed && (
                    <div className="mt-3"><label className={labelCls}>{d.clubName === '__other' ? 'Enter your club and team name *' : 'Enter your team name *'}</label>
                      <input className={inputCls} name="teamOther" value={d.teamOther} onChange={e => set('teamOther', e.target.value)} placeholder={d.clubName === '__other' ? 'e.g. Tampa Elite 2031' : 'e.g. 2031 Blue'} required />
                    </div>
                  )}
                </div>
              )}
            </>
          )}
          {fields.teamName && !clubMode && <div><label className={labelCls}>Team or club name *</label>{teams && teams.length > 0
            ? <select className={inputCls} name="teamName" value={d.teamName} onChange={e => setD((p: any) => ({ ...p, teamName: e.target.value, teamOther: '', notListed: false }))} required><option value="">Select your team…</option>{teams.map(tm => <option key={tm} value={tm}>{tm}</option>)}<option value="__other">Other / not listed</option></select>
            : <input className={inputCls} name="teamName" value={d.teamName} onChange={e => set('teamName', e.target.value)} required />}</div>}
          {fields.teamName && !clubMode && d.teamName === '__other' && teams && teams.length > 0 && (
            <div className="sm:col-span-2 rounded-lg border border-amber-300 bg-amber-50 p-3">
              <p className="text-sm font-semibold text-amber-900">One more look before you type it in</p>
              <p className="mt-1 text-xs text-amber-800 leading-relaxed">All {teams.length} teams registered for this event are in the list above &mdash; tap yours if it&rsquo;s here:</p>
              <ul className="mt-2 flex flex-wrap gap-1.5">
                {teams.map(tm => (
                  <li key={tm}>
                    <button type="button" onClick={() => setD((p: any) => ({ ...p, teamName: tm, teamOther: '', notListed: false }))}
                      className="rounded-full bg-white border border-amber-300 px-2.5 py-1 text-xs font-medium text-amber-900 hover:border-amber-500 hover:bg-amber-100">{tm}</button>
                  </li>
                ))}
              </ul>
              <label className="mt-3 flex items-start gap-2 text-xs font-semibold text-amber-900 cursor-pointer">
                <input type="checkbox" className="mt-0.5 accent-amber-600" checked={!!d.notListed} onChange={e => set('notListed', e.target.checked)} />
                <span>I&rsquo;ve checked the list &mdash; my team isn&rsquo;t there.</span>
              </label>
              {d.notListed && (
                <div className="mt-3"><label className={labelCls}>Enter your team or club name *</label>
                  <input className={inputCls} name="teamOther" value={d.teamOther} onChange={e => set('teamOther', e.target.value)} placeholder="e.g. Tampa Elite 2031" required />
                </div>
              )}
            </div>
          )}
          {/* Digits only, up to 3: a 10-digit number typed here (Oct 7 2026) once
              made every waiver list of its event fail to load (lib/formSubmissions). */}
          <div><label className={labelCls}>Jersey number</label><input className={inputCls} name="jerseyNumber" inputMode="numeric" autoComplete="off" maxLength={3} value={d.jerseyNumber} onChange={e => set('jerseyNumber', e.target.value.replace(/\D/g, '').slice(0, 3))} /></div>
          {fields.position !== false && <div><label className={labelCls}>Position</label><select className={inputCls} name="position" value={d.position} onChange={e => set('position', e.target.value)}><option value="">Select…</option>{POSITIONS.map(p => <option key={p}>{p}</option>)}</select></div>}
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="text-base font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">Parent information</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <div><label className={labelCls}>Parent name *</label><input className={inputCls} name="parentName" value={d.parentName} onChange={e => set('parentName', e.target.value)} autoComplete="name" required /></div>
          <div><label className={labelCls}>Parent email *</label><input className={inputCls} type="email" name="parentEmail" value={d.parentEmail} onChange={e => set('parentEmail', e.target.value)} autoComplete="email" required /></div>
          <div><label className={labelCls}>Parent mobile phone *</label><input className={inputCls} type="tel" name="parentPhone" value={d.parentPhone} onChange={e => set('parentPhone', e.target.value)} autoComplete="tel" required /></div>
        </div>
        {fields.homeTown !== false && (
          <div className="grid sm:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-100">
            <div>
              <label className={labelCls}>Home town *</label>
              {/* address-level2/1 are what a browser matches a saved address on,
                  so a phone offers the whole thing in one tap. */}
              <input className={inputCls} name="homeCity" value={d.homeCity} onChange={e => set('homeCity', e.target.value)}
                autoComplete="address-level2" placeholder="City" required />
            </div>
            <div>
              <label className={labelCls}>Home state *</label>
              <select className={inputCls} name="homeState" value={d.homeState} onChange={e => set('homeState', e.target.value)}
                autoComplete="address-level1" required>
                <option value="">Select…</option>
                {US_STATES.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
              </select>
            </div>
            <p className="sm:col-span-2 text-[12px] text-slate-500 -mt-1">
              Where your family travels from. Our venues&rsquo; county tourism boards ask for this.
            </p>
          </div>
        )}
        {fields.parent2 && (
          <div className="grid sm:grid-cols-2 gap-4 mt-4 pt-4 border-t border-slate-100">
            <div><label className={labelCls}>Parent 2 name</label><input className={inputCls} name="parent2Name" value={d.parent2Name} onChange={e => set('parent2Name', e.target.value)} /></div>
            <div><label className={labelCls}>Parent 2 email</label><input className={inputCls} type="email" name="parent2Email" value={d.parent2Email} onChange={e => set('parent2Email', e.target.value)} /></div>
            <div><label className={labelCls}>Parent 2 mobile phone</label><input className={inputCls} type="tel" name="parent2Phone" value={d.parent2Phone} onChange={e => set('parent2Phone', e.target.value)} /></div>
          </div>
        )}
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="text-base font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">Emergency contact</h2>
        <div className="grid sm:grid-cols-2 gap-4">
          <div><label className={labelCls}>Name *</label><input className={inputCls} name="emergencyName" value={d.emergencyName} onChange={e => set('emergencyName', e.target.value)} required /></div>
          <div><label className={labelCls}>Phone *</label><input className={inputCls} type="tel" name="emergencyPhone" value={d.emergencyPhone} onChange={e => set('emergencyPhone', e.target.value)} required /></div>
        </div>
      </div>

      {fields.hotelQuestion && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <label className={labelCls}>Is your family staying at a hotel or vacation rental during the tournament? *</label>
          <select className={inputCls} name="hotel" value={d.hotel} onChange={e => set('hotel', e.target.value)} required><option value="">Select…</option><option>Yes</option><option>No</option><option>Maybe</option></select>
          {d.hotel === 'Yes' && <div className="mt-3"><label className={labelCls}>Which hotel / where are you staying? *</label><input className={inputCls} name="hotelName" value={d.hotelName} onChange={e => set('hotelName', e.target.value)} placeholder="Hotel or rental name" required /></div>}
        </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 p-6">
        <h2 className="text-base font-bold text-slate-800 mb-4 pb-2 border-b border-slate-100">{waiverTitle}</h2>
        <div className="bg-slate-50 rounded-xl p-4 text-xs text-slate-600 leading-relaxed mb-4 max-h-56 overflow-y-auto" dangerouslySetInnerHTML={{ __html: waiverHtml }} />
        <label className="flex items-start gap-3 cursor-pointer mb-4">
          <input type="checkbox" checked={d.agree} onChange={e => set('agree', e.target.checked)} className="mt-0.5 accent-teal-500 w-4 h-4" />
          <span className="text-sm text-slate-700">I have read and agree to the waiver and release of liability above, and to the Whistle Ready <a href="/terms" target="_blank" rel="noreferrer" className="text-teal-700 underline underline-offset-2">Terms of Use</a> *</span>
        </label>
        <label className={labelCls}>Type your full name as signature *</label>
        <input className={inputCls} name="signature" value={d.signature} onChange={e => set('signature', e.target.value)} placeholder="Full legal name" required />
      </div>

      {fields.newsletter && (
        <label className="flex items-start gap-3 cursor-pointer px-1">
          <input type="checkbox" checked={d.newsletter} onChange={e => set('newsletter', e.target.checked)} className="mt-0.5 accent-teal-500 w-4 h-4" />
          <span className="text-sm text-slate-600">Keep me in the loop with updates and offers.</span>
        </label>
      )}

      <button type="submit" disabled={submitting || !d.agree} className="w-full bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-bold py-3.5 rounded-2xl transition-colors">
        {submitting ? 'Submitting…' : 'Submit registration'}
      </button>
    </form>
    {shownCard && (
      <aside className="hidden lg:block sticky top-6">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="text-xs font-bold uppercase tracking-[0.16em] text-slate-500">
            {cardView === 'example' ? 'Example card' : 'Your player card'}
          </div>
          <CardViewSwitch view={cardView} onPick={pickView} />
        </div>
        <CardPreview p={shownCard} qrText={cardView === 'example' ? sampleQr : previewQr} qr2Text={cardView === 'example' ? sampleQr2 : cardContext!.eventQrUrl} theme={cardContext!.theme} className="w-full rounded-2xl shadow-xl ring-1 ring-slate-200" />
        <p className="text-xs text-slate-400 mt-2 leading-relaxed">
          {cardView === 'example'
            ? 'A finished card, so you can see where this is going. Switch to Yours and it builds itself as you type \u2014 or just start typing your name.'
            : 'Builds itself as you type. The player ID and QR code are set when you submit; you can change the photo or the link any time after.'}
        </p>
      </aside>
    )}
    </div>
    </>
  )
}
