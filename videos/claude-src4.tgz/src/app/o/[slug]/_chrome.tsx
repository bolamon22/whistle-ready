import Link from 'next/link'
import { headers } from 'next/headers'
import { isCustomOrgHost } from '@/lib/orgDomains'
import { createClient } from '@libsql/client'
import { Facebook, Instagram, Globe, UserRound } from 'lucide-react'
import { fmtRangeShort, shortLocation } from '@/lib/eventHero'
import { regBadge, shortDay, TONE_CLASS } from '@/lib/regStatus'
import OrgNav, { EventMark, type HeaderEvent } from './OrgNav'

export type PageRec = { title: string; slug: string; group?: string; body?: string; heroImage?: string; placement?: 'nav' | 'footer' }
export type NavLink = { title: string; href: string }
export type NavItem = { type: 'link'; title: string; href: string; id?: string } | { type: 'group'; label: string; children: NavLink[] }

// Link base for the org's own pages. On a custom domain (sunshinelax.com) the org
// is served at the root so links are root-relative (''); on whistleready.app they
// live under /o/[slug]. Read once per request from the Host header.
export function orgBase(slug: string): string {
  try { return isCustomOrgHost(headers().get('host')) ? '' : `/o/${slug}` } catch { return `/o/${slug}` }
}

// Build the ordered nav (with dropdown groups) from the org's pages.
export function buildNav(base: string, pages: PageRec[], hasGallery: boolean, workHref?: string): NavItem[] {
  // Straight to the event list, not the top of the home page: on the home page itself
  // `base || '/'` just reloaded and appeared to do nothing, and from /gallery or /work
  // it left you scrolling for the events. Same target as the hero's "See all events".
  const items: NavItem[] = [{ type: 'link', id: 'tournaments', title: 'Tournaments', href: base ? `${base}#tournaments` : '/#tournaments' }]
  if (hasGallery) items.push({ type: 'link', title: 'Gallery', href: `${base}/gallery` })
  const groupAt: Record<string, number> = {}
  for (const p of pages) {
    if (!p.title || !p.slug) continue
    if (p.placement === 'footer') continue
    const href = `${base}/${p.slug}`
    const g = (p.group || '').trim()
    if (g) {
      if (groupAt[g] === undefined) { groupAt[g] = items.length; items.push({ type: 'group', label: g, children: [] }) }
      ;(items[groupAt[g]] as any).children.push({ title: p.title, href })
    } else {
      items.push({ type: 'link', title: p.title, href })
    }
  }
  {
    let moreIdx = items.findIndex(it => it.type === 'group' && (((it as any).label || '').trim().toLowerCase() === 'more'))
    if (moreIdx === -1) { moreIdx = items.length; items.push({ type: 'group', label: 'More', children: [] }) }
    ;(items[moreIdx] as any).children.push({ title: 'Results', href: `${base}/results` })
    ;(items[moreIdx] as any).children.push({ title: 'By the Numbers', href: `${base}/stats` })
  }
  if (workHref) items.push({ type: 'link', title: 'Work With Us', href: workHref })
  return items
}

// Link sections for the footer, from the pages placed there.
//
// WHY info pages get a second home: the header dropdown serves someone who has
// already picked this org and wants a policy — rules, refunds, weather. A page
// written to be FOUND, like "Florida Youth Lacrosse Tournaments: A Guide for
// Teams & Families", is for a stranger who hasn't, and it stretched that menu to
// three lines for an audience that never opens it. Either placement gives the
// page the same site-wide internal link; the footer is where that link stops
// costing the menu. The section heading is the page's own group, so an org names
// it whatever it likes and can grow the section later.
export function buildFooterLinks(base: string, pages: PageRec[]): { label: string; links: NavLink[] }[] {
  const out: { label: string; links: NavLink[] }[] = []
  const at: Record<string, number> = {}
  for (const p of pages) {
    if (!p.title || !p.slug || p.placement !== 'footer') continue
    const label = (p.group || '').trim() || 'Guides'
    if (at[label] === undefined) { at[label] = out.length; out.push({ label, links: [] }) }
    out[at[label]].links.push({ title: p.title, href: `${base}/${p.slug}` })
  }
  return out
}

// The header's event logos: the org's next few events, soonest first. Four fit
// beside Tournaments at 1280px with Sunshine's longest menu (measured Oct 7 2026:
// 247px free before the logos, about 83px after, the org name untouched). An
// event stays through its last day in Eastern time, eventIsOver's rule, so it is
// still up there the weekend it is played, when families most need its schedule.
const HEADER_EVENTS = 4

// Same palette and hash as the home page's event cards, so an event with no logo
// gets the same color in the header as on its card.
const ACCENTS = ['#0e7490', '#b45309', '#9f1239', '#1d4ed8', '#6d28d9', '#047857']
function accentFor(str: string) { let h = 0; for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0; return ACCENTS[h % ACCENTS.length] }
function initials(name: string) {
  return name.split(' ').filter(w => w.length > 2).slice(0, 2).map(w => w[0].toUpperCase()).join('') || name.slice(0, 2).toUpperCase()
}

export async function headerEvents(orgId: string): Promise<HeaderEvent[]> {
  if (!orgId) return []
  try {
    const client = createClient({ url: process.env.TURSO_DATABASE_URL!, authToken: process.env.TURSO_AUTH_TOKEN })
    const today = new Date().toLocaleDateString('en-CA', { timeZone: 'America/New_York' })
    const res = await client.execute({
      sql: `SELECT id, name, startDate, endDate, location, logoUrl, teamRegEnabled, registrationDivisions FROM "Tournament"
            WHERE orgId = ? AND TRIM(COALESCE(name, '')) <> '' AND COALESCE(NULLIF(endDate, ''), startDate) >= ?
            ORDER BY startDate LIMIT ${HEADER_EVENTS}`,
      args: [orgId, today],
    })
    const rows = res.rows as any[]
    if (!rows.length) return []

    // The registration badge the home page's cards show. Only the fields regBadge
    // reads come back, not each event's whole page blob, since this runs on every
    // page of the site. No badges is the worst a failure here can do.
    const site: Record<string, any> = {}
    try {
      const keys = rows.map(t => `tournamentSite:${t.id}`)
      const s = await client.execute({
        sql: `SELECT "key", json_extract("value", '$.regStatus') AS regStatus, json_extract("value", '$.regStatusText') AS regStatusText,
                json_extract("value", '$.regClosesOn') AS regClosesOn, json_extract("value", '$.divisionStatus') AS divisionStatus
              FROM "AppSetting" WHERE "key" IN (${keys.map(() => '?').join(',')}) AND json_valid("value")`,
        args: keys,
      })
      for (const r of s.rows as any[]) {
        let divisionStatus: Record<string, string> = {}
        try { const d = JSON.parse(String(r.divisionStatus || '{}')); if (d && typeof d === 'object') divisionStatus = d } catch { /* no division states */ }
        site[String(r.key).slice('tournamentSite:'.length)] = {
          regStatus: r.regStatus == null ? undefined : String(r.regStatus),
          regStatusText: r.regStatusText == null ? undefined : String(r.regStatusText),
          regClosesOn: r.regClosesOn == null ? undefined : String(r.regClosesOn),
          divisionStatus,
        }
      }
    } catch { /* no badges this render */ }

    return rows.map(t => {
      const id = String(t.id)
      const raw = String(t.name || '')
      let divs: string[] = []
      try { const d = JSON.parse(String(t.registrationDivisions || '[]')); if (Array.isArray(d)) divs = d.filter(Boolean) } catch { /* label falls back */ }
      const badge = regBadge(site[id] || null, divs)
      const logo = String(t.logoUrl || '')
      return {
        id,
        name: raw.replace(/\s+/g, ' ').trim(),
        href: `/tournaments/${id}/event`,
        // A logo still stored inline would ride along on every page of the site, twice.
        logoUrl: logo.startsWith('data:') && logo.length > 60000 ? '' : logo,
        initials: initials(raw),
        accent: accentFor(raw),
        dates: fmtRangeShort(String(t.startDate || ''), String(t.endDate || '')),
        day: shortDay(String(t.startDate || '')),
        place: shortLocation(String(t.location || '')),
        registerHref: Number(t.teamRegEnabled) ? `/tournaments/${id}/register` : undefined,
        badge: badge ? { label: badge.label, cls: TONE_CLASS[badge.tone] } : null,
      }
    })
  } catch {
    return []
  }
}

// `orgId` falls back to org.id; the tournament pages pass it, since the org they
// hand in is only a name and a logo. `currentId` is the event being shown, which
// gets a ring among the logos.
export async function OrgHeader({ org, homeHref, nav, registerHref, orgId, currentId = '' }: { org: any; homeHref: string; nav: NavItem[]; registerHref?: string; orgId?: string; currentId?: string }) {
  const all = await headerEvents(String(orgId || org?.id || ''))
  // A lone event that is the page you are already on promotes nothing.
  const events = all.length > 1 || (all.length === 1 && all[0].id !== currentId) ? all : []
  return (
    <>
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200/70 relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
          <Link href={homeHref} className="flex items-center gap-2.5 min-w-0 flex-shrink">
            {org.logoUrl && <img src={org.logoUrl} alt="" className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg object-contain bg-white border border-slate-100 flex-shrink-0" />}
            <span className="font-extrabold tracking-tight text-slate-900 text-base sm:text-lg truncate">{org.name}</span>
          </Link>
          <OrgNav nav={nav} registerHref={registerHref} events={events} currentId={currentId} />
        </div>
      </header>
      {/* Below xl the bar has no room for the logos, so phones and tablets get
          them here: logo and first day, sliding sideways when a narrow phone
          can't fit them all. It scrolls away with the page instead of sticking
          under the bar, which already takes 64px of a phone screen. */}
      {events.length > 0 && (
        <nav aria-label="Upcoming events" className="xl:hidden bg-white border-b border-slate-200/70">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-1.5 flex items-center gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {events.map(e => {
              const here = e.id === currentId
              return (
                <Link key={e.id} href={e.href} prefetch={false} title={`${e.name} · ${e.dates}`} aria-label={`${e.name}, ${e.dates}`} aria-current={here ? 'true' : undefined}
                  className={`flex-none inline-flex items-center gap-1.5 rounded-full border py-[3px] pl-[3px] pr-2 text-xs font-semibold whitespace-nowrap transition-colors ${here ? 'border-teal-500 ring-1 ring-teal-500 bg-teal-50 text-teal-800' : 'border-slate-200 bg-white text-slate-700 hover:border-teal-400'}`}>
                  <EventMark e={e} className="w-7 h-7 rounded-full border border-slate-100 text-[10px]" />
                  {e.day}
                </Link>
              )
            })}
          </div>
        </nav>
      )}
    </>
  )
}

export function OrgFooter({ org, contact, socials, base = '', pages = [] }: { org: any; contact: any; socials: any; base?: string; pages?: PageRec[] }) {
  // Renders nothing extra when no page is placed here, so an org that has not used
  // this keeps exactly the footer it had.
  const sections = buildFooterLinks(base, pages)
  return (
    <footer className="bg-[#0b1220] text-slate-300">
      <div className="max-w-6xl mx-auto px-6 py-14 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-3">
            {org.logoUrl && <img src={org.logoUrl} alt="" className="w-11 h-11 rounded-lg object-contain bg-white/95 p-1" />}
            <span className="font-extrabold text-white text-xl tracking-tight">{org.name}</span>
          </div>
          <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1 text-sm text-slate-400">
            {(contact.email || org.contactEmail) && <a href={`mailto:${contact.email || org.contactEmail}`} className="hover:text-teal-300">{contact.email || org.contactEmail}</a>}
            {contact.phone && <a href={`tel:${contact.phone}`} className="hover:text-teal-300">{contact.phone}</a>}
            {contact.hours && <span>{contact.hours}</span>}
            {contact.address && <span>{contact.address}</span>}
          </div>
          {(socials.facebook || socials.instagram || socials.website) && (
            <div className="flex gap-3 mt-4">
              {socials.facebook && <a href={socials.facebook} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors" aria-label="Facebook"><Facebook size={17} /></a>}
              {socials.instagram && <a href={socials.instagram} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors" aria-label="Instagram"><Instagram size={17} /></a>}
              {socials.website && <a href={socials.website} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors" aria-label="Website"><Globe size={17} /></a>}
            </div>
          )}
        </div>
        {sections.length > 0 && (
          <div className="flex flex-wrap gap-x-12 gap-y-7">
            {sections.map(sec => (
              <div key={sec.label}>
                <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500">{sec.label}</p>
                <ul className="mt-3 space-y-2">
                  {sec.links.map(l => (
                    <li key={l.href}><Link href={l.href} className="text-sm text-slate-400 hover:text-teal-300 transition-colors">{l.title}</Link></li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}
        {/* The header has this too; the footer is where people look for it on a long page. */}
        <div className="flex flex-col items-start sm:items-end gap-2">
          <Link href="/login" className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-200 hover:text-teal-300 transition-colors">
            <UserRound size={15} /> Log in to your account
          </Link>
          <a href="https://whistleready.app" className="text-xs text-slate-500 hover:text-teal-300 transition-colors">Powered by Whistle Ready</a>
        </div>
      </div>
    </footer>
  )
}
