'use client'
import { useEffect, useState, useCallback, useRef } from 'react'
import { TEMPLATE_CATALOG, BRACKET_TEMPLATES, getTemplate, type GameTemplate } from '@/lib/bracketTemplates'
import { buildTemplate, bracketStats, type BracketStats } from '@/lib/bracketGen'
import { CheckCircle2 } from 'lucide-react'
import { parseStandingsRules, seedOrder, type Game as StGame } from '@/lib/standings'

// ── Types ──────────────────────────────────────────────────────────────────

interface BracketGame {
  id: string
  gameNumber: number
  label: string | null
  team1Source: string
  team2Source: string
  section: string
  round: number
}

interface BracketData {
  id: string
  format: string
  teamCount: number
  flight?: string
  numberOffset?: number
  seeds: Record<string, string>
  games: BracketGame[]
}

interface Props {
  tournamentId: string
  division: string
  planFormat?: 'single' | 'double' | '2gg'
  planCount?: string
  planConsolation?: string
  planLoserConsolation?: boolean
  // Which view the rail asked for. 'preview' when the click came from a bracket
  // chip, 'seeding' otherwise; openPreviewAt is a counter whose VALUE means nothing
  // -- it changing is what re-asks, so clicking the same chip twice still works
  // after the user has switched tabs by hand.
  initialTab?: 'seeding' | 'preview'
  openPreviewAt?: number
  /** "No bracket: pool play only" (lib/divisionPlan), and how the page hears it changed. */
  noBracket?: boolean
  onNoBracketChange?: (on: boolean) => void
  /** For the game counts shown before a bracket is built: the division's pool
   *  games, pool games per team, the event's game guarantee and team count. */
  poolGameCount?: number
  poolPerTeam?: number
  guarantee?: number
  divisionTeams?: number
}

// A flight's format. 'owes2' is single elimination plus a loser-fed 2nd game for
// every team: the fewest games that still give everyone 2 bracket games.
type SplitFmt = 'single' | 'double' | '2gg' | 'owes2'
const SPLIT_FMT_LABEL: Record<SplitFmt, string> = { single: 'Single', double: 'Double', '2gg': '2GG', owes2: 'Min 2' }
const SPLIT_FMT_TITLE: Record<SplitFmt, string> = {
  single: 'Single elimination: losers are out after one game',
  double: 'Double elimination (4 or 8 teams)',
  '2gg': 'Both-ways consolation: winners and consolation brackets, every team plays 2+',
  owes2: 'Single elimination plus a loser-fed 2nd game for every team: the fewest games that still give everyone 2',
}

/** "9 games · every team 2+" or "7 games · 4 teams get only 1" for a would-be bracket. */
function StatsLine({ st, need, className = '' }: { st: BracketStats | null; need: number; className?: string }) {
  if (!st) return null
  return (
    <p className={`text-xs font-medium ${st.short ? 'text-amber-300' : 'text-emerald-300'} ${className}`}>
      {st.games} game{st.games === 1 ? '' : 's'}{st.ifNeeded ? ` (${st.ifNeeded} if needed)` : ''} · {st.short
        ? `${st.short} team${st.short === 1 ? '' : 's'} could get only ${st.minPerTeam} bracket game${st.minPerTeam === 1 ? '' : 's'}`
        : `every team plays ${need}+`}
    </p>
  )
}

// ── Layout constants ───────────────────────────────────────────────────────

const GAME_H = 72
const GAME_W = 216
const CONN_W = 48
const GAME_GAP = 16
const UNIT = GAME_H + GAME_GAP
const LABEL_H = 28
const BAR_H = 28
const BAR_GAP = 8
const TOP_PAD = 16

function roundLabel(round: number, maxRound: number): string {
  if (round === maxRound) return 'Final'
  if (round === maxRound - 1 && maxRound >= 3) return 'Semifinals'
  if (round === maxRound - 2 && maxRound >= 4) return 'Quarterfinals'
  return `Round ${round}`
}

const FORMAT_LABELS: Record<string, string> = {
  single: 'Single Elimination',
  double: 'Double Elimination',
  '2gg': 'Both-ways consolation',
}

const SECTION_LABELS: Record<string, string> = {
  winners: 'Winners Bracket',
  championship: 'Championship',
  consolation: 'Consolation',
  losers: "Losers' Bracket",
}

// ── Main component ─────────────────────────────────────────────────────────

export default function BracketBuilder({ tournamentId, division, planFormat, planCount, planConsolation, planLoserConsolation, initialTab, openPreviewAt, noBracket, onNoBracketChange, poolGameCount, poolPerTeam, guarantee, divisionTeams }: Props) {
  // Bracket games each team still needs once pool play is done (4 guaranteed - 2 pool = 2).
  const need = Math.max(1, (guarantee ?? 4) - (poolPerTeam ?? 2))
  const [loading, setLoading] = useState(true)
  // Pool play only (Bo, Oct 11 2026: "an option not to schedule bracket games").
  const [poolOnly, setPoolOnly] = useState(!!noBracket)
  useEffect(() => { setPoolOnly(!!noBracket) }, [noBracket])
  const [savingPoolOnly, setSavingPoolOnly] = useState(false)
  const [bracket, setBracket] = useState<BracketData | null>(null)
  const [tab, setTab] = useState<'seeding' | 'manage' | 'preview'>(initialTab ?? 'seeding')
  const [showAddGame, setShowAddGame] = useState(false)
  const [seeds, setSeeds] = useState<Record<string, string>>({})
  const [standings, setStandings] = useState<{ team: string; w: number; l: number; t: number; gf: number; ga: number }[]>([])
  // Standings exist before a ball is played (every team 0-0), and that order is just
  // the order teams appear in the games. Seeding from it put real names on the bracket
  // before the event and paired two pool-mates in round one (Girls MS, Oct 2026).
  // Names only go in once every pool game has a score.
  const [poolProgress, setPoolProgress] = useState({ scored: 0, total: 0 })
  const poolDone = poolProgress.total > 0 && poolProgress.scored === poolProgress.total
  const [schedule, setSchedule] = useState<Record<number, { date: string; startTime: string; location: string }>>({})
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [selFormat, setSelFormat] = useState<'single' | 'double' | '2gg'>(planFormat ?? 'single')
  const [selCountInput, setSelCountInput] = useState(planCount ?? '4')
  const [consolationInput, setConsolationInput] = useState(planConsolation ?? '0')
  const [loserConsolation, setLoserConsolation] = useState(planLoserConsolation ?? false)
  const [creating, setCreating] = useState(false)

  // Flighting (Stage 2): a division can hold multiple brackets (Flight A/B)
  const [flights, setFlights] = useState<BracketData[]>([])
  const [activeFlight, setActiveFlight] = useState<string>('A')
  const activeRef = useRef('A')
  useEffect(() => { activeRef.current = activeFlight }, [activeFlight])
  const [showSplit, setShowSplit] = useState(false)
  const [cutoffInput, setCutoffInput] = useState('8')
  const [fmtA, setFmtA] = useState<SplitFmt>('single')
  const [fmtB, setFmtB] = useState<SplitFmt>('single')
  const [splitting, setSplitting] = useState(false)
  const [logos, setLogos] = useState<Record<string, string>>({})
  useEffect(() => {
    fetch(`/api/tournaments/${tournamentId}/divisions/${division}/teams`)
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (!d?.teams) return
        const m: Record<string, string> = {}
        for (const t of d.teams) if (t.logoUrl) m[t.teamName] = t.logoUrl
        setLogos(m)
      }).catch(() => {})
  }, [tournamentId, division])

  // Add-game form state
  const [addSection, setAddSection] = useState('consolation')
  const [addRound, setAddRound] = useState(1)
  const [addT1, setAddT1] = useState('')
  const [addT2, setAddT2] = useState('')
  const [addLabel, setAddLabel] = useState('')
  const [addingGame, setAddingGame] = useState(false)
  const [removingGame, setRemovingGame] = useState<number | null>(null)

  const apiBase = `/api/tournaments/${tournamentId}/divisions/${division}/bracket`
  const flightApi = `${apiBase}?flight=${activeFlight}`

  const loadBracket = useCallback(async () => {
    setLoading(true)
    try {
      const r = await fetch(apiBase)
      const raw = r.ok ? await r.json() : []
      const list: BracketData[] = Array.isArray(raw) ? raw : (raw && raw.id ? [raw] : [])
      setFlights(list)
      const keep = list.find(f => (f.flight || 'A') === activeRef.current)
      const active = keep || list[0] || null
      setActiveFlight(active ? (active.flight || 'A') : 'A')
      setBracket(active)
      setSeeds(active?.seeds || {})
    } catch { setFlights([]); setBracket(null) } finally {
      setLoading(false)
    }
  }, [apiBase])

  useEffect(() => { loadBracket() }, [loadBracket])

  // Follow the rail only when the rail actually asks. A tab the user picked by hand
  // changes none of these, so it stays put.
  useEffect(() => { setTab(initialTab ?? 'seeding') }, [initialTab, division, openPreviewAt])

  // Seeds follow the tournament's advance rule and tiebreakers (Settings > Standings,
  // lib/standings), the same ranking the public standings page shows. This used to
  // sort by wins, goal diff, goals for regardless of the tiebreakers set, so "Seed
  // from standings" could disagree with what families saw.
  const [advanceBy, setAdvanceBy] = useState<'division' | 'pool'>('division')
  const loadStandings = useCallback(async () => {
    try {
      const [pg, t] = await Promise.all([
        fetch(`/api/tournaments/${tournamentId}/divisions/${division}/pool-games`).then(r => r.ok ? r.json() : []),
        fetch(`/api/tournaments/${tournamentId}`).then(r => r.ok ? r.json() : null).catch(() => null),
      ])
      const rules = parseStandingsRules(t?.tiebreakers)
      setAdvanceBy(rules.advanceBy)
      const list: StGame[] = (Array.isArray(pg) ? pg : []).map((g: any) => ({
        ...g,
        score1: g.score1 == null || g.score1 === '' ? null : Number(g.score1),
        score2: g.score2 == null || g.score2 === '' ? null : Number(g.score2),
        isCanceled: !!g.isCanceled, isChampionship: false,
      }))
      const live = list.filter(g => !g.isCanceled)
      setPoolProgress({ scored: live.filter(g => g.score1 != null && g.score2 != null).length, total: live.length })
      if (!list.length) { setStandings([]); return }
      setStandings(seedOrder(list, list[0].division, rules).map(({ team, w, l, t, gf, ga }) => ({ team, w, l, t, gf, ga })))
    } catch { setStandings([]); setPoolProgress({ scored: 0, total: 0 }) }
  }, [tournamentId, division])

  useEffect(() => { loadStandings() }, [loadStandings])

  const loadSchedule = useCallback(async () => {
    try {
      const bg = await fetch(`/api/tournaments/${tournamentId}/divisions/${division}/pool-games?scope=bracket`).then(r => r.ok ? r.json() : [])
      const map: Record<number, { date: string; startTime: string; location: string }> = {}
      for (const g of (Array.isArray(bg) ? bg : [])) {
        const n = parseInt(String(g.gameNumber).replace(/^B/, ''))
        if (!isNaN(n)) map[n] = { date: g.date || '', startTime: g.startTime || '', location: g.location || '' }
      }
      setSchedule(map)
    } catch { setSchedule({}) }
  }, [tournamentId, division])

  useEffect(() => { loadSchedule() }, [loadSchedule])

  async function handleCreate() {
    setCreating(true); setError(null)
    try {
      const r = await fetch(apiBase, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ format: selFormat, teamCount: Math.max(2, parseInt(selCountInput) || 2), consolationCount: Math.max(0, parseInt(consolationInput) || 0), loserConsolation: loserConsolation && selFormat !== '2gg', seeds: {} }),
      })
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Failed to create') }
      await loadBracket()
      setTab('seeding')
    } catch (e: any) {
      setError(e.message)
    } finally {
      setCreating(false)
    }
  }

  async function handleSaveSeeds() {
    if (!bracket) return
    setSaving(true); setError(null)
    try {
      const r = await fetch(flightApi, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ seeds }),
      })
      if (!r.ok) throw new Error('Failed to save')
      const d = await r.json()
      setBracket(prev => prev ? { ...prev, seeds: d.seeds || {} } : prev)
      setSeeds(d.seeds || {})
      setFlights(prev => prev.map(f => f.id === bracket.id ? { ...f, seeds: d.seeds || {} } : f))
    } catch (e: any) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete() {
    if (!confirm('Delete this bracket and all its games? This cannot be undone.')) return
    setDeleting(true)
    try {
      await fetch(apiBase, { method: 'DELETE' })
      setBracket(null)
      setSeeds({})
    } finally { setDeleting(false) }
  }

  async function handleAddGame() {
    if (!bracket || !addT1.trim() || !addT2.trim()) return
    setAddingGame(true); setError(null)
    const maxNum = bracket.games.length > 0
      ? Math.max(...bracket.games.map(g => g.gameNumber))
      : 0
    try {
      const r = await fetch(flightApi, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          addGame: {
            gameNumber: maxNum + 1,
            round: addRound,
            section: addSection,
            t1Source: addT1.trim(),
            t2Source: addT2.trim(),
            label: addLabel.trim(),
          },
        }),
      })
      if (!r.ok) throw new Error('Failed to add game')
      const updated = await r.json()
      setBracket(updated)
      setSeeds(updated.seeds || {})
      setFlights(prev => prev.map(f => f.id === updated.id ? updated : f))
      setAddT1(''); setAddT2(''); setAddLabel('')
    } catch (e: any) {
      setError(e.message)
    } finally {
      setAddingGame(false)
    }
  }

  async function handleRenameSeed(seedNum: number, value: string) {
    const next = { ...seeds, [String(seedNum)]: value }
    setSeeds(next)
    if (!bracket) return
    try {
      const r = await fetch(flightApi, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seeds: next }) })
      if (r.ok) { const d = await r.json(); setBracket(prev => prev ? { ...prev, seeds: d.seeds || {} } : prev); setSeeds(d.seeds || {}); setFlights(prev => prev.map(f => f.id === bracket.id ? { ...f, seeds: d.seeds || {} } : f)) }
    } catch { /* ignore */ }
  }

  async function handleRemoveGame(gameNumber: number) {
    if (!confirm(`Remove game B${gameNumber} from the bracket?`)) return
    setRemovingGame(gameNumber)
    try {
      const r = await fetch(flightApi, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ removeGame: gameNumber }),
      })
      if (!r.ok) throw new Error('Failed to remove game')
      const updated = await r.json()
      setBracket(updated)
      setSeeds(updated.seeds || {})
      setFlights(prev => prev.map(f => f.id === updated.id ? updated : f))
    } catch (e: any) {
      setError(e.message)
    } finally {
      setRemovingGame(null)
    }
  }

  async function handleEditGame(gameNumber: number, t1Source: string, t2Source: string) {
    try {
      const r = await fetch(flightApi, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ editGame: { gameNumber, t1Source, t2Source } }),
      })
      if (!r.ok) throw new Error('Failed to edit matchup')
      const updated = await r.json()
      setBracket(updated)
      setSeeds(updated.seeds || {})
      setFlights(prev => prev.map(f => f.id === updated.id ? updated : f))
    } catch (e: any) { setError(e.message) }
  }

  async function handleLabelChange(gameNumber: number, label: string) {
    try {
      await fetch(flightApi, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updateLabel: { gameNumber, label } }),
      })
      setBracket(prev => prev ? { ...prev, games: prev.games.map(g => g.gameNumber === gameNumber ? { ...g, label } : g) } : prev)
      setFlights(prev => prev.map(f => (f.flight || 'A') === activeRef.current ? { ...f, games: f.games.map(g => g.gameNumber === gameNumber ? { ...g, label } : g) } : f))
    } catch { /* ignore */ }
  }

  function quickAddConsolation() {
    if (!bracket) return
    const mainGames = bracket.games.filter(g =>
      g.section === 'winners' || g.section === 'championship'
    )
    const maxRound = mainGames.length > 0
      ? Math.max(...mainGames.map(g => g.round))
      : 1
    const semis = mainGames
      .filter(g => g.round === maxRound - 1)
      .sort((a, b) => a.gameNumber - b.gameNumber)
    setAddSection('consolation')
    setAddRound(maxRound)
    setAddLabel('3rd Place')
    if (semis.length >= 2) {
      setAddT1(`loser:${semis[0].gameNumber}`)
      setAddT2(`loser:${semis[1].gameNumber}`)
    } else {
      setAddT1(''); setAddT2('')
    }
  }

  function switchFlight(fl: string) {
    const target = flights.find(x => (x.flight || 'A') === fl)
    if (!target) return
    setActiveFlight(fl)
    setBracket(target)
    setSeeds(target.seeds || {})
  }

  async function handleSplit() {
    setSplitting(true); setError(null)
    try {
      const total = standings.length || (bracket?.teamCount ?? 0)
      if (total < 3) throw new Error('Need at least 3 ranked teams to split into flights.')
      const cut = Math.max(1, Math.min(parseInt(cutoffInput) || 1, total - 1))
      const seedMap: Record<string, string> = {}
      if (standings.length && poolDone) standings.forEach((r, i) => { seedMap[String(i + 1)] = r.team })
      else Object.assign(seedMap, seeds)
      const r = await fetch(apiBase, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ split: {
          cutoff: cut, total,
          flightA: { format: fmtA === 'owes2' ? 'single' : fmtA, consolationCount: 0, loserConsolation: fmtA === 'owes2' },
          flightB: { format: fmtB === 'owes2' ? 'single' : fmtB, consolationCount: 0, loserConsolation: fmtB === 'owes2' },
          seeds: seedMap,
        } }),
      })
      if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || 'Failed to split') }
      setShowSplit(false)
      activeRef.current = 'A'
      await loadBracket()
      setTab('preview')
    } catch (e: any) { setError(e.message) } finally { setSplitting(false) }
  }

  const totalTeams = standings.length || (bracket?.teamCount ?? 0)
  const cutPreview = Math.max(1, Math.min(parseInt(cutoffInput) || 1, Math.max(1, totalTeams - 1)))
  const flightBCount = Math.max(0, totalTeams - cutPreview)
  // What each flight would be, counted with the same generator the API builds from.
  const planStats = (fmt: SplitFmt, n: number): BracketStats | null =>
    n >= 2 ? bracketStats(buildTemplate(fmt === 'owes2' ? 'single' : fmt, n, 0, fmt === 'owes2'), n, need) : null
  const doubleOk = (n: number) => !!getTemplate('double', n)
  const stA = planStats(fmtA, cutPreview), stB = planStats(fmtB, flightBCount)
  const bracketTotal = (stA?.games ?? 0) + (stB?.games ?? 0)
  const splitFormatPickers = ([['Flight A', fmtA, setFmtA, cutPreview], ['Flight B', fmtB, setFmtB, flightBCount]] as [string, SplitFmt, (v: SplitFmt) => void, number][])
  const splitPanel = (
    <div className="mb-5 rounded-xl border border-teal-500/40 bg-slate-800/80 p-5">
      <p className="text-base font-semibold text-white mb-1">Split into flights</p>
      <p className="text-sm text-slate-300 mb-4">
        Two brackets, each with its own champion. Teams rank by {advanceBy === 'pool' ? 'pool finish' : 'division standings'}, then split at the cutoff.
      </p>

      <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Cutoff</label>
      <div className="flex items-center gap-3 mb-4">
        <input type="number" min={1} value={cutoffInput} onChange={e => setCutoffInput(e.target.value)}
          className="w-20 bg-slate-900 border border-slate-600 text-white text-base rounded-lg px-3 py-2 text-center focus:outline-none focus:border-teal-500" />
        <span className="text-sm text-slate-300">top seeds go to <span className="font-semibold text-teal-300">Flight A</span> · the rest to <span className="font-semibold text-teal-300">Flight B</span></span>
      </div>

      {totalTeams > 0 && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="rounded-lg bg-slate-900/70 border border-slate-700 px-3 py-2.5">
            <p className="text-xs font-semibold text-teal-300 uppercase tracking-wider">Flight A</p>
            <p className="text-sm text-white mt-1">{cutPreview} {cutPreview === 1 ? 'team' : 'teams'}</p>
            <p className="text-xs text-slate-400 mt-0.5">seeds 1–{cutPreview}</p>
            <StatsLine st={stA} need={need} className="mt-1.5" />
          </div>
          <div className="rounded-lg bg-slate-900/70 border border-slate-700 px-3 py-2.5">
            <p className="text-xs font-semibold text-teal-300 uppercase tracking-wider">Flight B</p>
            <p className="text-sm text-white mt-1">{flightBCount} {flightBCount === 1 ? 'team' : 'teams'}</p>
            <p className="text-xs text-slate-400 mt-0.5">{flightBCount > 0 ? `seeds ${cutPreview + 1}–${totalTeams}` : '—'}</p>
            <StatsLine st={stB} need={need} className="mt-1.5" />
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 mb-4">
        {splitFormatPickers.map(([lbl, val, set, n]) => (
          <div key={lbl}>
            <p className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">{lbl} format</p>
            <div className="grid grid-cols-4 gap-1.5">
              {(['single', 'owes2', '2gg', 'double'] as const).map(ff => {
                const off = ff === 'double' && !doubleOk(n)
                const st = off ? null : planStats(ff, n)
                return (
                  <button key={ff} onClick={() => set(ff)} disabled={off}
                    title={off ? 'Double elimination is only built for 4 or 8 teams' : `${SPLIT_FMT_TITLE[ff]}${st ? ` · ${st.games} games` : ''}`}
                    className={`py-1.5 rounded-lg text-xs font-medium border transition-colors disabled:opacity-30 disabled:cursor-not-allowed ${val === ff ? 'bg-teal-600 border-teal-500 text-white' : 'bg-slate-900 border-slate-600 text-slate-300 hover:text-white hover:border-slate-500'}`}>
                    <span className="block">{SPLIT_FMT_LABEL[ff]}</span>
                    <span className={`block text-[10px] leading-tight mt-0.5 ${val === ff ? 'text-teal-100' : st?.short ? 'text-amber-400/90' : 'text-slate-400'}`}>{st ? `${st.games} gm${st.short ? ' · short' : ''}` : '—'}</span>
                  </button>
                )
              })}
            </div>
          </div>
        ))}
      </div>

      {totalTeams > 0 && (
        <div className="mb-3 rounded-lg bg-slate-900/70 border border-slate-700 px-3 py-2 text-sm text-slate-300 flex flex-wrap items-baseline gap-x-2">
          <span>Bracket <b className="text-white">{bracketTotal}</b></span>
          {poolGameCount != null && <><span className="text-slate-500">+</span><span>Pool <b className="text-white">{poolGameCount}</b></span>
            <span className="text-slate-500">=</span><span className="font-semibold text-teal-300">{bracketTotal + poolGameCount} games in the division</span></>}
        </div>
      )}

      <button onClick={handleSplit} disabled={splitting}
        className="w-full py-2.5 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white text-sm font-semibold rounded-xl transition-colors">
        {splitting ? 'Splitting…' : (totalTeams > 0 ? `Split into ${cutPreview} + ${flightBCount} flights` : 'Split into flights')}
      </button>
      {!poolDone && (
        <p className="text-xs text-amber-400/90 mt-3">
          Pool play isn't finished{poolProgress.total > 0 ? ` (${poolProgress.scored} of ${poolProgress.total} games scored)` : ''}, so the flights will show "Seed 1", "Seed 2"… instead of team names. Split again once every pool game has a score, or type seeds by hand.
        </p>
      )}
    </div>
  )

  // ── Loading ────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="flex items-center justify-center h-40 text-slate-400 text-sm">
        Loading bracket…
      </div>
    )
  }

  // ── Setup wizard ───────────────────────────────────────────────────────

  async function setNoBracket(on: boolean) {
    setSavingPoolOnly(true); setError(null)
    try {
      const r = await fetch(`/api/tournaments/${tournamentId}/divisions/${encodeURIComponent(division)}/no-bracket`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ on }),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) { setError(j.error || 'That didn’t save. Try again.'); return }
      setPoolOnly(on)
      onNoBracketChange?.(on)
    } catch { setError('That didn’t save. Check your connection and try again.') }
    finally { setSavingPoolOnly(false) }
  }

  if (!bracket && poolOnly) {
    return (
      <div className="py-6 px-2 max-w-lg" data-testid="pool-only">
        <div className="bg-slate-800 border-2 border-teal-500 rounded-xl p-5">
          <div className="flex items-start gap-3">
            <CheckCircle2 size={22} className="text-teal-300 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <div className="font-semibold text-white text-base">No bracket: pool play only</div>
              <p className="text-slate-300 mt-1 leading-relaxed">This division has no playoffs or championship game. No bracket games are made or scheduled for it: <b className="text-white">Generate all divisions</b> skips it, and a bracket can&rsquo;t be built here until this is turned off.</p>
              <button onClick={() => setNoBracket(false)} disabled={savingPoolOnly}
                className="mt-4 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-700 text-teal-300 border border-slate-600 hover:border-teal-500 disabled:opacity-60 transition-colors">
                {savingPoolOnly ? 'Saving…' : 'This division has a bracket after all'}
              </button>
            </div>
          </div>
        </div>
        {error && <div className="mt-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-3">{error}</div>}
      </div>
    )
  }

  if (!bracket) {
    const selCount = Math.max(2, parseInt(selCountInput) || 2)
    const consN = Math.max(0, parseInt(consolationInput) || 0)
    const owes = loserConsolation && selFormat !== '2gg'
    // A fixed template's blurb ("7 games · 1 champion") is wrong once loser-fed games are added.
    const entry = owes ? undefined : TEMPLATE_CATALOG.find(t => t.key === `${selFormat}-${selCount}`)
    // Every team in the division counts: teams past the bracket's seeds play only
    // the consolation slots (or nothing).
    const singleStats = bracketStats(buildTemplate(selFormat, selCount, owes ? 0 : consN, owes), Math.max(selCount, divisionTeams ?? selCount), need)

    return (
      <div className="py-6 px-2 max-w-lg">
        <p className="text-sm text-slate-400 mb-6">
          No bracket yet. Choose a format and team count, then add or remove games as needed.
        </p>

        {/* First question: is there a bracket at all? */}
        <label className="mb-5 flex items-start gap-3 bg-slate-800 border border-slate-700 hover:border-teal-500 rounded-xl p-4 cursor-pointer transition-colors" data-testid="no-bracket-box">
          <input type="checkbox" checked={savingPoolOnly} disabled={savingPoolOnly} onChange={() => setNoBracket(true)} className="mt-0.5 w-4 h-4 accent-teal-500" />
          <span className="text-sm">
            <span className="font-semibold text-white">No bracket: pool play only</span>
            <span className="block text-slate-400 mt-0.5">Tick this when the division has no playoffs or championship game. No bracket games are made or scheduled for it.</span>
          </span>
        </label>

        <div className="mb-5">
          <button onClick={() => setShowSplit(v => !v)}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-teal-300 border border-slate-700 hover:border-teal-500 transition-colors">
            {showSplit ? '← Single bracket' : 'Split into flights (2 champions)'}
          </button>
        </div>
        {showSplit && splitPanel}

        {error && (
          <div className="mb-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-3">
            {error}
          </div>
        )}

        {!showSplit && (<>
        <div className="mb-5">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Format</p>
          <div className="grid grid-cols-3 gap-2">
            {(['single', 'double', '2gg'] as const).map(fmt => (
              <button
                key={fmt}
                onClick={() => setSelFormat(fmt)}
                className={`py-3 px-2 rounded-lg border text-sm font-medium text-center transition-all ${
                  selFormat === fmt
                    ? 'bg-teal-600 border-teal-500 text-white shadow-lg shadow-teal-900/30'
                    : 'bg-slate-800 border-slate-600 text-slate-300 hover:border-slate-500 hover:text-white'
                }`}
              >
                {FORMAT_LABELS[fmt]}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-5 grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Teams in bracket
            </label>
            <input
              type="number" min="2" max="64"
              value={selCountInput}
              onChange={e => setSelCountInput(e.target.value)}
              className="w-full bg-slate-800 border border-slate-600 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-teal-500"
              placeholder="e.g. 2"
            />
            <p className="text-xs text-slate-600 mt-1">Top N seeds advance to bracket</p>
          </div>
          <div>
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Consolation games
            </label>
            <input
              type="number" min="0" max="20"
              value={consolationInput}
              onChange={e => setConsolationInput(e.target.value)}
              className="w-full bg-slate-800 border border-slate-600 text-white text-sm rounded-lg px-3 py-2.5 focus:outline-none focus:border-teal-500"
              placeholder="0"
            />
            <p className="text-xs text-slate-600 mt-1">Extra consolation game slots</p>
          </div>
        </div>

        {selFormat !== '2gg' && (
        <label className="mb-5 flex items-start gap-3 bg-slate-800 border border-slate-700 rounded-xl p-4 cursor-pointer">
          <input type="checkbox" checked={loserConsolation} onChange={e => setLoserConsolation(e.target.checked)} className="mt-0.5 accent-teal-500" />
          <span className="text-sm">
            <span className="font-semibold text-white">2-game guarantee · every team plays a 2nd game</span>
            <span className="block text-slate-400 mt-0.5">For 2 pool-game divisions. All teams play; first-round losers get a loser-fed consolation game (plus auto &ldquo;if needed&rdquo; games), so the bracket fills the 4-game guarantee. Set &ldquo;Teams in bracket&rdquo; to the full team count.</span>
          </span>
        </label>
        )}

        <div className="mb-5 bg-slate-800 border border-slate-700 rounded-xl p-4 text-sm">
          {entry ? (
            <>
              <div className="font-semibold text-white">{entry.label} · {entry.teamCount} teams</div>
              <div className="text-slate-400 mt-0.5">{entry.description}</div>
            </>
          ) : (
            <>
              <div className="font-semibold text-white">
                {FORMAT_LABELS[selFormat]} · {selCount} team{selCount !== 1 ? 's' : ''}
              </div>
              <div className="text-slate-400 mt-0.5">
                {selFormat === '2gg' ? 'Losers get loser-fed consolation games · ' : owes ? 'First-round losers get a loser-fed 2nd game · ' : ''}bracket generated automatically
                {parseInt(consolationInput) > 0 && ` · ${consolationInput} consolation slot${parseInt(consolationInput) > 1 ? 's' : ''}`}
              </div>
            </>
          )}
          <StatsLine st={singleStats} need={need} className="mt-2" />
          {poolGameCount != null && (
            <p className="text-xs text-slate-400 mt-1">Bracket {singleStats.games} + pool {poolGameCount} = <span className="font-semibold text-teal-300">{singleStats.games + poolGameCount} games in the division</span></p>
          )}
        </div>

        <button
          onClick={handleCreate}
          disabled={creating}
          className="w-full py-3 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white font-semibold rounded-xl transition-colors text-sm"
        >
          {creating ? 'Creating…' : 'Generate Bracket'}
        </button>
        </>)}
      </div>
    )
  }

  // ── Bracket exists ─────────────────────────────────────────────────────

  const entry = TEMPLATE_CATALOG.find(e => e.key === `${bracket.format}-${bracket.teamCount}`)

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          {/* These were text-white and text-slate-400 -- styles for the dark panel
              this component used to sit in. On the white card it renders on now,
              "Double Elimination" was white on white and simply could not be read. */}
          <span className="font-semibold text-slate-800 text-sm">
            {entry?.label ?? FORMAT_LABELS[bracket.format] ?? bracket.format}
          </span>
          <span className="ml-2 text-slate-500 text-sm">
            {bracket.teamCount} seeds · {bracket.games.length} games
          </span>
        </div>
        <div className="flex items-center gap-1">
          {(['seeding', 'preview'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                tab === t
                  ? 'bg-teal-600 text-white'
                  : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
              }`}
            >
              {t === 'seeding' ? 'Seeds' : 'Preview'}
            </button>
          ))}
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="ml-2 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors disabled:opacity-40"
          >
            {deleting ? 'Deleting…' : 'Reset'}
          </button>
        </div>
      </div>

      {/* Flight switcher / split control */}
      <div className="mb-4 flex items-center gap-2 flex-wrap">
        {flights.length > 1 ? (
          <>
            <span className="text-[11px] text-slate-500 uppercase tracking-wider mr-1">Flights</span>
            {flights.map(f => {
              const fl = f.flight || 'A'
              return (
                <button key={fl} onClick={() => switchFlight(fl)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${activeFlight === fl ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'}`}>
                  Flight {fl} · {f.teamCount}
                </button>
              )
            })}
          </>
        ) : (
          <button onClick={() => setShowSplit(v => !v)}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-teal-300 border border-slate-700 hover:border-teal-500 transition-colors">
            {showSplit ? 'Cancel split' : 'Split into flights (2 champions)'}
          </button>
        )}
      </div>

      {showSplit && flights.length <= 1 && splitPanel}

      {error && (
        <div className="mb-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-3">
          {error}
        </div>
      )}

      {/* ── Seeds tab ─────────────────────────────────────────────────────── */}
      {tab === 'seeding' && (
        <div>
          <p className="text-sm text-slate-400 mb-4">
            Enter team names for each seed. Leave blank to show "Seed N" on the bracket.
          </p>
          {standings.length > 0 && (
            <div className="mb-5 rounded-xl border border-slate-700 overflow-hidden bg-slate-800">
              <div className="flex items-center justify-between px-3 py-2 bg-slate-900">
                <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">{!poolDone ? 'Standings so far' : advanceBy === 'pool' ? 'Seed order · by pool finish' : 'Seed order · division standings'}</span>
                {poolDone ? (
                  <button onClick={() => { const next = { ...seeds }; standings.forEach((r, i) => { next[String(i + 1)] = r.team }); setSeeds(next) }}
                    className="text-[11px] text-teal-300 hover:text-teal-200">Seed from standings ↓</button>
                ) : (
                  <span className="text-[11px] text-amber-300">{poolProgress.scored} of {poolProgress.total} pool games scored · seed after pool play</span>
                )}
              </div>
              <table className="w-full text-xs">
                <thead className="bg-slate-900 text-slate-400">
                  <tr>
                    <th className="text-left px-3 py-1.5 font-semibold">#</th>
                    <th className="text-left px-2 py-1.5 font-semibold">Team</th>
                    <th className="px-2 py-1.5 font-semibold">W-L{standings.some(x => x.t > 0) ? '-T' : ''}</th>
                    <th className="px-2 py-1.5 font-semibold">GF</th>
                    <th className="px-2 py-1.5 font-semibold">GA</th>
                    <th className="px-2 py-1.5 font-semibold">Diff</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700">
                  {standings.map((r, i) => (
                    <tr key={r.team}>
                      <td className="px-3 py-1.5 text-slate-400">{i + 1}</td>
                      <td className="px-2 py-1.5 font-medium text-white">{r.team}</td>
                      <td className="px-2 py-1.5 text-center text-slate-200">{r.w}-{r.l}{standings.some(x => x.t > 0) ? `-${r.t}` : ''}</td>
                      <td className="px-2 py-1.5 text-center text-slate-200">{r.gf}</td>
                      <td className="px-2 py-1.5 text-center text-slate-200">{r.ga}</td>
                      <td className={`px-2 py-1.5 text-center font-medium ${r.gf - r.ga > 0 ? 'text-emerald-400' : r.gf - r.ga < 0 ? 'text-red-400' : 'text-slate-400'}`}>{r.gf - r.ga > 0 ? '+' : ''}{r.gf - r.ga}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-5">
            {Array.from({ length: Math.max(bracket.teamCount, ...bracket.games.flatMap(g => [g.team1Source, g.team2Source]).filter(x => !!x && x.startsWith('seed:')).map(x => parseInt(x.split(':')[1]) || 0)) }, (_, i) => i + 1).map(n => (
              <div key={n} className="flex items-center gap-3">
                <span className="text-xs font-semibold text-slate-500 w-12 text-right shrink-0">#{n}</span>
                <input
                  type="text"
                  value={seeds[String(n)] ?? ''}
                  onChange={e => setSeeds(prev => ({ ...prev, [String(n)]: e.target.value }))}
                  placeholder={`Seed ${n}`}
                  className="flex-1 bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500/30"
                />
              </div>
            ))}
          </div>
          <button
            onClick={handleSaveSeeds}
            disabled={saving}
            className="px-6 py-2.5 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white font-semibold rounded-xl transition-colors text-sm"
          >
            {saving ? 'Saving…' : 'Save Seeds'}
          </button>
          <p className="mt-3 text-xs text-slate-500">
            After saving, click <strong className="text-slate-400">Preview</strong> to see the bracket.
          </p>
        </div>
      )}

      {/* ── Add/remove games panel (toggled from Preview via '+ Add game') ── */}
      {tab === 'preview' && showAddGame && (
        <div>
          <p className="text-sm text-slate-400 mb-4">
            Add or remove games. Changes apply immediately.
          </p>

          {/* Game list grouped by section */}
          {bracket.games.length === 0 ? (
            <p className="text-sm text-slate-500 italic mb-5">No games yet — add one below.</p>
          ) : (
            <div className="mb-6 space-y-4">
              {(['winners', 'championship', 'consolation', 'losers'] as const)
                .map(sec => {
                  const games = bracket.games
                    .filter(g => g.section === sec)
                    .sort((a, b) => a.gameNumber - b.gameNumber)
                  if (games.length === 0) return null
                  return (
                    <div key={sec}>
                      <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                        {SECTION_LABELS[sec]}
                      </p>
                      <div className="space-y-1">
                        {games.map(g => (
                          <div
                            key={g.gameNumber}
                            className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2"
                          >
                            <span className="text-xs font-mono text-slate-500 w-8 shrink-0">B{(bracket.numberOffset || 0) + g.gameNumber}</span>
                            <span className="text-xs text-slate-500 shrink-0">R{g.round}</span>
                            <span className="flex-1 text-xs text-slate-300 truncate font-mono">
                              {g.team1Source} <span className="text-slate-600 font-sans">vs</span> {g.team2Source}
                            </span>
                            {g.label && (
                              <span className="text-xs text-amber-400 shrink-0 mr-1">{g.label}</span>
                            )}
                            <button
                              onClick={() => handleRemoveGame(g.gameNumber)}
                              disabled={removingGame === g.gameNumber}
                              className="text-slate-600 hover:text-red-400 transition-colors text-sm shrink-0 w-6 text-center"
                              title="Remove game"
                            >
                              {removingGame === g.gameNumber ? '…' : '✕'}
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })}
            </div>
          )}

          {/* Add game form */}
          <div className="bg-slate-800/60 border border-slate-700 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Add Game</p>
              <button
                onClick={quickAddConsolation}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-700 text-teal-400 hover:bg-slate-600 transition-colors"
              >
                ⚡ Quick Consolation
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-3">
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Section</label>
                <select
                  value={addSection}
                  onChange={e => setAddSection(e.target.value)}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-2 py-1.5 text-sm text-white focus:outline-none focus:border-teal-500"
                >
                  <option value="winners">Winners</option>
                  <option value="consolation">Consolation</option>
                  <option value="championship">Championship</option>
                  <option value="losers">Losers</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Round</label>
                <input
                  type="number"
                  min={1}
                  value={addRound}
                  onChange={e => setAddRound(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-2 py-1.5 text-sm text-white focus:outline-none focus:border-teal-500"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Team 1 source</label>
                <input
                  type="text"
                  value={addT1}
                  onChange={e => setAddT1(e.target.value)}
                  placeholder="seed:1 or winner:3"
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-2 py-1.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-teal-500"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 mb-1 block">Team 2 source</label>
                <input
                  type="text"
                  value={addT2}
                  onChange={e => setAddT2(e.target.value)}
                  placeholder="seed:4 or loser:3"
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-2 py-1.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-teal-500"
                />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-slate-500 mb-1 block">Label <span className="text-slate-600">(optional)</span></label>
                <input
                  type="text"
                  value={addLabel}
                  onChange={e => setAddLabel(e.target.value)}
                  placeholder="e.g. 3rd Place, Gold, Consolation Final"
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-2 py-1.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-teal-500"
                />
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Source syntax: <code className="text-slate-500 bg-slate-900/50 px-1 rounded">seed:N</code>{' '}
              <code className="text-slate-500 bg-slate-900/50 px-1 rounded">winner:N</code>{' '}
              <code className="text-slate-500 bg-slate-900/50 px-1 rounded">loser:N</code>
              {' '}where N is a game number (e.g. winner:3 = winner of B3)
            </p>

            <button
              onClick={handleAddGame}
              disabled={addingGame || !addT1.trim() || !addT2.trim()}
              className="px-5 py-2 bg-teal-600 hover:bg-teal-500 disabled:opacity-40 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              {addingGame ? 'Adding…' : '+ Add Game'}
            </button>
          </div>
        </div>
      )}

      {/* ── Preview tab ───────────────────────────────────────────────────── */}
      {tab === 'preview' && (bracket.format === '2gg' && bracket.games.some(g => (g.label || '').toLowerCase().includes('consolation championship')) ? (
        <MirrorPreview
          logos={logos}
          numberOffset={bracket.numberOffset || 0}
          schedule={schedule}
          template={bracket.games.map(g => ({
            gameNumber: g.gameNumber,
            round: g.round,
            section: g.section as 'winners' | 'losers' | 'consolation' | 'championship',
            t1: g.team1Source,
            t2: g.team2Source,
            label: g.label || undefined,
          }))}
          seeds={seeds}
          division={division}
          onRemoveGame={handleRemoveGame}
          onAddGame={() => setShowAddGame(v => !v)}
        />
      ) : (
        <BracketPreview
          logos={logos}
          numberOffset={bracket.numberOffset || 0}
          schedule={schedule}
          template={bracket.games.map(g => ({
            gameNumber: g.gameNumber,
            round: g.round,
            section: g.section as 'winners' | 'losers' | 'consolation' | 'championship',
            t1: g.team1Source,
            t2: g.team2Source,
            label: g.label || undefined,
          }))}
          seeds={seeds}
          division={division}
          onLabelChange={handleLabelChange}
          onRemoveGame={handleRemoveGame}
          onEditGame={handleEditGame}
          onRenameSeed={handleRenameSeed}
          onAddGame={() => setShowAddGame(v => !v)}
        />
      ))}
    </div>
  )
}

// ── Visual Bracket Preview ─────────────────────────────────────────────────

function resolveLabel(src: string, seeds: Record<string, string>, offset = 0): string {
  if (!src) return 'TBD'
  const [type, n] = src.split(':')
  if (type === 'seed') return seeds[n] || `Seed ${n}`
  if (type === 'winner') return `W-B${offset + Number(n)}`
  if (type === 'loser') return `L-B${offset + Number(n)}`
  return src
}

// ── Both-ways consolation tournament (mirror) preview ──────────────────────
function MirrorPreview({ template, seeds, division, numberOffset = 0, logos = {}, schedule = {}, onRemoveGame, onAddGame }: {
  template: GameTemplate[]
  seeds: Record<string, string>
  division?: string
  numberOffset?: number
  logos?: Record<string, string>
  schedule?: Record<number, { date: string; startTime: string; location: string }>
  onRemoveGame?: (gameNumber: number) => void
  onAddGame?: () => void
}) {
  const ROW = 120
  const [zoom, setZoom] = useState(1)
  const HALF_BAR = (BAR_H + BAR_GAP) / 2
  const isWin = (g: GameTemplate) => g.section === 'winners' || g.section === 'championship'
  const wins = template.filter(isWin)
  const cons = template.filter(g => !isWin(g))
  if (wins.length === 0) return <div className="text-center py-10 text-slate-500 text-sm">No bracket games yet.</div>
  const byNum: Record<number, GameTemplate> = {}; template.forEach(g => { byNum[g.gameNumber] = g })
  const feederNums = (g: GameTemplate) => [g.t1, g.t2].map(src => { const m = (src || '').match(/^(winner|loser):(\d+)$/); const n = m ? parseInt(m[2]) : NaN; return byNum[n] ? n : null })
  const minWinRound = Math.min(...wins.map(g => g.round))
  const r1 = wins.filter(g => g.round === minWinRound).map(g => g.gameNumber)
  const consSet = new Set<number>(); let ch = true
  while (ch) { ch = false; for (const g of cons) { if (consSet.has(g.gameNumber)) continue
    const ok = [g.t1, g.t2].some(src => { const m = (src || '').match(/^(winner|loser):(\d+)$/); if (!m) return false; const ref = parseInt(m[2]); if (src.startsWith('loser:') && r1.includes(ref)) return true; if (consSet.has(ref)) return true; return false })
    if (ok) { consSet.add(g.gameNumber); ch = true } } }
  const consBracket = cons.filter(g => consSet.has(g.gameNumber))
  const placement = cons.filter(g => !consSet.has(g.gameNumber))
  const mir = [...wins, ...consBracket]
  const inMir = new Set(mir.map(g => g.gameNumber))
  const fOf = (g: GameTemplate) => feederNums(g).map(n => n != null && inMir.has(n) ? n : null)
  const referenced = new Set<number>(); mir.forEach(g => fOf(g).forEach(n => { if (n != null) referenced.add(n) }))
  const roots = mir.filter(g => !referenced.has(g.gameNumber)).sort((a, b) => b.round - a.round || a.gameNumber - b.gameNumber)
  const rough: Record<number, number> = {}; let ls0 = 0
  const roughY = (num: number): number => { if (rough[num] !== undefined) return rough[num]; const g = byNum[num]; if (!g) return 0; const [a, b] = fOf(g); const cs: number[] = []; if (a != null) cs.push(roughY(a)); if (b != null) cs.push(roughY(b)); const y = cs.length ? cs.reduce((p, q) => p + q, 0) / cs.length : (ls0++ * ROW); rough[num] = y; return y }
  roots.forEach(r => roughY(r.gameNumber)); mir.forEach(g => { if (rough[g.gameNumber] === undefined) rough[g.gameNumber] = ls0++ * ROW })
  const rv = mir.map(g => rough[g.gameNumber]); const mid = rv.length ? (Math.min(...rv) + Math.max(...rv)) / 2 : 0
  const winnerTopOf: Record<number, boolean> = {}; const yByNum: Record<number, number> = {}; let leaf = 0
  const placeY = (num: number): number => { if (yByNum[num] !== undefined) return yByNum[num]; const g = byNum[num]; if (!g) return 0; const [f1, f2] = fOf(g); let y: number; if (f1 != null && f2 != null) y = (placeY(f1) + placeY(f2)) / 2; else if (f1 != null || f2 != null) { const fN = (f1 != null ? f1 : f2) as number; const wt = rough[fN] <= mid; winnerTopOf[num] = wt; y = placeY(fN) + (wt ? HALF_BAR : -HALF_BAR) } else y = leaf++ * ROW; yByNum[num] = y; return y }
  roots.forEach(r => placeY(r.gameNumber)); mir.forEach(g => { if (yByNum[g.gameNumber] === undefined) yByNum[g.gameNumber] = leaf++ * ROW })
  const minY = Math.min(0, ...mir.map(g => yByNum[g.gameNumber]))
  const stepX = GAME_W + CONN_W
  const maxWinDepth = Math.max(0, ...wins.map(g => g.round - minWinRound))
  const maxConsDepth = consBracket.length ? Math.max(...consBracket.map(g => g.round - minWinRound)) : 0
  const CX = maxConsDepth * stepX + 10
  const colX = (g: GameTemplate) => isWin(g) ? CX + (g.round - minWinRound) * stepX : CX - (g.round - minWinRound) * stepX
  const pos: Record<number, { x: number; y: number; cy: number }> = {}
  mir.forEach(g => { const y = yByNum[g.gameNumber] - minY + TOP_PAD + 14 + 30; pos[g.gameNumber] = { x: colX(g), y, cy: y + BAR_H + BAR_GAP / 2 } })
  const canvasW = CX + maxWinDepth * stepX + GAME_W + 10
  const canvasH = Math.max(160, ...mir.map(g => pos[g.gameNumber].y + 2 * BAR_H + BAR_GAP)) + 20
  const conns: JSX.Element[] = []
  mir.forEach(g => { const p = pos[g.gameNumber]; if (!p) return; const win = isWin(g)
    fOf(g).forEach(fn => { if (fn == null) return; const fp = pos[fn]; if (!fp) return
      const fx = win ? fp.x + GAME_W : fp.x; const tx = win ? p.x : p.x + GAME_W; const mx = (fx + tx) / 2
      conns.push(<path key={`c${g.gameNumber}-${fn}`} d={`M${fx},${fp.cy} H${mx} V${p.cy} H${tx}`} fill="none" stroke="#475569" strokeWidth="1.5" />) }) })
  const champGame = wins.find(g => g.section === 'championship') || wins.slice().sort((a, b) => b.round - a.round)[0]
  const consFinal = consBracket.length ? consBracket.slice().sort((a, b) => b.round - a.round)[0] : null
  const cP = champGame ? pos[champGame.gameNumber] : null
  const kP = consFinal ? pos[consFinal.gameNumber] : null
  const bar = (g: GameTemplate, src: string, idx: number, isChamp: boolean) => {
    const p = pos[g.gameNumber]; const top = p.y + (idx === 0 ? 0 : BAR_H + BAR_GAP)
    const [type, n] = (src || '').split(':'); const isSeed = type === 'seed'
    const nm = resolveLabel(src, seeds, numberOffset); const computed = nm.startsWith('W-') || nm.startsWith('L-')
    const named = !!nm && !nm.startsWith('Seed ') && !computed; const logo = named ? logos[nm] : ''
    const [fa, fb] = fOf(g); const bye = (fa != null) !== (fb != null)
    return (
      <div key={idx} style={{ position: 'absolute', left: p.x, top, width: GAME_W, height: BAR_H }}
        className={`flex items-center rounded-md border overflow-hidden ${isChamp ? 'border-amber-400/60 bg-amber-950/40' : 'border-slate-600/80 bg-slate-800/95'}`}>
        <span className={`h-full flex items-center justify-center text-[11px] font-semibold shrink-0 ${isSeed ? (bye ? 'bg-amber-500 text-white' : 'bg-teal-600 text-white') : 'bg-slate-700/80 text-slate-500'}`} style={{ width: 24 }}>{isSeed ? n : ''}</span>
        {logo
          ? <img src={logo} alt="" className="rounded-full object-cover ml-2 mr-1.5 shrink-0 bg-white" style={{ width: 18, height: 18 }} />
          : <span className="rounded-full bg-slate-700 text-slate-300 text-[9px] flex items-center justify-center ml-2 mr-1.5 shrink-0" style={{ width: 18, height: 18 }}>{named ? nm.charAt(0).toUpperCase() : ''}</span>}
        <span className={`flex-1 min-w-0 pr-2 truncate text-xs font-medium ${computed ? 'text-slate-400 italic' : 'text-white'}`}>{nm}</span>
      </div>
    )
  }
  return (
    <div>
      <div className="flex items-center justify-between gap-2 mb-2">
        <p className="text-[10px] text-slate-500">Both-ways consolation &middot; winners &rarr; Champion (right), losers &rarr; Consolation Champion (left) &middot; &times; removes a game</p>
        {onAddGame && <button onClick={onAddGame} className="text-[11px] text-slate-400 hover:text-teal-300 shrink-0">+ Add game</button>}
      </div>
      <div className="flex items-center gap-1 mb-2 text-slate-500">
        <span className="text-[10px] mr-1 uppercase tracking-wider">Zoom</span>
        <button onClick={() => setZoom(z => Math.max(0.5, Math.round((z - 0.15) * 100) / 100))} className="w-5 h-5 rounded border border-slate-600 text-slate-300 hover:bg-slate-700 text-xs leading-none">−</button>
        <span className="text-[10px] w-9 text-center text-slate-400">{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom(z => Math.min(1, Math.round((z + 0.15) * 100) / 100))} className="w-5 h-5 rounded border border-slate-600 text-slate-300 hover:bg-slate-700 text-xs leading-none">+</button>
      </div>
      <div className="overflow-x-auto pb-2">
        <div style={{ width: canvasW * zoom, height: canvasH * zoom }}>
        <div style={{ position: 'relative', width: canvasW, height: canvasH, transformOrigin: 'top left', transform: zoom !== 1 ? `scale(${zoom})` : undefined }}>
          <svg style={{ position: 'absolute', top: 0, left: 0, width: canvasW, height: canvasH, pointerEvents: 'none' }} viewBox={`0 0 ${canvasW} ${canvasH}`}>{conns}</svg>
          {mir.map(g => {
            const p = pos[g.gameNumber]; if (!p) return null
            const isChamp = g.section === 'championship'
            const sched = schedule[numberOffset + g.gameNumber]
            const st = sched ? [sched.startTime, (sched.location || '').split(' - ').pop() || sched.location].map(x => (x || '').trim()).filter(Boolean).join(' · ') : ''
            const lbl = g.label || (isChamp ? 'Championship' : '')
            const [fa, fb] = fOf(g); const byeG = (fa != null) !== (fb != null)
            let topSrc = g.t1, botSrc = g.t2
            if (byeG) { const feederSrc = fa != null ? g.t1 : g.t2; const byeSrc = fa != null ? g.t2 : g.t1; if (winnerTopOf[g.gameNumber]) { topSrc = feederSrc; botSrc = byeSrc } else { topSrc = byeSrc; botSrc = feederSrc } }
            return (
              <div key={g.gameNumber}>
                <div style={{ position: 'absolute', left: p.x, top: p.cy - BAR_GAP / 2 - BAR_H - 14, width: GAME_W }} className="flex items-center justify-between gap-1">
                  <span className="text-[9px] font-mono text-teal-300/80 px-0.5 shrink-0">B{numberOffset + g.gameNumber}</span>
                  <span className="flex-1 text-center text-[8px] truncate px-1 text-slate-400">{st}</span>
                  {lbl && <span className={`text-[9px] font-semibold shrink-0 ${isChamp ? 'text-amber-400' : 'text-amber-400/70'}`}>{lbl}</span>}
                  {onRemoveGame && <button onClick={() => onRemoveGame(g.gameNumber)} title="Remove game" className="text-[11px] leading-none text-slate-500 hover:text-red-400 shrink-0">&times;</button>}
                </div>
                {bar(g, topSrc, 0, isChamp)}
                {bar(g, botSrc, 1, isChamp)}
              </div>
            )
          })}
          {cP && <div style={{ position: 'absolute', left: cP.x, top: Math.max(2, cP.y - 58), width: GAME_W, height: 38 }} className="flex items-center justify-center rounded-lg bg-amber-600 text-white font-bold text-xs">{division ? `${division} Champion` : 'Champion'}</div>}
          {kP && <div style={{ position: 'absolute', left: kP.x, top: Math.max(2, kP.y - 58), width: GAME_W, height: 38 }} className="flex items-center justify-center rounded-lg bg-slate-600 text-white font-semibold text-xs">Consolation Champion</div>}
        </div>
        </div>
      </div>
      {placement.length > 0 && (
        <div className="mt-4 pt-3 border-t border-slate-700">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Placement</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {placement.map(g => (
              <div key={g.gameNumber} className="rounded-lg border border-slate-600/80 bg-slate-800/90 text-xs overflow-hidden">
                <div className="px-2 py-0.5 bg-black/20 text-[10px] font-mono text-teal-300 flex items-center justify-between">
                  <span>B{numberOffset + g.gameNumber}{g.label ? ` · ${g.label}` : ''}</span>
                  {onRemoveGame && <button onClick={() => onRemoveGame(g.gameNumber)} title="Remove game" className="text-[11px] leading-none text-slate-500 hover:text-red-400">&times;</button>}
                </div>
                {[g.t1, g.t2].map((src, i) => <div key={i} className={`px-2 py-1 truncate text-white ${i === 0 ? 'border-b border-slate-700' : ''}`}>{resolveLabel(src, seeds, numberOffset)}</div>)}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function BracketPreview({ template, seeds, division, numberOffset = 0, logos = {}, schedule = {}, onLabelChange, onRemoveGame, onEditGame, onRenameSeed, onAddGame }: {
  template: GameTemplate[]
  seeds: Record<string, string>
  division?: string
  numberOffset?: number
  logos?: Record<string, string>
  schedule?: Record<number, { date: string; startTime: string; location: string }>
  onLabelChange?: (gameNumber: number, label: string) => void
  onRemoveGame?: (gameNumber: number) => void
  onEditGame?: (gameNumber: number, t1: string, t2: string) => void
  onRenameSeed?: (seedNum: number, value: string) => void
  onAddGame?: () => void
}) {
  const [editingLabel, setEditingLabel] = useState<{ gameNumber: number; value: string } | null>(null)
  const [editingSeat, setEditingSeat] = useState<{ gameNumber: number; slot: number; value: string } | null>(null)
  const [editingFeeders, setEditingFeeders] = useState<{ gameNumber: number; t1: string; t2: string } | null>(null)
  const allGameNums = template.map(g => g.gameNumber)
  const maxSeedNum = Math.max(0, ...template.flatMap(g => [g.t1, g.t2]).filter(x => (x || '').startsWith('seed:')).map(x => parseInt(x.split(':')[1]) || 0))
  const sourceOptions = [
    ...Array.from({ length: maxSeedNum }, (_, i) => ({ v: `seed:${i + 1}`, l: `Seed ${i + 1}` })),
    ...allGameNums.map(n => ({ v: `winner:${n}`, l: `W-B${numberOffset + n}` })),
    ...allGameNums.map(n => ({ v: `loser:${n}`, l: `L-B${numberOffset + n}` })),
  ]

  const schedText = (n: number, short: boolean) => {
    const sc = schedule[n]
    if (!sc) return ''
    const parts = short ? [sc.startTime, sc.location] : [sc.date, sc.startTime, sc.location]
    return parts.map(x => (x || '').trim()).filter(Boolean).join(' · ')
  }

  function renderSlot(gameNumber: number, src: string, slot: number) {
    const label = resolveLabel(src, seeds, numberOffset)
    const computed = label.startsWith('W-') || label.startsWith('L-')
    if (src.startsWith('seed:') && onRenameSeed) {
      const seedNum = parseInt(src.split(':')[1])
      if (editingSeat && editingSeat.gameNumber === gameNumber && editingSeat.slot === slot) {
        return (
          <input autoFocus value={editingSeat.value} placeholder={`Seed ${seedNum}`}
            onChange={e => setEditingSeat({ gameNumber, slot, value: e.target.value })}
            onBlur={() => { onRenameSeed(seedNum, editingSeat.value); setEditingSeat(null) }}
            onKeyDown={e => { if (e.key === 'Enter' || e.key === 'Escape') { onRenameSeed(seedNum, editingSeat.value); setEditingSeat(null) } }}
            className="bg-transparent border-b border-teal-400 text-white text-xs outline-none w-full" />
        )
      }
      return (
        <button onClick={() => setEditingSeat({ gameNumber, slot, value: seeds[String(seedNum)] ?? '' })}
          title="Click to rename" className="truncate text-xs font-medium text-left w-full text-white hover:text-teal-300 cursor-text">{label}</button>
      )
    }
    return <span className={`truncate text-xs font-medium ${computed ? 'text-slate-400 italic' : 'text-white'}`}>{label}</span>
  }

  const mainGames = template.filter(g => g.section === 'winners' || g.section === 'championship')
  const sideGames = template.filter(g => g.section === 'consolation' || g.section === 'losers')
  const mainRounds = [...new Set(mainGames.map(g => g.round))].sort((a, b) => a - b)
  const maxRound = mainRounds.length > 0 ? Math.max(...mainRounds) : 1

  function colLeft(r: number) { return (r - 1) * (GAME_W + CONN_W) }

  // ── Feeder-graph layout ──────────────────────────────────────────────
  // Position each game from the games that feed it rather than a fixed
  // per-round formula. A game fed by a single round-N game (because its other
  // slot is a BYE) sits in line with that feeder, so the connector is straight
  // and the winner's next game is directly to the right. A game fed by two
  // games centers between them.
  const mainByNum: Record<number, GameTemplate> = {}
  mainGames.forEach(g => { mainByNum[g.gameNumber] = g })
  const feederOf = (g: GameTemplate): (number | null)[] =>
    [g.t1, g.t2].map(src => {
      const [type, n] = (src || '').split(':')
      const num = parseInt(n)
      return (type === 'winner' || type === 'loser') && mainByNum[num] ? num : null
    })
  const referenced = new Set<number>()
  mainGames.forEach(g => feederOf(g).forEach(fn => { if (fn) referenced.add(fn) }))
  const roots = mainGames
    .filter(g => !referenced.has(g.gameNumber))
    .sort((a, b) => b.round - a.round || a.gameNumber - b.gameNumber)
  const yByNum: Record<number, number> = {}
  let leafSlot = 0
  const HALF_BAR = (BAR_H + BAR_GAP) / 2
  // Pass 1: rough positions (byes centred) to learn each game's half of the bracket.
  const ROW = 120
  const rough: Record<number, number> = {}
  let ls0 = 0
  const roughY = (num: number): number => {
    if (rough[num] !== undefined) return rough[num]
    const g = mainByNum[num]; if (!g) return 0
    const [a, b] = feederOf(g)
    const cs: number[] = []
    if (a != null) cs.push(roughY(a))
    if (b != null) cs.push(roughY(b))
    const y = cs.length ? cs.reduce((p, q) => p + q, 0) / cs.length : (ls0++ * ROW)
    rough[num] = y; return y
  }
  roots.forEach(r => roughY(r.gameNumber))
  mainGames.forEach(g => { if (rough[g.gameNumber] === undefined) rough[g.gameNumber] = ls0++ * ROW })
  const roughVals = mainGames.map(g => rough[g.gameNumber])
  const mid = roughVals.length ? (Math.min(...roughVals) + Math.max(...roughVals)) / 2 : 0
  // Pass 2: final positions. For a bye game, align the winner-feeder bar with its feeder
  // (winner toward the outer edge, bye toward centre) so it reads as a real matchup.
  const winnerTopOf: Record<number, boolean> = {}
  const placeY = (num: number): number => {
    if (yByNum[num] !== undefined) return yByNum[num]
    const g = mainByNum[num]; if (!g) return 0
    const [f1, f2] = feederOf(g)
    let y: number
    if (f1 != null && f2 != null) {
      y = (placeY(f1) + placeY(f2)) / 2
    } else if (f1 != null || f2 != null) {
      const fNum = (f1 != null ? f1 : f2) as number
      const winnerTop = rough[fNum] <= mid
      winnerTopOf[num] = winnerTop
      y = placeY(fNum) + (winnerTop ? HALF_BAR : -HALF_BAR)
    } else {
      y = leafSlot++ * ROW
    }
    yByNum[num] = y
    return y
  }
  roots.forEach(r => placeY(r.gameNumber))
  mainGames.forEach(g => { if (yByNum[g.gameNumber] === undefined) yByNum[g.gameNumber] = leafSlot++ * ROW })
  const minY = Math.min(0, ...mainGames.map(g => yByNum[g.gameNumber]))
  mainGames.forEach(g => { yByNum[g.gameNumber] -= minY })

  const positions: Record<number, { x: number; y: number; cy: number }> = {}
  mainGames.forEach(g => {
    const y = yByNum[g.gameNumber] + TOP_PAD
    positions[g.gameNumber] = { x: colLeft(g.round), y, cy: y + GAME_H / 2 }
  })

  const canvasW = colLeft(maxRound) + GAME_W + 24
  const canvasH = mainGames.length > 0
    ? Math.max(...mainGames.map(g => (positions[g.gameNumber]?.y ?? 0) + GAME_H)) + 24
    : 120

  const connectors: JSX.Element[] = []
  mainGames.forEach(game => {
    const pos = positions[game.gameNumber]
    if (!pos) return
    const feeders: number[] = []
    ;[game.t1, game.t2].forEach(src => {
      const [type, n] = src.split(':')
      if ((type === 'winner' || type === 'loser') && positions[parseInt(n)]) feeders.push(parseInt(n))
    })
    if (feeders.length >= 2) {
      const f1 = positions[feeders[0]], f2 = positions[feeders[1]]
      if (f1 && f2) {
        const midX = f1.x + GAME_W + CONN_W / 2
        connectors.push(<path key={`a-${game.gameNumber}`} d={`M${f1.x+GAME_W},${f1.cy} H${midX}`} fill="none" stroke="#475569" strokeWidth="1.5"/>)
        connectors.push(<path key={`b-${game.gameNumber}`} d={`M${f2.x+GAME_W},${f2.cy} H${midX}`} fill="none" stroke="#475569" strokeWidth="1.5"/>)
        connectors.push(<line key={`c-${game.gameNumber}`} x1={midX} y1={f1.cy} x2={midX} y2={f2.cy} stroke="#475569" strokeWidth="1.5"/>)
        connectors.push(<path key={`d-${game.gameNumber}`} d={`M${midX},${pos.cy} H${pos.x}`} fill="none" stroke="#475569" strokeWidth="1.5"/>)
      }
    } else if (feeders.length === 1) {
      const f = positions[feeders[0]]
      if (f) {
        // Single feeder (other slot is a bye) — the next game is aligned, so draw a straight line.
        connectors.push(
          <path key={`sf-${game.gameNumber}`} d={`M${f.x+GAME_W},${f.cy} H${pos.x}`} fill="none" stroke="#475569" strokeWidth="1.5"/>
        )
      }
    }
  })

  const teamBar = (game: GameTemplate, src: string, idx: number, isChamp: boolean) => {
    const pos = positions[game.gameNumber]
    if (!pos) return null
    const top = idx === 0 ? pos.cy - BAR_GAP / 2 - BAR_H : pos.cy + BAR_GAP / 2
    const [type, n] = (src || '').split(':')
    const isSeed = type === 'seed'
    const isComputed = type === 'winner' || type === 'loser'
    const nm = resolveLabel(src, seeds, numberOffset)
    const named = !!nm && !nm.startsWith('Seed ') && !isComputed
    const logo = named ? logos[nm] : ''
    const initial = named ? nm.charAt(0).toUpperCase() : ''
    return (
      <div key={idx} style={{ position: 'absolute', left: pos.x, top, width: GAME_W, height: BAR_H }}
        className={`flex items-center rounded-md border overflow-hidden ${isChamp ? 'border-amber-400/60 bg-amber-950/40' : 'border-slate-600/80 bg-slate-800/95'}`}>
        <span className={`h-full flex items-center justify-center text-[11px] font-semibold shrink-0 ${isSeed ? 'bg-teal-600 text-white' : 'bg-slate-700/80 text-slate-500'}`} style={{ width: 24 }}>
          {isSeed ? n : ''}
        </span>
        {logo
          ? <img src={logo} alt="" className="rounded-full object-cover ml-2 mr-1.5 shrink-0 bg-white" style={{ width: 18, height: 18 }} />
          : <span className="rounded-full bg-slate-700 text-slate-300 text-[9px] flex items-center justify-center ml-2 mr-1.5 shrink-0" style={{ width: 18, height: 18 }}>{initial}</span>}
        <div className="flex-1 min-w-0 pr-2">{renderSlot(game.gameNumber, src, idx)}</div>
      </div>
    )
  }

  if (mainGames.length === 0) {
    return (
      <div className="text-center py-10 text-slate-500 text-sm">
        No bracket games yet — go to <strong className="text-slate-400">Games</strong> tab to add some.
      </div>
    )
  }

  return (
    <div>
      {(onAddGame || onRenameSeed) && (
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] text-slate-500">Click a team to rename · × removes a game</span>
          {onAddGame && <button onClick={onAddGame} className="text-[11px] text-slate-400 hover:text-teal-300">+ Add game</button>}
        </div>
      )}
      {/* Round column labels */}
      <div style={{ position: 'relative', width: canvasW, height: LABEL_H }} className="mb-1">
        {mainRounds.map(r => (
          <div
            key={r}
            style={{ position: 'absolute', left: colLeft(r), width: GAME_W, textAlign: 'center' }}
            className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider"
          >
            {roundLabel(r, maxRound)}
          </div>
        ))}
      </div>

      <div className="overflow-x-auto pb-2">
        <div style={{ position: 'relative', width: canvasW, height: canvasH, minHeight: 120 }}>
          <svg style={{ position: 'absolute', top: 0, left: 0, width: canvasW, height: canvasH, pointerEvents: 'none' }} viewBox={`0 0 ${canvasW} ${canvasH}`}>
            {connectors}
          </svg>
          {mainGames.map(game => {
            const pos = positions[game.gameNumber]
            if (!pos) return null
            const isChamp = game.section === 'championship'
            const displayLabel = game.label || (isChamp ? (division ? `${division} Champion` : 'Champion') : undefined)
            return (
              <div key={game.gameNumber}>
                <div style={{ position: 'absolute', left: pos.x, top: pos.cy - BAR_GAP / 2 - BAR_H - 14, width: GAME_W, height: 13 }}
                  className="flex items-center justify-between">
                  <span className="text-[9px] font-mono text-teal-300/80 px-0.5 shrink-0">B{numberOffset + game.gameNumber}</span>
                  <span className="flex-1 text-center text-[8px] truncate px-1 text-slate-400">{schedText(numberOffset + game.gameNumber, true) || <span className="text-slate-600">TBD</span>}</span>
                  <span className="flex items-center gap-1 shrink-0">
                    {displayLabel && (editingLabel?.gameNumber === game.gameNumber
                      ? <input autoFocus value={editingLabel.value}
                          onChange={e => setEditingLabel({ gameNumber: game.gameNumber, value: e.target.value })}
                          onBlur={() => { onLabelChange?.(game.gameNumber, editingLabel.value); setEditingLabel(null) }}
                          onKeyDown={e => { if (e.key === 'Enter' || e.key === 'Escape') { onLabelChange?.(game.gameNumber, editingLabel.value); setEditingLabel(null) } }}
                          className="text-[9px] bg-transparent border-b border-amber-400 text-amber-300 outline-none w-24 text-right" />
                      : <button onClick={() => setEditingLabel({ gameNumber: game.gameNumber, value: displayLabel })} title="Click to edit label"
                          className={`text-[9px] font-semibold hover:opacity-70 cursor-text ${isChamp ? 'text-amber-400' : 'text-amber-400/70'}`}>{displayLabel}</button>
                    )}
                    {onRemoveGame && <button onClick={() => onRemoveGame(game.gameNumber)} title="Remove game" className="text-[11px] leading-none text-slate-500 hover:text-red-400">×</button>}
                  </span>
                </div>
                {(() => {
                  const [fa, fb] = feederOf(game)
                  let topSrc = game.t1, botSrc = game.t2
                  if ((fa != null) !== (fb != null)) {
                    const feederSrc = fa != null ? game.t1 : game.t2
                    const byeSrc = fa != null ? game.t2 : game.t1
                    if (winnerTopOf[game.gameNumber]) { topSrc = feederSrc; botSrc = byeSrc }
                    else { topSrc = byeSrc; botSrc = feederSrc }
                  }
                  return <>{teamBar(game, topSrc, 0, isChamp)}{teamBar(game, botSrc, 1, isChamp)}</>
                })()}
              </div>
            )
          })}
        </div>
      </div>

      {sideGames.length > 0 && (
        <div className="mt-5 pt-4 border-t border-slate-700">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
            {sideGames.some(g => g.section === 'losers') ? "Losers' Bracket" : 'Consolation Games'}
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {sideGames.map(game => (
              <div key={game.gameNumber} className="rounded-lg border border-slate-600/80 bg-slate-800/90 text-xs overflow-hidden">
                <div className="px-2 py-0.5 bg-black/20 flex items-center justify-between">
                  <span className="text-[10px] font-mono text-teal-300">B{numberOffset + game.gameNumber}</span>
                  {(() => {
                    const displayLabel = game.label
                    if (!displayLabel) return null
                    if (editingLabel?.gameNumber === game.gameNumber) {
                      return (
                        <input autoFocus value={editingLabel.value}
                          onChange={e => setEditingLabel({ gameNumber: game.gameNumber, value: e.target.value })}
                          onBlur={() => { onLabelChange?.(game.gameNumber, editingLabel.value); setEditingLabel(null) }}
                          onKeyDown={e => { if (e.key === 'Enter' || e.key === 'Escape') { onLabelChange?.(game.gameNumber, editingLabel.value); setEditingLabel(null) } }}
                          className="text-[10px] bg-transparent border-b border-slate-400 text-slate-200 outline-none w-24 text-right"
                        />
                      )
                    }
                    return (
                      <button onClick={() => setEditingLabel({ gameNumber: game.gameNumber, value: displayLabel })}
                        title="Click to edit label"
                        className="text-[10px] text-amber-400/70 hover:text-amber-400 cursor-text">
                        {displayLabel}
                      </button>
                    )
                  })()}
                  {onEditGame && <button onClick={() => setEditingFeeders(editingFeeders?.gameNumber === game.gameNumber ? null : { gameNumber: game.gameNumber, t1: game.t1, t2: game.t2 })} title="Edit matchup" className="text-[11px] leading-none text-slate-500 hover:text-teal-300 ml-1">&#9998;</button>}
                  {onRemoveGame && <button onClick={() => onRemoveGame(game.gameNumber)} title="Remove game" className="text-[12px] leading-none text-slate-500 hover:text-red-400 ml-1">×</button>}
                </div>
                {editingFeeders?.gameNumber === game.gameNumber ? (
                  <div className="p-2 space-y-1">
                    {(['t1', 't2'] as const).map(slot => (
                      <select key={slot} value={editingFeeders[slot]} onChange={e => setEditingFeeders(ef => ef ? { ...ef, [slot]: e.target.value } : ef)}
                        className="w-full text-[11px] bg-slate-900 border border-slate-600 rounded px-1 py-0.5 text-slate-200">
                        {sourceOptions.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
                      </select>
                    ))}
                    <div className="flex gap-1 justify-end pt-0.5">
                      <button onClick={() => setEditingFeeders(null)} className="text-[10px] text-slate-400 hover:text-slate-200 px-1">Cancel</button>
                      <button onClick={() => { onEditGame?.(game.gameNumber, editingFeeders.t1, editingFeeders.t2); setEditingFeeders(null) }} className="text-[10px] font-semibold bg-teal-600 hover:bg-teal-700 text-white px-2 py-0.5 rounded">Save</button>
                    </div>
                  </div>
                ) : [game.t1, game.t2].map((src, i) => (
                  <div key={i} className={`px-2 py-1 flex items-center ${i === 0 ? 'border-b border-slate-700' : ''}`}>
                    {renderSlot(game.gameNumber, src, i)}
                  </div>
                ))}
                <div className="px-2 py-0.5 border-t border-slate-700 text-[9px] text-slate-500 truncate">
                  {schedText(numberOffset + game.gameNumber, false) || <span className="text-slate-600">Not scheduled</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
