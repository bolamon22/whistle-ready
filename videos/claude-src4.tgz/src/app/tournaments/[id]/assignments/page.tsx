'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import TournamentNav from '../TournamentNav'
import toast, { Toaster } from 'react-hot-toast'
import { X } from 'lucide-react'

interface Worker { id: string; name: string; certLevel: string; defaultRole: string }
// payRate is null when this viewer doesn't see that pay: the scheduler, or an
// assigner for a group they don't run (lib/payGroups).
interface Assignment { id: string; role: string; payRate: number | null; worker: Worker; checkedInAt?: string | null }
interface Game {
  id: string; gameNumber: string; date: string; startTime: string
  division: string; location: string; team1: string; team2: string
  isCanceled: boolean; isChampionship: boolean; refCount: number
  assignments: Assignment[]
}

const ROLE_LABELS: Record<string, string> = {
  ref1: 'Official 1', ref2: 'Official 2', ref3: 'Official 3',
  scorekeeper: 'Scorekeeper', athletic_trainer: 'Athletic Trainer', field_ops: 'Field Ops',
}
const ROLE_COLORS: Record<string, string> = {
  ref1: 'bg-indigo-100 text-indigo-700', ref2: 'bg-violet-100 text-violet-700',
  ref3: 'bg-pink-100 text-pink-700', scorekeeper: 'bg-emerald-100 text-emerald-700',
  athletic_trainer: 'bg-amber-100 text-amber-700', field_ops: 'bg-teal-100 text-teal-700',
}

function fmt12(t: string) {
  if (!t) return ''
  const [h, m] = t.split(':').map(Number)
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`
}

export default function AssignmentsPage({ params }: { params: { id: string } }) {
  const [tName, setTName] = useState('')
  const [tLogo, setTLogo] = useState('')
  const [games, setGames] = useState<Game[]>([])
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState<'game' | 'staff'>('game')
  const [selDate, setSelDate] = useState('')
  const [selDiv, setSelDiv] = useState('')
  const [removing, setRemoving] = useState<string | null>(null)

  useEffect(() => {
    fetch(`/api/tournaments/${params.id}`).then(r => r.json()).then(t => {
      setTName(t.name); setTLogo(t.logoUrl || '')
    })
    loadGames()
  }, [params.id])

  async function loadGames() {
    const [gRes, aRes] = await Promise.all([
      fetch(`/api/tournaments/${params.id}/games`).then(r => r.json()),
      fetch(`/api/assignments?tournamentId=${params.id}`).then(r => r.json()).catch(() => []),
    ])
    const aMap: Record<string, Assignment[]> = {}
    if (Array.isArray(aRes)) {
      aRes.forEach((a: Assignment & { gameId: string }) => {
        if (!aMap[a.gameId]) aMap[a.gameId] = []
        aMap[a.gameId].push(a)
      })
    }
    setGames(gRes.map((g: Game) => ({ ...g, assignments: aMap[g.id] || [] })))
    const dates = [...new Set(gRes.map((g: Game) => g.date))].sort() as string[]
    if (dates.length && !selDate) setSelDate(dates[0])
    setLoading(false)
  }

  async function removeAssignment(assignmentId: string) {
    setRemoving(assignmentId)
    await fetch(`/api/assignments/${assignmentId}`, { method: 'DELETE' })
    await loadGames()
    setRemoving(null)
    toast.success('Assignment removed')
  }

  const dates = [...new Set(games.map(g => g.date))].sort()
  const divisions = [...new Set(games.map(g => g.division))].sort()

  const filteredGames = games.filter(g => {
    if (g.isCanceled) return false
    if (selDate && g.date !== selDate) return false
    if (selDiv && g.division !== selDiv) return false
    return true
  }).sort((a, b) => a.startTime < b.startTime ? -1 : 1)

  // Stats
  const totalSlots = games.filter(g => !g.isCanceled).reduce((s, g) => s + g.refCount + 1, 0)
  const filledSlots = games.filter(g => !g.isCanceled).reduce((s, g) => s + g.assignments.length, 0)
  const pct = totalSlots > 0 ? Math.round(filledSlots / totalSlots * 100) : 0

  // Staff view — group by worker
  const staffMap = new Map<string, { worker: Worker; games: { game: Game; role: string; payRate: number | null; assignmentId: string }[] }>()
  games.filter(g => !g.isCanceled && (!selDate || g.date === selDate) && (!selDiv || g.division === selDiv))
    .forEach(g => g.assignments.forEach(a => {
      if (!staffMap.has(a.worker.id)) staffMap.set(a.worker.id, { worker: a.worker, games: [] })
      staffMap.get(a.worker.id)!.games.push({ game: g, role: a.role, payRate: a.payRate, assignmentId: a.id })
    }))
  const staffList = [...staffMap.values()].sort((a, b) => a.worker.name.localeCompare(b.worker.name))

  if (loading) return <div className="p-10 text-center text-slate-400">Loading…</div>

  return (
    <div className="min-h-screen bg-slate-50 pb-16">
      <Toaster />
      <TournamentNav id={params.id} name={tName} logoUrl={tLogo} />
      <div className="max-w-5xl mx-auto px-0 sm:px-4 pt-4 sm:pt-6">

        {/* Header */}
        <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              {/* The assigner works from the Assigner board, not the Scheduler (which that role can't open). */}
              <Link href={`/tournaments/${params.id}`} className="text-xs text-teal-600 hover:text-teal-800 hover:underline">← Assigner</Link>
            </div>
            <h1 className="text-2xl font-bold text-slate-800">Assignments</h1>
            <p className="text-sm text-slate-400 mt-0.5">
              {filledSlots} of {totalSlots} slots filled
              <span className={`ml-2 font-semibold ${pct >= 90 ? 'text-emerald-600' : pct >= 50 ? 'text-amber-500' : 'text-red-500'}`}>{pct}%</span>
            </p>
          </div>
          <div className="grid grid-cols-2 sm:flex gap-2 w-full sm:w-auto">
            <button onClick={() => setView('game')}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${view === 'game' ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
              By game
            </button>
            <button onClick={() => setView('staff')}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${view === 'staff' ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
              By staff
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap mb-5">
          {dates.map(d => {
            const label = new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })
            return (
              <button key={d} onClick={() => setSelDate(d === selDate ? '' : d)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${selDate === d ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                {label}
              </button>
            )
          })}
          <select value={selDiv} onChange={e => setSelDiv(e.target.value)}
            className="flex-1 sm:flex-none min-w-0 border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-600 bg-white focus:outline-none">
            <option value="">All divisions</option>
            {divisions.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>

        {/* ── By Game view ── */}
        {view === 'game' && (
          <div className="space-y-2">
            {filteredGames.length === 0 && <div className="text-center py-12 text-slate-400">No games found.</div>}
            {filteredGames.map(game => {
              const slots = game.refCount + 1
              const filled = game.assignments.length
              const complete = filled >= slots
              return (
                <div key={game.id} className={`bg-white border rounded-xl overflow-hidden ${complete ? 'border-emerald-200' : filled > 0 ? 'border-amber-200' : 'border-slate-200'}`}>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 px-3 sm:px-5 py-3 border-b border-slate-50">
                    <div className="flex items-center gap-2 sm:contents">
                      <span className={`text-xs font-mono px-2 py-0.5 rounded ${game.isChampionship ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'}`}>#{game.gameNumber}</span>
                      <span className="text-xs text-slate-500">{fmt12(game.startTime)}</span>
                      <span className={`ml-auto sm:ml-0 sm:order-4 text-xs font-semibold px-2 py-0.5 rounded-full ${complete ? 'bg-emerald-100 text-emerald-700' : filled > 0 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-600'}`}>
                        {filled}/{slots}
                      </span>
                    </div>
                    <span className="text-sm font-medium text-slate-800 sm:flex-1 sm:order-1">{game.team1} <span className="text-slate-400 font-normal text-xs">vs</span> {game.team2}</span>
                    <div className="flex items-center gap-2 text-xs text-slate-400 sm:contents">
                      <span className="sm:order-2">{game.division}</span>
                      <span className="sm:hidden">·</span>
                      <span className="sm:order-3 truncate">{game.location}</span>
                    </div>
                  </div>
                  <div className="px-3 sm:px-5 py-2.5 flex flex-wrap gap-2">
                    {game.assignments.length === 0
                      ? <span className="text-xs text-slate-400 italic">No staff assigned</span>
                      : game.assignments.map(a => (
                        <div key={a.id} className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg ${ROLE_COLORS[a.role] || 'bg-slate-100 text-slate-600'}`}>
                          <span className="font-medium">{a.worker.name}</span>
                          <span className="opacity-70">· {ROLE_LABELS[a.role] || a.role}</span>
                          {a.checkedInAt && <span title="Checked in on the staff app" className="font-semibold text-emerald-700">· In {new Date(a.checkedInAt).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}</span>}
                          {a.payRate != null && <span className="opacity-60">· ${a.payRate}</span>}
                          <button onClick={() => removeAssignment(a.id)} disabled={removing === a.id}
                            className="ml-1 opacity-50 hover:opacity-100 transition-opacity text-current"><X size={12} /></button>
                        </div>
                      ))
                    }
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* ── By Staff view ── */}
        {view === 'staff' && (
          <div className="space-y-3">
            {staffList.length === 0 && <div className="text-center py-12 text-slate-400">No assignments in this view.</div>}
            {staffList.map(({ worker, games: wGames }) => {
              const priced = wGames.filter(g => g.payRate != null)
              const totalPay = priced.reduce((s, g) => s + (g.payRate ?? 0), 0)
              return (
                <div key={worker.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <div className="flex items-center gap-3 px-3 sm:px-5 py-3 border-b border-slate-50 bg-slate-50">
                    <div className="w-7 h-7 rounded-full bg-teal-100 text-teal-700 text-xs font-bold flex items-center justify-center flex-shrink-0">
                      {worker.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                    </div>
                    <span className="font-semibold text-slate-800 flex-1">{worker.name}</span>
                    <span className="text-xs text-slate-400">{wGames.length} game{wGames.length !== 1 ? 's' : ''}</span>
                    {priced.length > 0 && <span className="text-sm font-semibold text-emerald-700" title={priced.length < wGames.length ? 'Pay for the games in your pay groups' : undefined}>${totalPay.toFixed(0)}</span>}
                  </div>
                  <div className="divide-y divide-slate-50">
                    {wGames.sort((a, b) => `${a.game.date}${a.game.startTime}` < `${b.game.date}${b.game.startTime}` ? -1 : 1).map(({ game, role, payRate, assignmentId }) => (
                      <div key={assignmentId} className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 px-3 sm:px-5 py-2.5">
                        <div className="flex items-center gap-2 sm:contents">
                          <span className="text-xs text-slate-400 sm:w-10">{fmt12(game.startTime)}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${ROLE_COLORS[role] || 'bg-slate-100 text-slate-600'}`}>{ROLE_LABELS[role] || role}</span>
                          <span className="ml-auto sm:ml-0 sm:order-3 text-xs text-slate-500 font-medium">{payRate != null ? `$${payRate}` : ''}</span>
                          <button onClick={() => removeAssignment(assignmentId)} disabled={removing === assignmentId}
                            className="sm:order-4 text-red-300 hover:text-red-500 text-xs transition-colors p-1 -mr-1 sm:p-0 sm:mr-0"><X size={12} /></button>
                        </div>
                        <span className="text-sm text-slate-700 sm:flex-1 sm:order-1">{game.team1} vs {game.team2} <span className="sm:hidden text-xs text-slate-400">· {game.division}</span></span>
                        <span className="hidden sm:inline text-xs text-slate-400 sm:order-2">{game.division}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
