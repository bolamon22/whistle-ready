import { NextResponse } from 'next/server'
import prisma from '@/lib/db'
import { requireStaff, eventGate, orgGate, viewer } from '@/lib/apiAuth'
import { getPublicVisibility, applyPublicView } from '@/lib/publicView'
import { notifyFinal } from '@/lib/finalAlerts'
import { ownClubTeams, isOwnClubGame, ownClubRefusal } from '@/lib/ownClub'
import { actorOf, gameMoveChanges, sendOfficialChanges, spotOf, type OfficialChange } from '@/lib/officialChangeAlerts'

// Middleware lets every /api/* request through, so the gate has to live here.
// Without it this route rewrote or deleted any game by id with no login at all —
// scores, times, fields and team names on a live public schedule. requireStaff
// (not requireDirector) because the table workers running the scorekeeper page
// carry staff/ref/scorekeeper roles and must keep working; it only shuts out
// anonymous callers and the coach/parent/club-director roles.
//
// A score write that makes (or corrects) a final also alerts the phones
// following either team -- see lib/finalAlerts for the guards. The scorekeeper
// page saves mid-game too, to survive a refresh; it marks those writes
// `provisional: true` so they are not announced as finals. The response is the
// updated game either way, so nothing about the callers had to change.
// A game of another organization's event is not found for a director, scheduler,
// assigner or field director working elsewhere (lib/orgScope).
async function otherOrg(gate: Parameters<typeof orgGate>[0], gameId: string) {
  const g = await prisma.game.findUnique({ where: { id: gameId }, select: { tournamentId: true } })
  return g ? orgGate(gate, g.tournamentId) : null
}

export async function PATCH(req: Request, { params }: { params:{id:string} }) {
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  const b = await req.json()
  // Assigners staff games; they don't schedule them (Bo, Oct 13 2026: "they should not be able to
  // move games, the schedule would do that"). The Scheduler page was already closed to them.
  // The one game field they keep is how many refs it needs.
  if (gate.role === 'assigner' && Object.keys(b || {}).some(k => k !== 'refCount')) {
    return NextResponse.json({ error: 'Assigners can change refs per game only. Ask the scheduler to move or edit games.' }, { status: 403 })
  }
  // A field director posts scores, at their own events (lib/fieldDirector), and changes nothing else.
  if (gate.role === 'field_director') {
    if (Object.keys(b || {}).some(k => !['score1', 'score2', 'provisional'].includes(k))) {
      return NextResponse.json({ error: 'Field directors can post scores only. Ask the scheduler to move or edit games.' }, { status: 403 })
    }
    if (gate.events) {
      const g = await prisma.game.findUnique({ where: { id: params.id }, select: { tournamentId: true } })
      const refused = eventGate(gate, g?.tournamentId); if (refused) return refused
    }
  }
  const away = await otherOrg(gate, params.id); if (away) return away
  const touchesScore = b.score1 !== undefined || b.score2 !== undefined
  const before = touchesScore
    ? await prisma.game.findUnique({ where: { id: params.id }, select: { score1: true, score2: true, tournamentId: true, team1: true, team2: true } })
    : null
  // Never a game this login's own club plays (lib/ownClub). Only a real change
  // counts: Post scores sends both boxes, and an unchanged score changes nothing.
  const asScore = (v: unknown) => v === '' || v === null ? null : Number(v)
  if (before && ((b.score1 !== undefined && asScore(b.score1) !== before.score1) || (b.score2 !== undefined && asScore(b.score2) !== before.score2))) {
    const refused = await ownClubRefusal(gate, before.tournamentId, [before.team1, before.team2, b.team1, b.team2]); if (refused) return refused
  }
  // A move, cancel, renumber or new teams is told to the officials on it once their
  // crew is published (lib/officialChangeAlerts). Score saves skip the extra read.
  const moves = ['date', 'startTime', 'location', 'isCanceled', 'gameNumber', 'team1', 'team2'].some(k => b[k] !== undefined)
  const was = moves ? await prisma.game.findUnique({ where: { id: params.id }, include: { assignments: { select: { workerId: true, role: true } } } }) : null
  const updated = await prisma.game.update({ where:{id:params.id}, data:{
    // null and '' both mean "no score". Number(null) is 0, so the old ''-only check
    // turned the Scores page's empty box (it sends null) into a 0 -- filling in the
    // first of two boxes made the public page show a final of 8-0 until the second
    // box was typed, and would have pushed that phantom final to followers.
    ...(b.score1      !== undefined && { score1:      b.score1===''||b.score1===null?null:Number(b.score1) }),
    ...(b.score2      !== undefined && { score2:      b.score2===''||b.score2===null?null:Number(b.score2) }),
    ...(b.refCount    !== undefined && { refCount:    Number(b.refCount) }),
    ...(b.isChampionship !== undefined && { isChampionship: Boolean(b.isChampionship) }),
    ...(b.isCanceled  !== undefined && { isCanceled:  Boolean(b.isCanceled) }),
    ...(b.startTime   !== undefined && { startTime:   String(b.startTime) }),
    ...(b.location    !== undefined && { location:    String(b.location) }),
    ...(b.division    !== undefined && { division:    String(b.division) }),
    ...(b.pool        !== undefined && { pool:        b.pool||null }),
    ...(b.team1       !== undefined && { team1:       String(b.team1) }),
    ...(b.team2       !== undefined && { team2:       String(b.team2) }),
    ...(b.gameNumber  !== undefined && { gameNumber:  String(b.gameNumber) }),
    ...(b.date        !== undefined && { date:        String(b.date) }),
  }})
  // Back to not played (Scores page unchecks Final): drop the scorekeeper's live entry
  // too, or the public page keeps showing the old live score and the start/halftime
  // alert flags stay set for when the game is really played.
  // Only when it really had a score: an empty save of an unplayed game (a score box
  // clicked and left blank) must not wipe a game that is live right now.
  if (touchesScore && updated.score1 === null && updated.score2 === null && before && (before.score1 !== null || before.score2 !== null)) {
    await prisma.appSetting.deleteMany({ where: { key: `liveScore:${params.id}` } }).catch(() => {})
  }
  if (before && b.provisional !== true) {
    await notifyFinal(before, { ...updated, url: `/tournaments/${updated.tournamentId}/public/games/${updated.id}` })
  }
  if (was) {
    // A move never changes who keeps score, and scorekeepers aren't messaged about
    // moves: they work a field all day (Bo, Oct 21 2026). The Scheduler asks before
    // handing a moved game to the new field's scorekeeper.
    const moved = gameMoveChanges(was, updated).filter(c => c.role !== 'scorekeeper')
    await sendOfficialChanges(updated.tournamentId, moved, actorOf(gate))
  }
  return NextResponse.json(updated)
}

export async function DELETE(_: Request, { params }: { params:{id:string} }) {
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  if (gate.role === 'assigner' || gate.role === 'field_director') return NextResponse.json({ error: 'Only the scheduler or director can delete games.' }, { status: 403 })
  const away = await otherOrg(gate, params.id); if (away) return away
  const was = await prisma.game.findUnique({ where: { id: params.id }, include: { assignments: { select: { workerId: true, role: true } } } })
  await prisma.game.delete({ where:{id:params.id} })
  if (was?.assignments.length) {
    const spot = spotOf(was)
    await sendOfficialChanges(was.tournamentId, was.assignments.map((a): OfficialChange => ({ kind: 'removed', workerId: a.workerId, role: a.role, spot })), actorOf(gate))
  }
  return NextResponse.json({ ok:true })
}

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const game = await prisma.game.findUnique({ where: { id: params.id } })
  if (!game) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const staff = await requireStaff()
  // Staff of another organization's event get what the public gets (lib/orgScope).
  if (staff.ok && !(await orgGate(staff, game.tournamentId))) {
    // The scorekeeper page shows a game the viewer's own club plays without the
    // controls: someone else keeps that score (lib/ownClub).
    const who = await viewer()
    const mine = await ownClubTeams(who.role, who.userId, game.tournamentId).catch(() => new Set<string>())
    return NextResponse.json(isOwnClubGame(mine, game) ? { ...game, ownClub: true } : game)
  }
  const [visible] = applyPublicView([game], await getPublicVisibility(game.tournamentId))
  if (!visible) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(visible)
}
