import { NextResponse } from 'next/server'
import prisma from '@/lib/db'
import { requireStaff } from '@/lib/apiAuth'
import { canSeeMoney, canSeeStaffPay } from '@/lib/roleScope'
import { payScopeFor } from '@/lib/payScope'
import { approvedExpenseTotal } from '@/lib/eventExpenses'

export async function GET(_: Request, { params }: { params: { id: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  const id = params.id

  const [tournament, games, registrations, rosterEntries, allAssignments, timeEntries, staffPayments, transactions, playerCount, receipts] = await Promise.all([
    prisma.tournament.findUnique({ where: { id } }),
    prisma.game.findMany({ where: { tournamentId: id }, select: { id: true, division: true, isCanceled: true, assignments: { select: { id: true } } } }),
    prisma.teamRegistration.findMany({
      where: { tournamentId: id, deletedAt: null },
      include: { teams: { select: { id: true, division: true, waitlisted: true } }, payments: { select: { amount: true } } },
    }),
    prisma.rosterEntry.findMany({ where: { tournamentId: id }, select: { workerId: true } }),
    prisma.assignment.findMany({ where: { game: { tournamentId: id } }, select: { id: true, payRate: true, role: true } }),
    prisma.timeEntry.findMany({ where: { tournamentId: id }, include: { worker: { select: { hourlyRate: true } } } }),
    prisma.paymentRecord.findMany({ where: { tournamentId: id }, select: { amount: true } }),
    prisma.tournamentTransaction.findMany({ where: { tournamentId: id }, select: { type: true, category: true, amount: true } }),
    prisma.playerRegistration.count({ where: { tournamentId: id, deletedAt: null } }),
    approvedExpenseTotal(id),   // approved receipts (Financials > Expenses); 0 when none
  ])

  if (!tournament) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Staff pay expenses
  function calcHours(e: { clockIn: string | null; clockOut: string | null; hoursManual: number | null }) {
    if (e.hoursManual != null) return e.hoursManual
    if (e.clockIn && e.clockOut) {
      const [ih, im] = e.clockIn.split(':').map(Number)
      const [oh, om] = e.clockOut.split(':').map(Number)
      return Math.max(0, (oh * 60 + om - (ih * 60 + im)) / 60)
    }
    return 0
  }
  const refPayTotal = allAssignments.reduce((s, a) => s + a.payRate, 0)
  const hourlyPayTotal = timeEntries.reduce((te, e) => te + calcHours(e) * (e.worker.hourlyRate ?? 0), 0)
  const totalStaffExpense = refPayTotal + hourlyPayTotal
  const totalStaffPaid = staffPayments.reduce((s, p) => s + p.amount, 0)
  const refCount = allAssignments.filter(a => a.role.startsWith('ref')).length
  const skCount = allAssignments.filter(a => a.role === 'scorekeeper').length

  // Other income & expenses (transactions)
  const otherIncome   = transactions.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0)
  const otherExpenses = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0) + receipts
  const txByCategory  = transactions.reduce((acc, t) => {
    acc[t.category] = (acc[t.category] || 0) + t.amount
    return acc
  }, {} as Record<string, number>)

  // Games summary
  const activeGames = games.filter(g => !g.isCanceled)
  const totalAssignmentSlots = activeGames.reduce((s, g) => s + g.assignments.length, 0)
  const divisions = Array.from(new Set(activeGames.map(g => g.division).filter(Boolean)))

  // Registration summary
  const totalClubs = registrations.length
  const totalTeams = registrations.reduce((s, r) => s + r.teams.length, 0)
  const totalInvoiced = registrations.reduce((s, r) => s + r.invoiceAmount - r.discountAmount, 0)
  const totalReceived = registrations.reduce((s, r) => s + r.payments.reduce((p, x) => p + x.amount, 0), 0)
  const totalBalance = totalInvoiced - totalReceived

  // Payment method breakdown
  const byMethod: Record<string, number> = {}
  for (const reg of registrations) {
    byMethod[reg.paymentMethod] = (byMethod[reg.paymentMethod] || 0) + 1
  }

  // Division breakdown from registrations. Teams whose division was never set land in
  // 'Unassigned' — the same key the dashboard files them under when it lists the teams, so
  // the chip opens instead of reading "No team details found". Every team lands somewhere,
  // so these counts always add up to totalTeams.
  //
  // Waiting-list teams are counted apart: they registered but are not playing
  // until Bo places them, and the tile has to answer "can I fit one more?",
  // which a count that includes them gets wrong. A division whose only entry is
  // waitlisted still gets a tile (count 0) so the waiting team is visible.
  // byDivision + byDivisionWaitlist still adds up to totalTeams.
  const divisionCounts: Record<string, number> = {}
  const divisionWaitlist: Record<string, number> = {}
  let waitlistedTeams = 0
  for (const reg of registrations) {
    for (const team of reg.teams) {
      const div = String(team.division || '').trim() || 'Unassigned'
      divisionCounts[div] = divisionCounts[div] || 0
      if (team.waitlisted) { divisionWaitlist[div] = (divisionWaitlist[div] || 0) + 1; waitlistedTeams++ }
      else divisionCounts[div]++
    }
  }

  // Hotel needs
  const hotelYes = registrations.filter(r => r.needsHotel === 'Yes').length
  const hotelMaybe = registrations.filter(r => r.needsHotel === 'Maybe').length

  // Paid in full vs outstanding
  const paidInFull = registrations.filter(r => {
    const paid = r.payments.reduce((s, p) => s + p.amount, 0)
    return r.invoiceAmount > 0 && paid >= (r.invoiceAmount - r.discountAmount)
  }).length

  // Staff without money access (the scheduler) get the counts -- teams, clubs,
  // who has paid in full -- but every dollar figure comes back as 0, so the page
  // has nothing to show and the figures never reach the browser.
  const money = canSeeMoney(gate.role)
  // Event-wide pay totals mix every pay group, so an assigner sees them only when
  // set to all four groups (lib/payGroups, Oct 13 2026).
  const pay = canSeeStaffPay(gate.role) && (money || (await payScopeFor(gate.role, gate.userId)).all)
  const $ = (n: number) => (money ? n : 0)
  const $pay = (n: number) => (pay ? n : 0)

  return NextResponse.json({
    canSeeMoney: money,
    tournament: money ? tournament : { ...tournament, payRates: undefined, registrationPricing: undefined },
    games: {
      total: games.length,
      active: activeGames.length,
      canceled: games.length - activeGames.length,
      assigned: totalAssignmentSlots,
      divisions: divisions.length,
    },
    staff: {
      onRoster: rosterEntries.length,
      refPayTotal: $pay(refPayTotal),
      hourlyPayTotal: $pay(hourlyPayTotal),
      totalStaffExpense: $(totalStaffExpense),
      totalStaffPaid: $(totalStaffPaid),
      refCount,
      skCount,
    },
    financials: {
      otherIncome: $(otherIncome),
      otherExpenses: $(otherExpenses),
      txByCategory: money ? txByCategory : {},
    },
    registrations: {
      clubs: totalClubs,
      teams: totalTeams,
      invoiced: $(totalInvoiced),
      received: $(totalReceived),
      balance: $(totalBalance),
      paidInFull,
      outstanding: totalClubs - paidInFull,
      byMethod: money ? byMethod : {},
      byDivision: divisionCounts,
      byDivisionWaitlist: divisionWaitlist,
      waitlisted: waitlistedTeams,
      hotelYes,
      hotelMaybe,
    },
    playerCount,
  })
}
