import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { requireStaff } from '@/lib/apiAuth'
import { canSeeMoney, canSeeContacts, payStatus } from '@/lib/roleScope'
import { cleanName, nameKey } from '@/lib/names'
import { renameTeamRefs, removeTeamRefs, swapTeamDivisionRefs } from '@/lib/teamRename'
import { findShortTeams, describeFinding } from '@/lib/gameBalance'
import { parsePricing, calcFee } from '@/lib/regPricing'
import { WITHDRAWN_DIVISION } from '@/lib/withdrawn'

export async function GET(_req: NextRequest, { params }: { params: { id: string; division: string } }) {
  // Staff only: this returns coach phone/email and what each club owes. It was open to
  // anyone with a tournament id. Every caller is a staff Divisions/Bracket page.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  try {
    const division = decodeURIComponent(params.division)

    const teams = await prisma.registeredTeam.findMany({
      where: { registration: { tournamentId: params.id, deletedAt: null }, division },
      include: { registration: { select: { invoiceAmount: true, discountAmount: true, payments: { select: { amount: true } } } } },
      orderBy: { teamName: 'asc' },
    })

    let pools: { id: string; name: string; teamNames: string }[] = []
    try {
      pools = await prisma.pool.findMany({
        where: { tournamentId: params.id, division },
        orderBy: { name: 'asc' },
      })
    } catch { /* Pool table not migrated yet */ }

    const teamPool = new Map<string, string>()
    for (const pool of pools) {
      const names: string[] = JSON.parse(pool.teamNames || '[]')
      for (const n of names) teamPool.set(n, pool.name)
    }

    // Ensure status column exists
    try {
      await prisma.$executeRawUnsafe(`ALTER TABLE "RegisteredTeam" ADD COLUMN "status" TEXT DEFAULT 'confirmed'`)
    } catch { /* already exists */ }

    // The scheduler sees whether a club has paid, not how much, and no coach
    // contacts. Amounts come back as 0 and contacts as '' for those roles.
    const money = canSeeMoney(gate.role), contacts = canSeeContacts(gate.role)
    const result = await Promise.all(teams.map(async t => {
      const paid = t.registration.payments.reduce((s, p) => s + p.amount, 0)
      const owed = t.registration.invoiceAmount - (t.registration.discountAmount || 0)
      const st = payStatus(owed, paid)
      // Read status via raw query since it may not be in Prisma schema yet
      const statusRow = await prisma.$queryRawUnsafe<{status: string}[]>(
        'SELECT status FROM "RegisteredTeam" WHERE id = ?', t.id
      ).catch(() => [{ status: 'confirmed' }])
      return {
        id: t.id,
        teamName: t.teamName,
        clubName: t.clubName,
        logoUrl: t.logoUrl || '',
        division: t.division,
        coachName: t.coachName,
        coachPhone: contacts ? t.coachPhone : '',
        coachEmail: contacts ? t.coachEmail : '',
        pool: teamPool.get(t.teamName) ?? null,
        paid: money ? paid : 0, owed: money ? owed : 0,
        // "Paid" now also counts the club's discount; a club that paid its
        // discounted invoice used to read as partial.
        paymentStatus: st === 'none' ? 'unpaid' : st,
        status: statusRow[0]?.status ?? 'confirmed',
        waitlisted: !!t.waitlisted,
      }
    }))

    const parsedPools = pools.map(p => ({ ...p, teamNames: JSON.parse(p.teamNames || '[]') }))
    return NextResponse.json({ teams: result, pools: parsedPools })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to load teams' }, { status: 500 })
  }
}

// PATCH: move a team to a different division
export async function PATCH(req: NextRequest, { params }: { params: { id: string; division: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  try {
    const { teamId, newDivision, swapWithTeamId, withdraw } = await req.json()

    // WITHDRAW (lib/withdrawn): off this division, its pools and its games, but kept
    // on the club's registration with the invoice and payments untouched.
    if (teamId && withdraw === true) {
      const team = await prisma.registeredTeam.findFirst({
        where: { id: teamId, registration: { tournamentId: params.id } },
        select: { id: true, teamName: true, division: true },
      })
      if (!team) return NextResponse.json({ error: 'Team not found' }, { status: 404 })
      await prisma.registeredTeam.update({ where: { id: team.id }, data: { division: WITHDRAWN_DIVISION, waitlisted: true } })
      const removed = await removeTeamRefs(params.id, team.teamName, team.division)
      let shortWarning: { message: string }[] = []
      try {
        const rest = await prisma.game.findMany({
          where: { tournamentId: params.id, division: team.division },
          select: { division: true, pool: true, team1: true, team2: true, isCanceled: true, isChampionship: true },
        })
        shortWarning = findShortTeams(rest as any).map(f => ({ message: describeFinding(f) }))
      } catch { /* advisory only */ }
      return NextResponse.json({ ok: true, withdrawn: true, removed, shortWarning })
    }

    // Swap with another team: each takes the other's pool spot, games and bracket
    // seed (and, from another division, its division), so no schedule needs
    // rebuilding. Two teams in the same division is the Swap on the Teams board.
    if (teamId && swapWithTeamId) {
      const both = await prisma.registeredTeam.findMany({
        where: { id: { in: [teamId, swapWithTeamId] }, registration: { tournamentId: params.id } },
        select: { id: true, teamName: true, division: true, waitlisted: true },
      })
      const a = both.find(t => t.id === teamId), b = both.find(t => t.id === swapWithTeamId)
      if (!a || !b) return NextResponse.json({ error: 'Team not found' }, { status: 404 })
      if (a.id === b.id) return NextResponse.json({ error: 'Pick two different teams.' }, { status: 400 })
      // A waitlisted team isn't in the draw: trading places would put it in a pool
      // and games while it still reads as waiting, and leave the other team out.
      const waiting = [a, b].find(t => t.waitlisted)
      if (waiting) return NextResponse.json({ error: `${waiting.teamName} is on the waiting list. Take them off it before swapping.` }, { status: 409 })
      const sameDivision = nameKey(a.division) === nameKey(b.division)
      // Another team already carrying one of these names in the other division
      // would end up sharing its games.
      const clash = sameDivision ? null : await prisma.registeredTeam.findFirst({
        where: {
          registration: { tournamentId: params.id, deletedAt: null },
          OR: [
            { division: b.division, teamName: a.teamName, NOT: { id: b.id } },
            { division: a.division, teamName: b.teamName, NOT: { id: a.id } },
          ],
        },
        select: { teamName: true, division: true },
      })
      if (clash) return NextResponse.json({ error: `${clash.division} already has a team called ${clash.teamName}. Rename one first.` }, { status: 409 })
      // A score belongs to the matchup that was played; swapping would hand it
      // to a team that never played that game.
      const scored = await prisma.game.count({
        where: {
          tournamentId: params.id, NOT: { score1: null },
          OR: [
            { division: a.division, OR: [{ team1: a.teamName }, { team2: a.teamName }] },
            { division: b.division, OR: [{ team1: b.teamName }, { team2: b.teamName }] },
          ],
        },
      })
      if (scored) return NextResponse.json({ error: `${scored} of their games already have scores, so they can't be swapped.` }, { status: 409 })

      if (!sameDivision) {
        await prisma.registeredTeam.update({ where: { id: a.id }, data: { division: b.division } })
        await prisma.registeredTeam.update({ where: { id: b.id }, data: { division: a.division } })
      }
      const counts = await swapTeamDivisionRefs(params.id, { name: a.teamName, division: a.division }, { name: b.teamName, division: b.division })
      return NextResponse.json({ ok: true, counts })
    }

    if (!teamId || !newDivision?.trim()) return NextResponse.json({ error: 'teamId and newDivision required' }, { status: 400 })

    const division = decodeURIComponent(params.division)

    // Update the RegisteredTeam record
    await prisma.registeredTeam.update({
      where: { id: teamId },
      data: { division: newDivision.trim() },
    })

    // Remove team from any pool in old division
    const oldPools = await prisma.pool.findMany({
      where: { tournamentId: params.id, division },
    }).catch(() => [] as { id: string; teamNames: string }[])

    const team = await prisma.registeredTeam.findUnique({ where: { id: teamId }, select: { teamName: true } })
    if (team) {
      for (const pool of oldPools) {
        const names: string[] = JSON.parse(pool.teamNames || '[]')
        if (names.includes(team.teamName)) {
          await prisma.pool.update({
            where: { id: pool.id },
            data: { teamNames: JSON.stringify(names.filter(n => n !== team.teamName)) },
          }).catch(() => {})
        }
      }
    }

    // Ensure the new division exists in registrationDivisions
    const tournament = await prisma.tournament.findUnique({
      where: { id: params.id }, select: { registrationDivisions: true },
    })
    const regDivs: string[] = JSON.parse(tournament?.registrationDivisions ?? '[]')
    if (!regDivs.includes(newDivision.trim())) {
      await prisma.tournament.update({
        where: { id: params.id },
        data: { registrationDivisions: JSON.stringify([...regDivs, newDivision.trim()].sort()) },
      })
    }

    // Its games in the old division stay as they were (Bo, Oct 20 2026: Madskillz 2034
    // moved to Lower School but still played P1 and P7 in Middle School, and nothing
    // said so). Deleting them would quietly take games off its opponents, so they're
    // named for the mover to fix: change those matchups or rebuild the pool games.
    const leftGames = team ? await prisma.game.findMany({
      where: { tournamentId: params.id, division, OR: [{ team1: team.teamName }, { team2: team.teamName }] },
      select: { gameNumber: true },
    }).catch(() => [] as { gameNumber: string }[]) : []
    return NextResponse.json({ ok: true, leftGames: leftGames.map(g => g.gameNumber) })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to move team' }, { status: 500 })
  }
}

// POST: add a placeholder team directly (no full registration required)
export async function POST(req: NextRequest, { params }: { params: { id: string; division: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  try {
    const division = decodeURIComponent(params.division)
    const body = await req.json()
    const { teamName, clubName, coachName, coachEmail, coachPhone } = body
    if (!teamName?.trim()) return NextResponse.json({ error: 'Team name required' }, { status: 400 })

    // Ensure status column exists (libSQL-safe)
    try {
      await prisma.$executeRawUnsafe('ALTER TABLE RegisteredTeam ADD COLUMN status TEXT DEFAULT \'confirmed\'')
    } catch { /* already exists */ }

    // Create a stub TeamRegistration
    const reg = await prisma.teamRegistration.create({
      data: {
        tournamentId: params.id,
        clubName: clubName?.trim() || teamName.trim(),
        clubContact: coachName?.trim() || '',
        contactEmail: coachEmail?.trim() || '',
        contactPhone: coachPhone?.trim() || '',
        numTeams: 1,
        invoiceAmount: 0,
      },
    })

    // Create the RegisteredTeam via Prisma (known fields only)
    const team = await prisma.registeredTeam.create({
      data: {
        registrationId: reg.id,
        clubName: clubName?.trim() || teamName.trim(),
        teamName: teamName.trim(),
        division,
        coachName: coachName?.trim() || '',
        coachEmail: coachEmail?.trim() || '',
        coachPhone: coachPhone?.trim() || '',
      },
    })

    // Set status = 'placeholder' via raw SQL (not in Prisma schema)
    await prisma.$executeRawUnsafe(
      'UPDATE RegisteredTeam SET status = \'placeholder\' WHERE id = ?',
      team.id
    )

    return NextResponse.json({ ...team, pool: null, paid: 0, owed: 0, paymentStatus: 'unpaid', status: 'placeholder' })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to add team' }, { status: 500 })
  }
}

// PUT: update team details (and optionally confirm)
export async function PUT(req: NextRequest, { params }: { params: { id: string; division: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  try {
    const { teamId, teamName, clubName, coachName, coachEmail, coachPhone, logoUrl, confirm } = await req.json()
    if (!teamId) return NextResponse.json({ error: 'teamId required' }, { status: 400 })

    // Update known fields via Prisma
    const data: Record<string, string> = {}
    if (cleanName(teamName)) data.teamName = cleanName(teamName)
    if (clubName !== undefined) data.clubName = cleanName(clubName)
    if (coachName !== undefined) data.coachName = cleanName(coachName)
    // A role that cannot see contacts gets them blank in the edit form, so its
    // save must not write those blanks over the real ones.
    if (canSeeContacts(gate.role)) {
      if (coachEmail !== undefined) data.coachEmail = String(coachEmail || '').trim()
      if (coachPhone !== undefined) data.coachPhone = String(coachPhone || '').trim()
    }
    if (logoUrl !== undefined) data.logoUrl = logoUrl

    if (Object.keys(data).length > 0) {
      const before = await prisma.registeredTeam.findUnique({ where: { id: teamId }, include: { registration: { select: { clubName: true } } } })
      await prisma.registeredTeam.update({ where: { id: teamId }, data })
      // A rename has to follow the team into its pool, games, bracket and waivers.
      if (before && data.teamName && before.teamName !== data.teamName) {
        await renameTeamRefs(params.id, before.teamName, data.teamName, before.registration?.clubName || undefined, before.division)
      }
    }

    // Update status via raw SQL if confirming
    if (confirm) {
      try {
        await prisma.$executeRawUnsafe('ALTER TABLE RegisteredTeam ADD COLUMN status TEXT DEFAULT \'confirmed\'')
      } catch { /* already exists */ }
      await prisma.$executeRawUnsafe(
        'UPDATE RegisteredTeam SET status = \'confirmed\' WHERE id = ?',
        teamId
      )
    }

    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to update team' }, { status: 500 })
  }
}

// DELETE: remove a team from the division. Also cleans it out of any pool and
// removes the parent registration when it has no teams left (so a team deleted
// here also disappears from the Registrations list). Multi-team club
// registrations are kept and their team count is decremented.
export async function DELETE(req: NextRequest, { params }: { params: { id: string; division: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  try {
    const { teamId } = await req.json()
    if (!teamId) return NextResponse.json({ error: 'teamId required' }, { status: 400 })
    const division = decodeURIComponent(params.division)

    const team = await prisma.registeredTeam.findUnique({ where: { id: teamId } })
    if (!team) return NextResponse.json({ ok: true })

    // NEVER DELETE A REGISTRATION BY DELETING ITS LAST TEAM (Oct 21 2026). This used
    // to delete the club's whole registration once its only team was gone, and its
    // payments with it (they cascade), with no undo: Space Coast vanished from the
    // registrations page that way. The last team can be withdrawn instead, and a
    // whole registration is removed on the registrations page, where it can be
    // restored.
    if (team.registrationId) {
      const siblings = await prisma.registeredTeam.count({ where: { registrationId: team.registrationId } })
      if (siblings <= 1) {
        return NextResponse.json({
          error: `${team.teamName} is the only team on ${team.clubName || 'its club'}'s registration, so deleting it would delete the registration and its payments. Use Withdraw to take it out of the division and keep the registration, or remove the whole registration on the Registrations page.`,
          lastTeam: true,
        }, { status: 409 })
      }
    }

    await prisma.registeredTeam.delete({ where: { id: teamId } })

    // Take the name off the schedule everywhere it appears -- pools, games,
    // bracket slots, follows. A team name is a string key in more places than
    // anyone remembers, which is why removeTeamRefs is kept next to its rename
    // twin in lib/teamRename: one list, maintained once.
    const removed = await removeTeamRefs(params.id, team.teamName, team.division)

    // Deleting its games takes a game off each opponent it was drawn against,
    // so say who is now short. The organizer is usually rebuilding a schedule
    // when they do this and would otherwise find out on game day.
    let shortWarning: { division: string; pool: string; expected: number; shortTeams: { team: string; games: number; short: number }[]; message: string }[] = []
    try {
      const rest = await prisma.game.findMany({
        where: { tournamentId: params.id, division },
        select: { division: true, pool: true, team1: true, team2: true, isCanceled: true, isChampionship: true },
      })
      shortWarning = findShortTeams(rest as any).map(f => ({
        division: f.division, pool: f.pool, expected: f.expected, shortTeams: f.shortTeams,
        message: describeFinding(f),
      }))
    } catch { /* advisory only: never fail the delete over it */ }

    // Clean up the parent registration
    //
    // YOU CANNOT BILL A CLUB FOR A TEAM THAT IS NOT PLAYING. This used to drop the
    // team and decrement numTeams while leaving invoiceAmount untouched, so a club
    // that pulled a team stayed invoiced for it -- and because dropping below a
    // volume break re-rates the teams that remain, hand-editing the figure gets it
    // wrong as often as not. The staff edit drawer has always recomputed on every
    // team change; this path simply never learned to.
    //
    // Only recomputed when the stored figure still MATCHES the schedule for the
    // roster as it was a moment ago. If someone negotiated a price by hand, that
    // number is a decision, not a stale total, and silently replacing it would be
    // the same class of bug in the other direction -- so it is reported instead.
    let invoice: { was: number; now: number; teams: number } | null = null
    let invoiceHeldBack: { was: number; wouldBe: number; reason: string } | null = null
    if (team.registrationId) {
      try {
        const reg = await prisma.teamRegistration.findUnique({
          where: { id: team.registrationId },
          include: { teams: true },
        })
        const remaining = reg?.teams.length ?? 0
        if (!reg) { /* already gone */ }
        else if (remaining === 0) {
          await prisma.teamRegistration.delete({ where: { id: team.registrationId } })
        } else {
          const t = await prisma.tournament.findUnique({ where: { id: params.id }, select: { registrationPricing: true } })
          const pricing = parsePricing(t?.registrationPricing)
          const asOf = reg.createdAt.toISOString().slice(0, 10)   // price as of when they registered, not today
          const before = calcFee([...reg.teams, team].map(x => ({ division: x.division, waitlisted: x.waitlisted })), pricing, asOf)
          const after = calcFee(reg.teams.map(x => ({ division: x.division, waitlisted: x.waitlisted })), pricing, asOf)
          const unedited = Math.round((reg.invoiceAmount || 0) * 100) === Math.round(before * 100)
          // A DELETION MUST NEVER RAISE A BILL ON ITS OWN.
          //
          // Waitlisted teams are not billed but DO count toward the volume tier, so
          // a club with four committed and one waiting pays the four-team rate.
          // Delete the waiting team and the schedule says three teams at the higher
          // rate -- $4,350 becomes $4,485, and a club that did nothing owes $135 more
          // for being told there was no room. The fix for that club is to leave the
          // team waitlisted, not to delete it, so this reports and leaves it alone.
          const goesUp = Math.round(after * 100) > Math.round((reg.invoiceAmount || 0) * 100)
          const data: { numTeams: number; invoiceAmount?: number } = { numTeams: remaining }
          if (unedited && !goesUp && Math.round(after * 100) !== Math.round(reg.invoiceAmount * 100)) {
            data.invoiceAmount = after
            invoice = { was: reg.invoiceAmount, now: after, teams: remaining }
          } else if (!unedited || goesUp) {
            invoiceHeldBack = { was: reg.invoiceAmount, wouldBe: after, reason: goesUp ? 'would raise the invoice' : 'invoice was set by hand' }
          }
          await prisma.teamRegistration.update({ where: { id: team.registrationId }, data })
        }
      } catch { /* registration may have linked records; non-fatal */ }
    }

    return NextResponse.json({ ok: true, removed, shortWarning, invoice, invoiceHeldBack })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to delete team' }, { status: 500 })
  }
}
