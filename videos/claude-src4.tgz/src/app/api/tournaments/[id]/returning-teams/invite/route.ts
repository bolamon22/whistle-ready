import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { requireFeature } from '@/lib/apiAuth'
import { runReturningInvite, type InviteClub } from '@/lib/returningInvite'
import { OFFICE_CC } from '@/lib/email'
import { createScheduled } from '@/lib/commSchedule'

// Invite past-event clubs back — now, or queued for later (Bo). The send itself
// lives in src/lib/returningInvite.ts so the cron runs identical code.

export async function POST(req: Request, { params }: { params: { id: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireFeature('tournament_people'); if (!gate.ok) return gate.res
  const body = await req.json() as {
    clubs: InviteClub[]
    subjectTemplate?: string
    bodyTemplate?: string
    sendAt?: string
    test?: boolean
  }
  const { clubs } = body
  if (!clubs?.length) return NextResponse.json({ error: 'clubs required' }, { status: 400 })

  // One copy to the signed-in staffer, built from the first club on the list so
  // the merge fields are real. The address comes from the SESSION, never the
  // request body — a typo there would put a club invite in front of a stranger.
  // Nothing is written and no club is emailed.
  if (body.test === true) {
    const session = await getServerSession(authOptions)
    const me = String((session?.user as { email?: string } | undefined)?.email || '').trim().toLowerCase()
    if (!me) return NextResponse.json({ error: 'Your account has no email address to send to' }, { status: 400 })
    const t = await runReturningInvite({
      tournamentId: params.id, clubs: clubs.slice(0, 1),
      subjectTemplate: body.subjectTemplate, bodyTemplate: body.bodyTemplate,
      testTo: me,
    })
    if (!t.ok) return NextResponse.json({ error: t.error }, { status: t.status })
    return NextResponse.json({ ok: true, test: true, to: me, sent: t.sent, errors: t.errors })
  }

  const sendAt = String(body.sendAt || '').trim()
  if (sendAt) {
    const when = new Date(sendAt)
    if (isNaN(when.getTime())) return NextResponse.json({ error: 'Bad send time' }, { status: 400 })
    if (when.getTime() < Date.now() - 60_000) return NextResponse.json({ error: 'Pick a time in the future' }, { status: 400 })
    if (clubs.length > 300) return NextResponse.json({ error: 'Max 300 clubs per scheduled send' }, { status: 400 })
    const session = await getServerSession(authOptions)
    const scheduled = await createScheduled({
      tournamentId: params.id,
      type: 'returning',
      kind: 'returning',              // the kind column is for club letters; type drives dispatch
      regIds: [],
      subject: String(body.subjectTemplate || ''),
      body: String(body.bodyTemplate || ''),
      payload: { clubs },
      sendAt: when.toISOString(),
      createdBy: String((session?.user as { name?: string; email?: string } | undefined)?.name || (session?.user as { email?: string } | undefined)?.email || ''),
    })
    return NextResponse.json({ ok: true, scheduled })
  }

  // Send now gets the same receipt the scheduled path gets. The toast that used to be
  // the only signal is gone the moment the tab changes, and nothing here is written to
  // the database, so without this a completed send leaves no trace at all.
  const res = await runReturningInvite({
    tournamentId: params.id, clubs,
    subjectTemplate: body.subjectTemplate, bodyTemplate: body.bodyTemplate,
    notifyTo: OFFICE_CC,
  })
  if (!res.ok) return NextResponse.json({ error: res.error }, { status: res.status })
  return NextResponse.json({ sent: res.sent, errors: res.errors, skippedDupes: res.skippedDupes })
}
