import { NextResponse } from 'next/server'
import prisma from '@/lib/db'
import { requireStaff } from '@/lib/apiAuth'
import { gameGender } from '@/lib/gameGender'
import { eventSideOf } from '@/lib/eventTeamsStore'
import { actorOf, sendOfficialChanges, spotOf, type OfficialChange } from '@/lib/officialChangeAlerts'

// Clear a day's assignments by kind (girls' refs, boys' refs, scorekeepers) and,
// optionally, by field (Bo, Oct 12 2026: "maybe we can do by field").
//
// The kinds used to be ignored: the dialog's tick boxes never reached here, so
// ticking only "Girls Referees" cleared every assignment that day. And the
// division match used Prisma's case-insensitive mode, which this database doesn't
// support. Kinds are now required, and games are sorted boys / girls / both by
// lib/gameGender (a coed game's refs go with either refs kind).
//
// One person (Bo, Oct 17 2026: a scorekeeper said she can't work the whole
// weekend): { workerId, date? } clears just their games, for the whole event or
// one day, with no kinds or fields. The Assigner's Clear box looks them up by name.
const KINDS = ['girls-refs', 'boys-refs', 'scorekeepers'] as const
type Kind = typeof KINDS[number]
const REF_ROLES = new Set(['ref1', 'ref2', 'ref3'])
const LABEL: Record<Kind, string> = { 'girls-refs': "girls' refs", 'boys-refs': "boys' refs", scorekeepers: 'scorekeepers' }

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  // Auth (Jul 2026 sweep): staff only — was previously callable with no auth.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  const body = await req.json().catch(() => ({}))
  const deletedBy = String(body.deletedBy ?? '').trim()
  const date = typeof body.date === 'string' ? body.date : ''
  // `category` is the old single-kind field; still accepted.
  const raw: unknown[] = Array.isArray(body.kinds) ? body.kinds : body.category ? [body.category] : []
  const kinds = new Set(raw.filter((k): k is Kind => (KINDS as readonly string[]).includes(String(k))))
  const fields: string[] = Array.isArray(body.fields) ? body.fields.filter((f: unknown) => typeof f === 'string') : []
  if (!deletedBy) return NextResponse.json({ error: 'Your name is required for the audit log' }, { status: 400 })

  const workerId = typeof body.workerId === 'string' ? body.workerId : ''
  if (workerId) {
    const worker = await prisma.worker.findUnique({ where: { id: workerId }, select: { name: true } })
    if (!worker) return NextResponse.json({ error: 'That person isn’t in the Staff Pool' }, { status: 404 })
    const mine = await prisma.assignment.findMany({
      where: { workerId, game: { tournamentId: params.id, ...(date ? { date } : {}) } },
      select: { id: true, role: true, game: true },
    })
    const gone = mine.length ? await prisma.assignment.deleteMany({ where: { id: { in: mine.map(a => a.id) } } }) : { count: 0 }
    await sendOfficialChanges(params.id, mine.map((a): OfficialChange => ({ kind: 'removed', workerId, role: a.role, spot: spotOf(a.game) })), actorOf(gate))
    await prisma.auditLog.create({
      data: {
        tournamentId: params.id,
        action: 'CLEAR_ASSIGNMENTS',
        deletedBy,
        detail: `Cleared ${gone.count} assignments for ${worker.name}${date ? ` on ${date}` : ' (whole event)'}`,
      },
    })
    return NextResponse.json({ deleted: gone.count })
  }

  if (!date) return NextResponse.json({ error: 'Pick a day' }, { status: 400 })
  if (kinds.size === 0) return NextResponse.json({ error: 'Pick what to clear' }, { status: 400 })

  const games = await prisma.game.findMany({
    where: { tournamentId: params.id, date, ...(fields.length ? { location: { in: fields } } : {}) },
    select: { id: true, division: true, date: true, startTime: true, location: true, gameNumber: true, team1: true, team2: true, isCanceled: true, assignments: { select: { id: true, role: true, workerId: true } } },
  })
  const ids: string[] = []
  const side = await eventSideOf(params.id)   // a division that says neither: the event's teams
  for (const g of games) {
    const gg = gameGender(g.division, side)
    for (const a of g.assignments) {
      const hit = a.role === 'scorekeeper'
        ? kinds.has('scorekeepers')
        : REF_ROLES.has(a.role) && (gg === 'girls' ? kinds.has('girls-refs') : gg === 'boys' ? kinds.has('boys-refs') : kinds.has('girls-refs') || kinds.has('boys-refs'))
      if (hit) ids.push(a.id)
    }
  }
  const deleted = ids.length ? await prisma.assignment.deleteMany({ where: { id: { in: ids } } }) : { count: 0 }
  // Published officials taken off are told (lib/officialChangeAlerts).
  const cleared = new Set(ids)
  await sendOfficialChanges(params.id, games.flatMap(g => g.assignments.filter(a => cleared.has(a.id)).map((a): OfficialChange => ({ kind: 'removed', workerId: a.workerId, role: a.role, spot: spotOf(g) }))), actorOf(gate))

  const what = KINDS.filter(k => kinds.has(k)).map(k => LABEL[k]).join(', ')
  const where = fields.length ? ` on ${fields.map(f => f.split(' - ').pop() || f).join(', ')}` : ''
  await prisma.auditLog.create({
    data: {
      tournamentId: params.id,
      action: 'CLEAR_ASSIGNMENTS',
      deletedBy,
      detail: `Cleared ${deleted.count} assignments (${what})${where} for ${date}`,
    },
  })

  return NextResponse.json({ deleted: deleted.count })
}
