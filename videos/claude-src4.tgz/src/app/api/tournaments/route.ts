import { NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { createClient } from '@libsql/client'
import { requireStaff } from '@/lib/apiAuth'
import { assignEventSlug } from '@/lib/eventSlug'
import { eventTeamsMany, saveEventTeams } from '@/lib/eventTeamsStore'
import { eventScoresMany, saveEventScores } from '@/lib/eventScoresStore'

function db() {
  return createClient({ url: process.env.TURSO_DATABASE_URL!, authToken: process.env.TURSO_AUTH_TOKEN })
}

const INCLUDE = {
  _count: {
    select: {
      games: true,
      teamRegistrations: { where: { deletedAt: null } },
      playerRegistrations: { where: { deletedAt: null } },
    },
  },
  teamRegistrations: { where: { deletedAt: null }, select: { numTeams: true } },
}

function shape(t: any) {
  return {
    ...t,
    _count: { ...t._count, registeredTeams: t.teamRegistrations.reduce((s: number, r: any) => s + r.numTeams, 0) },
    teamRegistrations: undefined,
  }
}

// _count.placedGames: games with a time and a field, so a list can show how far a
// schedule has got ("198 games · 11 placed") without loading every game. One
// groupBy for the whole list.
async function withPlaced(list: any[]) {
  if (list.length === 0) return list
  const rows = await prisma.game.groupBy({
    by: ['tournamentId'],
    where: { tournamentId: { in: list.map(t => t.id) }, NOT: [{ startTime: '' }, { location: '' }] },
    _count: { _all: true },
  })
  const placed = new Map(rows.map((r: any) => [r.tournamentId as string, r._count._all as number]))
  // _count.reffedGames: games with at least their refCount of officials (ref1/ref2/ref3)
  // assigned, for the assigner's home ("198 games · 120 reffed"). Scorekeepers don't count.
  const reffed = new Map<string, number>()
  try {
    const ids = list.map(t => t.id)
    const rr = await prisma.$queryRawUnsafe<{ tournamentId: string; n: number | bigint }[]>(
      `SELECT g."tournamentId" AS "tournamentId", COUNT(*) AS n FROM "Game" g
         JOIN (SELECT "gameId", COUNT(*) AS c FROM "Assignment" WHERE "role" LIKE 'ref%' GROUP BY "gameId") a ON a."gameId" = g.id
        WHERE g."tournamentId" IN (${ids.map(() => '?').join(',')}) AND a.c >= g."refCount"
        GROUP BY g."tournamentId"`, ...ids)
    for (const r of rr) reffed.set(r.tournamentId, Number(r.n))
  } catch (e) { console.error('reffedGames', e) }
  // The kinds of teams each event has (lib/eventTeams), for its card and Edit.
  const teams = await eventTeamsMany(list.map(t => t.id))
  // Score boxes on the Assigner board: on, off, or null = follow the Scores add-on (lib/eventScores).
  const scores = await eventScoresMany(list.map(t => t.id))
  return list.map(t => ({ ...t, teams: teams.get(t.id) ?? [], scores: scores.get(t.id) ?? null, _count: { ...t._count, placedGames: placed.get(t.id) ?? 0, reffedGames: reffed.get(t.id) ?? 0 } }))
}

export async function GET(req: Request) {
  const url = new URL(req.url)
  const viewOrgId = url.searchParams.get('viewOrgId')
  const session = await getServerSession(authOptions)
  const role = (session?.user as any)?.role
  const orgId = (session?.user as any)?.orgId

  // Platform admin sees all tournaments
  if (role === 'admin') {
    if (viewOrgId) {
      const client = db()
      const res = await client.execute({ sql: 'SELECT id FROM "Tournament" WHERE orgId = ?', args: [viewOrgId] })
      const ids = res.rows.map((r: any) => r.id as string)
      if (ids.length === 0) return NextResponse.json([])
      const ts = await prisma.tournament.findMany({ where: { id: { in: ids } }, orderBy: { startDate: 'desc' }, include: INCLUDE })
      return NextResponse.json(await withPlaced(ts.map(shape)))
    }
    const all = await prisma.tournament.findMany({ orderBy: { startDate: 'desc' }, include: INCLUDE })
    return NextResponse.json(await withPlaced(all.map(shape)))
  }

  // Org user: scope to their org. A field director sees only the events assigned to
  // them (lib/fieldDirector).
  if (orgId) {
    const client = db()
    const res = await client.execute({ sql: 'SELECT id FROM "Tournament" WHERE orgId = ?', args: [orgId] })
    const mine: string[] | null = role === 'field_director' ? ((session?.user as any)?.events ?? []) : null
    const ids = res.rows.map((r: any) => r.id as string).filter(id => !mine || mine.includes(id))
    if (ids.length === 0) return NextResponse.json([])
    const tournaments = await prisma.tournament.findMany({
      where: { id: { in: ids } },
      orderBy: { startDate: 'desc' },
      include: INCLUDE,
    })
    return NextResponse.json(await withPlaced(tournaments.map(shape)))
  }

  // Logged in but not assigned to any organization — show nothing (prevents
  // cross-org leakage). Assign the user to an org (Admin → Orgs) to grant access.
  return NextResponse.json([])
}

export async function POST(req: Request) {
  // This route read the session only to decide which org to file the new tournament
  // under -- it never required one, so an unauthenticated POST still created the
  // tournament, just with no orgId. That left it out of every org-scoped list but
  // still visible in the public directory at /api/public/tournaments, i.e. anyone
  // could put a tournament on the site. The rest of the write routes were gated in
  // 188bc8e; this collection route was missed.
  const gate = await requireStaff(); if (!gate.ok) return gate.res
  if (gate.role === 'field_director') return NextResponse.json({ error: 'Field directors can’t create events.' }, { status: 403 })
  const session = gate.session
  const role = (session?.user as any)?.role
  const sessionOrgId = (session?.user as any)?.orgId ?? null

  // For admins in preview mode, use the preview-org cookie as the target org
  let orgId = sessionOrgId
  if (role === 'admin' && !orgId) {
    const cookieHeader = req.headers.get('cookie') ?? ''
    const m = cookieHeader.match(/(?:^|; )preview-org=([^;]*)/)
    if (m) orgId = decodeURIComponent(m[1])
  }

  const { name, sport, startDate, endDate, location, scheduleIncrement, registrationDivisions, teams, scores } = await req.json()
  const tournament = await prisma.tournament.create({
    data: {
      name,
      sport: sport ?? '',
      startDate: startDate ?? '',
      endDate: endDate ?? '',
      location: location ?? '',
      scheduleIncrement: scheduleIncrement ?? 50,
      ...(registrationDivisions ? { registrationDivisions } : {}),
    },
  })
  // A pretty URL from the start; the organizer can edit the base later.
  await assignEventSlug(tournament.id, { name: tournament.name, startDate: tournament.startDate })

  // Set orgId via raw SQL (column exists but not in Prisma schema)
  if (orgId) {
    try {
      await db().execute({ sql: 'UPDATE "Tournament" SET orgId = ? WHERE id = ?', args: [orgId, tournament.id] })
    } catch { /* non-fatal */ }
  }
  // Boys, men's, girls, women's: asked on New Tournament (lib/eventTeams).
  const saved = teams !== undefined
    ? await saveEventTeams(tournament.id, teams, String(session?.user?.name || session?.user?.email || '')).catch(() => [])
    : []
  // Scores on the Assigner board, asked next to Teams (lib/eventScores).
  const savedScores = scores !== undefined
    ? await saveEventScores(tournament.id, scores, String(session?.user?.name || session?.user?.email || '')).catch(() => null)
    : null
  return NextResponse.json({ ...tournament, teams: saved, scores: savedScores }, { status: 201 })
}