import { NextResponse } from 'next/server'
import { createClient } from '@libsql/client'
import { requireStaff } from '@/lib/apiAuth'
import { mergeW9 } from '@/lib/staffW9'
import { moveTrainingEmails } from '@/lib/trainingSends'
import { moveOfficialConfirms } from '@/lib/officialConfirm'

function db() {
  return createClient({ url: process.env.TURSO_DATABASE_URL!, authToken: process.env.TURSO_AUTH_TOKEN })
}

// POST /api/workers/merge {keepId, removeId} — merge two duplicate Workers.
// Repoints roster entries, availability, assignments, time entries, and pay records to
// keepId (dropping rows that would collide on a unique constraint), fills keep's empty
// fields from remove, unions their roles, then deletes remove. Destructive — the Staff
// Pool UI confirms before calling.
export async function POST(req: Request) {
  const gate = await requireStaff()
  if (!gate.ok) return gate.res

  let body: { keepId?: unknown; removeId?: unknown } = {}
  try { body = await req.json() } catch { /* validated below */ }
  const keepId = String(body.keepId ?? '')
  const removeId = String(body.removeId ?? '')
  if (!keepId || !removeId || keepId === removeId) {
    return NextResponse.json({ error: 'keepId and removeId are required and must differ' }, { status: 400 })
  }

  const client = db()
  const kRes = await client.execute({ sql: `SELECT * FROM "Worker" WHERE id = ?`, args: [keepId] })
  const rRes = await client.execute({ sql: `SELECT * FROM "Worker" WHERE id = ?`, args: [removeId] })
  const keep = kRes.rows[0] as Record<string, unknown> | undefined
  const rem = rRes.rows[0] as Record<string, unknown> | undefined
  if (!keep || !rem) return NextResponse.json({ error: 'Worker not found' }, { status: 404 })

  // Org scoping: non-admins may only merge within their own org
  if (gate.role !== 'admin') {
    const kOrg = (keep.orgId as string | null) ?? null
    const rOrg = (rem.orgId as string | null) ?? null
    if ((kOrg && kOrg !== gate.orgId) || (rOrg && rOrg !== gate.orgId)) {
      return NextResponse.json({ error: 'Not allowed' }, { status: 403 })
    }
  }

  // Bo's rule: when one record belongs to someone who signed up themselves, that record
  // stays. Worker and login are linked by email only, so keeping the other record (with a
  // different email) would leave the person's login pointing at nothing: their staff
  // portal, ID card and assignments would vanish for them. Refuse that direction.
  const remEmail = String(rem.email ?? '').trim().toLowerCase()
  const keepEmail = String(keep.email ?? '').trim().toLowerCase()
  // When BOTH have logins (Derwin Moore claimed the imported record's invite, then signed
  // up again under a work email), the organizer picks the one the person uses now; the
  // other login is left with no staff record, so only the kept email works afterwards.
  if (remEmail && keepEmail && remEmail !== keepEmail) {
    const u = await client.execute({ sql: `SELECT 1 FROM "User" WHERE lower(email) = ? LIMIT 1`, args: [remEmail] })
    const k = await client.execute({ sql: `SELECT 1 FROM "User" WHERE lower(email) = ? LIMIT 1`, args: [keepEmail] })
    if (u.rows.length && !k.rows.length) {
      return NextResponse.json({ error: `${String(rem.name ?? 'That person')} signed up with their own login (${remEmail}). Keep that record instead; merging this way would disconnect their login.` }, { status: 409 })
    }
  }

  // Repoint relations, dropping rows that would collide on a unique constraint.
  await client.execute({ sql: `DELETE FROM "RosterEntry" WHERE workerId = ? AND tournamentId IN (SELECT tournamentId FROM "RosterEntry" WHERE workerId = ?)`, args: [removeId, keepId] })
  await client.execute({ sql: `UPDATE "RosterEntry" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] })
  await client.execute({ sql: `DELETE FROM "Availability" WHERE workerId = ? AND (tournamentId || '|' || date) IN (SELECT tournamentId || '|' || date FROM "Availability" WHERE workerId = ?)`, args: [removeId, keepId] })
  await client.execute({ sql: `UPDATE "Availability" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] })
  try {   // availability answers (lib/availability): the kept record's answer wins a day both answered
    await client.execute({ sql: `DELETE FROM "AvailabilityAnswer" WHERE workerId = ? AND (tournamentId || '|' || date) IN (SELECT tournamentId || '|' || date FROM "AvailabilityAnswer" WHERE workerId = ?)`, args: [removeId, keepId] })
    await client.execute({ sql: `UPDATE "AvailabilityAnswer" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] })
  } catch { /* the table is made on first use; nobody has answered yet */ }
  await client.execute({ sql: `UPDATE "Assignment" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] })
  await client.execute({ sql: `UPDATE "TimeEntry" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] })
  await client.execute({ sql: `UPDATE "PaymentRecord" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] })
  try { await client.execute({ sql: `UPDATE "StaffInvite" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] }) } catch { /* raw column may not exist */ }
  try { await client.execute({ sql: `UPDATE "EventExpense" SET workerId = ? WHERE workerId = ?`, args: [keepId, removeId] }) } catch { /* no receipts table yet */ }
  // Training videos they've watched (api/training, keyed by the record their login
  // matched) and the training emails sent to them (lib/trainingSends) move to the kept
  // record. A video watched under both adds the plays together. Before Oct 15 2026 a
  // merge left the views on the deleted record, so the kept one showed them unwatched.
  try {
    const mine = await client.execute({ sql: `SELECT videoId, watchedAt, plays, lastWatchedAt FROM "StaffTraining" WHERE workerKey = ?`, args: [removeId] })
    for (const v of mine.rows as Record<string, unknown>[]) {
      const both = await client.execute({ sql: `SELECT watchedAt, plays, lastWatchedAt FROM "StaffTraining" WHERE workerKey = ? AND videoId = ?`, args: [keepId, String(v.videoId)] })
      const k = both.rows[0] as Record<string, unknown> | undefined
      if (!k) { await client.execute({ sql: `UPDATE "StaffTraining" SET workerKey = ? WHERE workerKey = ? AND videoId = ?`, args: [keepId, removeId, String(v.videoId)] }); continue }
      const first = [String(k.watchedAt || ''), String(v.watchedAt || '')].filter(Boolean).sort()[0] || String(k.watchedAt || '')
      const last = [String(k.lastWatchedAt || k.watchedAt || ''), String(v.lastWatchedAt || v.watchedAt || '')].sort().pop() || ''
      await client.execute({ sql: `UPDATE "StaffTraining" SET plays = ?, watchedAt = ?, lastWatchedAt = ? WHERE workerKey = ? AND videoId = ?`, args: [(Number(k.plays) || 1) + (Number(v.plays) || 1), first, last, keepId, String(v.videoId)] })
      await client.execute({ sql: `DELETE FROM "StaffTraining" WHERE workerKey = ? AND videoId = ?`, args: [removeId, String(v.videoId)] })
    }
  } catch { /* nobody has watched a video yet: no table */ }
  try { await moveTrainingEmails(removeId, keepId) } catch (e) { console.error('merge training emails', e) }
  // Their answers to "confirm your games" and their confirm links (lib/officialConfirm).
  try { await moveOfficialConfirms(removeId, keepId) } catch (e) { console.error('merge game confirmations', e) }

  // Fill keep's empty fields from remove; union roles; keep the stronger flags.
  const pick = (a: unknown, b: unknown) => (a !== null && a !== undefined && String(a).trim() !== '') ? a : ((b as string | null) ?? null)

  // Columns that are NOT NULL with a default read as "set" even when nobody chose them,
  // so a plain empty-check would keep the default and throw away the real answer the
  // other record has. certLevel/payMethod/gender all ship a default, and the imported
  // half of a pair is usually the one carrying the real cert while the fresh signup
  // carries the real pay details -- treat the untouched default as a gap to fill.
  const pickNonDefault = (a: unknown, b: unknown, dflt: string) => {
    const av = String(a ?? '').trim(), bv = String(b ?? '').trim()
    if (av && av !== dflt) return av
    if (bv && bv !== dflt) return bv
    return av || bv || dflt
  }
  let roles: string[] = []
  try {
    const ka = JSON.parse(String(keep.roles ?? '[]')), rb = JSON.parse(String(rem.roles ?? '[]'))
    roles = [...new Set([...(Array.isArray(ka) ? ka : []), ...(Array.isArray(rb) ? rb : [])])].map(String).filter(Boolean)
  } catch { /* fall back below */ }
  if (!roles.length) roles = [String(keep.defaultRole ?? 'ref')]

  await client.execute({
    sql: `UPDATE "Worker" SET email = ?, phone = ?, association = ?, payHandle = ?, payMethod = ?, certLevel = ?, gender = ?, notes = ?, photoUrl = ?, payRateOverride = ?, hourlyRate = ?, roles = ?, isAssigner = ?, updatedAt = datetime('now') WHERE id = ?`,
    args: [
      pick(keep.email, rem.email), pick(keep.phone, rem.phone), pick(keep.association, rem.association),
      pick(keep.payHandle, rem.payHandle),
      pickNonDefault(keep.payMethod, rem.payMethod, 'check'),
      pickNonDefault(keep.certLevel, rem.certLevel, 'youth'),
      pickNonDefault(keep.gender, rem.gender, 'both'),
      pick(keep.notes, rem.notes), pick(keep.photoUrl, rem.photoUrl),
      (keep.payRateOverride as number | null) ?? (rem.payRateOverride as number | null) ?? null,
      (keep.hourlyRate as number | null) ?? (rem.hourlyRate as number | null) ?? null,
      JSON.stringify(roles), (keep.isAssigner || rem.isAssigner) ? 1 : 0, keepId,
    ],
  })

  // THE PAY DETAILS. venmoHandle / zelleHandle / mailingAddress / w9OnFile are raw
  // columns added by guarded ALTER after this route was written (Sep 4-5 2026), and
  // nothing came back to include them -- so a merge quietly dropped exactly the fields
  // an organizer merges FOR. Someone who signs up fresh has the pay details and no
  // history; the imported record has the history and no pay details. Each column is
  // written on its own because any of them may not exist on an older database yet.
  const filled: string[] = []
  for (const col of ['venmoHandle', 'zelleHandle', 'mailingAddress']) {
    const kv = (keep as Record<string, unknown>)[col]
    const rv = (rem as Record<string, unknown>)[col]
    const value = (kv !== null && kv !== undefined && String(kv).trim() !== '') ? kv : rv
    if (value === null || value === undefined || String(value).trim() === '') continue
    try {
      await client.execute({ sql: `UPDATE "Worker" SET "${col}" = ? WHERE id = ?`, args: [value as string, keepId] })
      filled.push(col)
    } catch { /* column not on this database yet */ }
  }

  // The W-9 lives in AppSetting under the worker's id (lib/staffW9), so it has to move
  // with the person. w9OnFile used to be merged as a column above, where the kept
  // record's 0 beat the other record's 1 and the file was left under the deleted id.
  try { if (await mergeW9(keepId, removeId)) filled.push('w9OnFile') } catch (e) { console.error('merge w9', e) }

  // A record with no organization (older than org scoping, like both of Haylee Lamon's,
  // Oct 15 2026) takes the other record's, or else the merging director's, so the
  // person shows in their org's lists and sends again.
  const org = String(keep.orgId || '') || String(rem.orgId || '') || gate.orgId || ''
  if (!keep.orgId && org) {
    await client.execute({ sql: `UPDATE "Worker" SET orgId = ? WHERE id = ?`, args: [org, keepId] })
    filled.push('orgId')
  }

  // The ref level (lib/refLevel): the kept record's, else the other one's.
  if ((keep.refLevel === null || keep.refLevel === undefined) && rem.refLevel !== null && rem.refLevel !== undefined) {
    try { await client.execute({ sql: `UPDATE "Worker" SET "refLevel" = ? WHERE id = ?`, args: [Number(rem.refLevel), keepId] }); filled.push('refLevel') } catch { /* no column yet */ }
  }

  await client.execute({ sql: `DELETE FROM "Worker" WHERE id = ?`, args: [removeId] })
  return NextResponse.json({ ok: true, keepId, filled })
}
