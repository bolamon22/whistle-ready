import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { sendEmail, orgSender } from '@/lib/email'
import { orgForTournament } from '@/lib/org'
import crypto from 'crypto'
import { ensureStaffInviteTable } from '@/lib/staffInviteTable'
import { requireFeature, eventGate } from '@/lib/apiAuth'
import { tournamentOrgId } from '@/lib/org'

const APP_URL = process.env.APP_PUBLIC_URL || 'https://whistleready.app' // NOT NEXTAUTH_URL — prod's still points at old gameday-staff5.vercel.app (found Aug 28)

// "Invite Staff" on a tournament's Staff roster. It took no login at all (found Oct 13
// 2026), so anyone could send invites from the organization's address. Now it's for
// staff who can open the roster, for their own organization's events; a field
// director (lib/fieldDirector) for their own events.
export async function POST(req: NextRequest) {
  const gate = await requireFeature('tournament_roster'); if (!gate.ok) return gate.res
  try {
    const { email, name, tournamentId } = await req.json()
    if (!email) return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    if (!tournamentId && gate.role !== 'admin' && gate.role !== 'director') return NextResponse.json({ error: 'Pick the event to invite them to' }, { status: 400 })
    if (tournamentId) {
      const refused = eventGate(gate, String(tournamentId)); if (refused) return refused
      if (gate.role !== 'admin' && gate.orgId && (await tournamentOrgId(String(tournamentId))) !== gate.orgId) return NextResponse.json({ error: 'Tournament not found' }, { status: 404 })
    }

    await ensureStaffInviteTable()

    // Check if worker already exists
    const existing = await prisma.worker.findFirst({ where: { email: email.toLowerCase() } })
    if (existing) return NextResponse.json({ error: 'A staff member with this email already exists' }, { status: 409 })

    // Expire any previous unused invites for this email
    await prisma.staffInvite.updateMany({
      where: { email: email.toLowerCase(), usedAt: null },
      data: { expiresAt: new Date() },
    })

    const token = crypto.randomBytes(32).toString('hex')
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days

    // Get tournament name if provided
    let tournamentName = 'Staff Invite'
    if (tournamentId) {
      const t = await prisma.tournament.findUnique({ where: { id: tournamentId }, select: { name: true } })
      if (t) tournamentName = t.name
    }

    await prisma.staffInvite.create({
      data: { token, email: email.toLowerCase(), name: name || null, tournamentId: tournamentId || null, expiresAt },
    })

    const inviteUrl = `${APP_URL}/invite/${token}`

    // From the ORG (the employer), when the invite is tied to a tournament we can
    // resolve an org for — same rule as /api/workers/onboard (Bo, Aug 28 2026).
    const org = tournamentId ? await orgForTournament(tournamentId) : null
    await sendEmail({
      ...orgSender(org),
      to: email,
      subject: `You're invited to join ${tournamentName} staff`,
      html: `
        <div style="font-family: sans-serif; max-width: 480px; margin: 0 auto; padding: 32px 24px;">
          <h2 style="font-size: 22px; font-weight: 700; color: #0f172a; margin: 0 0 8px;">
            You've been invited to join the ${tournamentName} staff
          </h2>
          <p style="color: #475569; font-size: 15px; line-height: 1.6; margin: 0 0 24px;">
            ${name ? `Hi ${name}, ` : ''}Click the button below to accept your invite. It takes less than a minute.
          </p>
          <a href="${inviteUrl}"
            style="display: inline-block; background: #14b8a6; color: white; font-weight: 600;
                   font-size: 15px; padding: 12px 28px; border-radius: 10px; text-decoration: none;">
            Accept Invite →
          </a>
          <p style="color: #94a3b8; font-size: 13px; margin: 24px 0 0;">
            This link expires in 7 days. If you weren't expecting this, you can ignore it.
          </p>
        </div>
      `,
    })

    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to send invite' }, { status: 500 })
  }
}
