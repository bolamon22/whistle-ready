import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { viewAs } from '@/lib/clubDirectorView'
import { ensurePaymentGuard } from '@/lib/paymentGuard'
import { openableRegistrations } from '@/lib/clubAccess'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const as = viewAs(session, req.nextUrl.searchParams.get('userId'))
  if (!as.ok) return as.res

  // Every registration this login can open, at every event (lib/clubAccess):
  // per registration, not per club name.
  const openable = await openableRegistrations(as.userId)
  if (openable.length === 0) return NextResponse.json([])

  // Group by tournament
  const tournamentIds = Array.from(new Set(openable.map(r => r.tournamentId)))
  const clubsByTournament: Record<string, string[]> = {}
  const regIdsByTournament: Record<string, string[]> = {}
  for (const r of openable) {
    if (!clubsByTournament[r.tournamentId]) clubsByTournament[r.tournamentId] = []
    if (!clubsByTournament[r.tournamentId].includes(r.clubName)) clubsByTournament[r.tournamentId].push(r.clubName)
    regIdsByTournament[r.tournamentId] = [...(regIdsByTournament[r.tournamentId] || []), r.id]
  }

  const tournaments = await prisma.tournament.findMany({
    where: { id: { in: tournamentIds } },
    orderBy: { startDate: 'desc' },
  })

  await ensurePaymentGuard()
  const history = await Promise.all(tournaments.map(async (t) => {
    const clubNames = clubsByTournament[t.id] ?? []

    // Registrations & payments
    const registrations = await prisma.teamRegistration.findMany({
      // deletedAt: null, or a registration staff removed still counts against
      // the club. LaxManiax saw $8,970 owing on an account paid in full,
      // because deleted duplicates kept their invoice while only the live
      // registration's payments were credited (Sep 15 2026).
      where: { id: { in: regIdsByTournament[t.id] ?? [] }, deletedAt: null },
      include: {
        teams: true,
        payments: { orderBy: { receivedAt: 'asc' } },
      },
    })

    const teamNames = registrations.flatMap(r => r.teams.map(tm => tm.teamName)).filter(Boolean)

    // Games involving these teams
    const games = teamNames.length > 0 ? await prisma.game.findMany({
      where: {
        tournamentId: t.id,
        OR: [{ team1: { in: teamNames } }, { team2: { in: teamNames } }],
      },
    }) : []

    // Calculate W/L/T record per team
    const record = { wins: 0, losses: 0, ties: 0, gamesPlayed: 0 }
    const championshipWins: string[] = []
    for (const g of games) {
      if (g.score1 === null || g.score2 === null) continue
      const myTeam = teamNames.includes(g.team1) ? 'team1' : 'team2'
      const myScore = myTeam === 'team1' ? g.score1 : g.score2
      const oppScore = myTeam === 'team1' ? g.score2 : g.score1
      record.gamesPlayed++
      if (myScore > oppScore) {
        record.wins++
        if (g.isChampionship) {
          const teamName = myTeam === 'team1' ? g.team1 : g.team2
          championshipWins.push(`${teamName} (${g.division})`)
        }
      } else if (myScore < oppScore) {
        record.losses++
      } else {
        record.ties++
      }
    }

    // Financial summary
    const invoiceTotal = registrations.reduce((s, r) => s + r.invoiceAmount - r.discountAmount, 0)
    const paidTotal = registrations.reduce((s, r) => s + r.payments.reduce((ps, p) => ps + p.amount, 0), 0)
    const allPayments = registrations.flatMap(r =>
      r.payments.map(p => ({ ...p, clubName: r.clubName }))
    ).sort((a, b) => a.receivedAt.localeCompare(b.receivedAt))

    return {
      tournament: {
        id: t.id, name: t.name, sport: t.sport,
        startDate: t.startDate, endDate: t.endDate,
        location: t.location, logoUrl: t.logoUrl,
      },
      clubs: clubNames,
      teams: registrations.flatMap(r => r.teams),
      // No notes: those are the office's own notes about the club (and now
      // where the portal logs what a club did), never meant for the club.
      registrations: registrations.map(r => ({
        id: r.id, clubName: r.clubName, clubContact: r.clubContact,
        contactEmail: r.contactEmail, contactPhone: r.contactPhone,
        clubBasedIn: r.clubBasedIn, clubWebsite: r.clubWebsite,
        paymentMethod: r.paymentMethod,
        numTeams: r.numTeams, needsHotel: r.needsHotel,
        teams: r.teams,
      })),
      record,
      championshipWins,
      finance: { invoiceTotal, paidTotal, balance: invoiceTotal - paidTotal, payments: allPayments },
    }
  }))

  return NextResponse.json(history)
}
