import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { orgForTournament } from '@/lib/org'
import { ensurePaymentGuard } from '@/lib/paymentGuard'
import { clearingTransfers } from '@/lib/pendingTransfers'

// Public by design: the registration id in the URL is the capability (same model
// as /claim links). Returns ONLY what the public pay page needs — no contact info.
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await ensurePaymentGuard()
    const reg = await prisma.teamRegistration.findUnique({
      where: { id: params.id },
      include: { teams: true, payments: true },
    })
    if (reg && reg.deletedAt) {
      // A registration merged into another one: send the pay page to the survivor so
      // old pay links keep working.
      try {
        const m = await prisma.$queryRawUnsafe<any[]>(`SELECT "mergedIntoId" FROM "TeamRegistration" WHERE id = ?`, params.id)
        const into = String(m?.[0]?.mergedIntoId || '')
        if (into) return NextResponse.json({ mergedInto: into })
      } catch { /* column not there yet */ }
    }
    if (!reg || reg.deletedAt) return NextResponse.json({ error: 'Registration not found' }, { status: 404 })

    const tournament = await prisma.tournament.findUnique({
      where: { id: reg.tournamentId },
      select: { id: true, name: true, startDate: true, endDate: true, location: true, logoUrl: true },
    })

    const org = await orgForTournament(reg.tournamentId)

    const paid = reg.payments.reduce((s, p) => s + p.amount, 0)
    const due = (reg.invoiceAmount || 0) - (reg.discountAmount || 0)
    // A bank transfer still clearing counts against the balance here, so a club
    // that opens this link again while it settles is not asked to pay twice
    // (lib/pendingTransfers). If the bank rejects it, it stops counting.
    const clearing = (await clearingTransfers([reg.id]))[reg.id] || null
    const inFlight = clearing?.amount || 0
    const balance = Math.round(Math.max(0, due - paid - inFlight) * 100) / 100

    return NextResponse.json({
      clubName: reg.clubName,
      teamCount: reg.teams.length,
      // Itemized roster so clubs can see exactly what the invoice covers.
      // Team name + division only — never coach contact info on a public route.
      teams: reg.teams.map(t => ({ team: t.teamName, division: t.division })),
      tournamentId: reg.tournamentId,
      tournamentName: tournament?.name || '',
      tournamentDates: tournament?.startDate
        ? `${tournament.startDate}${tournament.endDate && tournament.endDate !== tournament.startDate ? ' to ' + tournament.endDate : ''}`
        : '',
      location: tournament?.location || '',
      logoUrl: tournament?.logoUrl || '',
      zelleHandle: org?.zelleHandle || '',
      due, paid, balance,
      clearing: clearing ? { amount: clearing.amount, startedAt: clearing.startedAt } : null,
      paidInFull: due > 0 && balance <= 0,
      noInvoice: due <= 0,
    })
  } catch (e) {
    console.error('pay-info failed:', e)
    return NextResponse.json({ error: 'Failed to load' }, { status: 500 })
  }
}
