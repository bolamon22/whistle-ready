import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'
import { sendEmail, emailEnabled, orgSender } from '@/lib/email'
import { tournamentOrgId, orgById } from '@/lib/org'
import { sendPushToOrg } from '@/lib/push'
import { parsePricing, calcFee } from '@/lib/regPricing'
import { resolveRegConfirmation, buildRegLetter, letterToEmailHtml, organizerEmailHtml, organizerEmailSubject, type RegLetterData, type RegNotifyData } from '@/lib/regConfirmation'
import { scopedEmailsForSeries } from '@/lib/scopedNotify'
import { seriesLabelOf } from '@/lib/eventSeries'
import { issueClaimToken, claimUrl, setUpPortalLogin, type PortalLogin } from '@/lib/claim'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { SITE_URL, tournamentAbs } from '@/lib/seo'
import { hasHowTo, howToPath } from '@/lib/howToVideos'
import { getHowToVisibility } from '@/lib/videoVisibility'
import { waiverCounts, summarizeClub, coachSignatures } from '@/lib/waiverCounts'
import { cleanName, nameKey } from '@/lib/names'
import { isDivisionFull } from '@/lib/regStatus'
import { canOpen, directorsOf } from '@/lib/clubAccess'
import { ensurePaymentGuard } from '@/lib/paymentGuard'
import { orgGate, requireStaff, viewerRole } from '@/lib/apiAuth'
import { getPublicVisibility } from '@/lib/publicView'
import { canSeeMoney, canSeeContacts, payStatus } from '@/lib/roleScope'
import { portalUsage } from '@/lib/portalVisits'
import { recordTermsAcceptance, requestMeta } from '@/lib/terms'
import { TERMS_VERSION } from '@/lib/termsVersion'

async function ensureRegistrationColumns() {
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "clubLogoUrl" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "instagramHandle" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  // Travel/room-night tracking (Aug 2026): raw columns like instagramHandle --
  // kept out of the Prisma schema so no client regen / migration is needed.
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "hotelName" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "hotelRooms" INTEGER NOT NULL DEFAULT 0`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "hotelNights" INTEGER NOT NULL DEFAULT 0`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "lastPayReminderAt" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "commEmailLog" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "confirmStatus" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "confirmNote" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "TeamRegistration" ADD COLUMN "confirmAt" TEXT NOT NULL DEFAULT ''`) } catch { /* already exists */ }
  // Waiting-list teams: registered but not invoiced. See src/lib/regPricing.ts.
  try { await prisma.$executeRawUnsafe(`ALTER TABLE "RegisteredTeam" ADD COLUMN "waitlisted" BOOLEAN NOT NULL DEFAULT 0`) } catch { /* already exists */ }
}

// "@yourclub", "instagram.com/yourclub", "https://www.instagram.com/yourclub/" → "yourclub"
function normalizeInstagram(raw?: string): string {
  let s = String(raw || '').trim()
  if (!s) return ''
  s = s.replace(/^https?:\/\/(www\.)?instagram\.com\//i, '').replace(/^@/, '').replace(/[/?#].*$/, '')
  return s.slice(0, 60)
}

// What a caller who is not allowed the whole registration still gets.
//
// This list had no sign-in check, so every club's contact email, phone, notes,
// invoice and payment history was readable by anyone with a tournament id, and
// by every coach (the coach dashboard reads it for team names). Now:
//  - director / admin: everything, as before
//  - other staff (scheduler, assigner, staff): clubs and teams, waiver and coach
//    counts, and whether the club has paid (paid / partial / unpaid) but no
//    amounts. Contacts only for roles that work with clubs and staff (assigner).
//  - signed out or external (coach, parent, club director): team names and
//    divisions, and only once Teams & pools is public (see GET).
const EXTERNAL = ['coach', 'parent', 'club_director']
function shapeForRole(list: any[], role: string): any[] {
  if (canSeeMoney(role)) return list
  const staff = !!role && !EXTERNAL.includes(role)
  const contacts = staff && canSeeContacts(role)
  return list.map((r: any) => {
    const teams = (r.teams || []).map((t: any) => staff
      ? {
          id: t.id, registrationId: t.registrationId, teamName: t.teamName, clubName: t.clubName,
          division: t.division, logoUrl: t.logoUrl, waitlisted: !!t.waitlisted, pool: t.pool ?? null,
          coachName: t.coachName, waiverCount: t.waiverCount, coachesSigned: t.coachesSigned,
          ...(contacts ? { coachEmail: t.coachEmail, coachPhone: t.coachPhone } : {}),
        }
      : { teamName: t.teamName, clubName: t.clubName, division: t.division, logoUrl: t.logoUrl })
    if (!staff) return { id: r.id, clubName: r.clubName, teams }
    const received = (r.payments || []).reduce((n: number, x: any) => n + (Number(x.amount) || 0), 0)
    return {
      id: r.id, tournamentId: r.tournamentId, clubName: r.clubName, clubLogoUrl: r.clubLogoUrl,
      numTeams: r.numTeams, createdAt: r.createdAt, confirmStatus: r.confirmStatus,
      payStatus: payStatus((Number(r.invoiceAmount) || 0) - (Number(r.discountAmount) || 0), received),
      waiverUnassigned: r.waiverUnassigned, coachesSigned: r.coachesSigned,
      teams,
      ...(contacts ? { clubContact: r.clubContact, contactEmail: r.contactEmail, contactPhone: r.contactPhone } : {}),
    }
  })
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const tournamentId = searchParams.get('tournamentId')
  if (!tournamentId) return NextResponse.json({ error: 'tournamentId required' }, { status: 400 })

  await ensureRegistrationColumns()
  await ensurePaymentGuard()
  let role = await viewerRole()
  // A director, scheduler, assigner or field director working in another
  // organization gets what the public gets here (lib/orgScope).
  if (role && !EXTERNAL.includes(role)) {
    const staff = await requireStaff()
    if (staff.ok && await orgGate(staff, tournamentId)) role = ''
  }
  // Signed out or external (coach, parent, club director): the team list is the
  // Teams & pools switch's to give. It went out regardless, on the grounds that
  // the public page showed it anyway, but the public page no longer shows teams
  // before that switch, and anyone can make a coach or parent account. Found
  // Oct 4 2026, after a club knew Fall Classic's middle-school count.
  if (!role || EXTERNAL.includes(role)) {
    const vis = await getPublicVisibility(tournamentId).catch(() => null)
    if (vis?.pools !== 'live') return NextResponse.json([])
  }
  const registrations = await prisma.teamRegistration.findMany({
    where: { tournamentId, deletedAt: null },
    include: { teams: true, payments: { orderBy: { receivedAt: 'asc' } } },
    orderBy: { createdAt: 'desc' },
  })
  // Raw columns (hotel/instagram) aren't in the Prisma schema -- merge them in.
  try {
    const extras: any[] = await prisma.$queryRawUnsafe(
      `SELECT id, "hotelName", "hotelRooms", "hotelNights", "instagramHandle", "lastPayReminderAt", "commEmailLog", "confirmStatus", "confirmNote", "confirmAt" FROM "TeamRegistration" WHERE tournamentId = ?`, tournamentId)
    const byId = new Map(extras.map((e: any) => [e.id, e]))
    // Per-hotel bookings (a club can split across hotels; logged on the housing
    // board). Table is created lazily by the housing feature — absent = no bookings.
    const bookingsById = new Map<string, any[]>()
    try {
      const bs: any[] = await prisma.$queryRawUnsafe(
        `SELECT b.id, b.regId, b.hotel, b.rooms, b.nights FROM "HousingBooking" b JOIN "TeamRegistration" r ON b.regId = r.id WHERE r.tournamentId = ? ORDER BY b.createdAt ASC`, tournamentId)
      for (const b of bs) {
        if (!bookingsById.has(b.regId)) bookingsById.set(b.regId, [])
        bookingsById.get(b.regId)!.push({ id: b.id, hotel: b.hotel, rooms: Number(b.rooms) || 0, nights: Number(b.nights) || 0 })
      }
    } catch { /* table not there yet */ }
    // Completed player waivers per team — see src/lib/waiverCounts.ts for why the
    // stored "Club — Team" tag has to be split before anything matches.
    const counts = await waiverCounts(tournamentId)
    // Which coaches have actually signed, matched to their teams the same way.
    // The COACH column on this page is whoever the club TYPED at registration --
    // useful for calling someone, silent on whether a waiver exists. These are
    // the signatures (Bo, Sep 17 2026).
    const coaches = await coachSignatures(tournamentId)

    // Does the club contact have a Whistle Ready login? Matched by email, same
    // way the claim flow and the Staff Pool's App column do it.
    const accounts = new Map<string, { id: string; role: string; name: string }>()
    try {
      const emails = [...new Set(registrations.map((r: any) => String(r.contactEmail || '').trim().toLowerCase()).filter(Boolean))]
      if (emails.length) {
        const us: any[] = await prisma.$queryRawUnsafe(
          `SELECT id, lower(email) AS email, role, name FROM "User" WHERE lower(email) IN (${emails.map(() => '?').join(',')})`, ...emails)
        // id comes along so the Account chip can open that person's own club
        // portal (Bo, Sep 15 2026) -- reading the bug report beat guessing.
        for (const u of us) accounts.set(String(u.email), { id: String(u.id || ''), role: String(u.role || ''), name: String(u.name || '') })
      }
    } catch { /* no account info — the card just won't show a badge */ }

    // When each club last opened its portal, and how often (lib/portalVisits;
    // Bo, Oct 5 2026). Only the full view carries it: shapeForRole rebuilds the
    // row for every other role and leaves it out.
    const usage = canSeeMoney(role) ? await portalUsage(registrations.map((r: any) => r.id)) : new Map()
    // Who can open each registration in the portal (lib/clubAccess). A contact can
    // have a login that was never connected to this registration -- a parent
    // account from before, or a director whose access covers their other event --
    // and "has a login" made the card read as fine while their portal showed
    // nothing (Creator's Game, Riverwolves and Stealth, Oct 5 2026).
    const openers = canSeeMoney(role) ? await directorsOf(registrations.map((r: any) => r.id)) : new Map()

    return NextResponse.json(shapeForRole(registrations.map((r: any) => {
      const sum = summarizeClub(counts, r.clubName, r.teams || [])
      return {
        ...r,
        ...((byId.get(r.id) as any) || {}),
        bookings: bookingsById.get(r.id) ?? [],
        teams: (r.teams || []).map((t: any, i: number) => ({
          ...t,
          waiverCount: sum.perTeam[i] ?? 0,
          coachesSigned: coaches.forTeam(t.clubName || r.clubName, t.teamName),
        })),
        waiverUnassigned: sum.unassigned,
        coachesSigned: coaches.forClub(r.clubName),
        hasAccount: accounts.has(String(r.contactEmail || '').trim().toLowerCase()),
        accountRole: accounts.get(String(r.contactEmail || '').trim().toLowerCase())?.role || '',
        accountUserId: accounts.get(String(r.contactEmail || '').trim().toLowerCase())?.id || '',
        // Shown before an admin connects the login by hand (ConnectLoginDialog).
        accountName: accounts.get(String(r.contactEmail || '').trim().toLowerCase())?.name || '',
        portal: usage.get(r.id) || null,
        portalOpenable: (openers.get(r.id)?.length ?? 0) > 0,
        accountCanOpen: !!(openers.get(r.id) || []).some((d: any) => d.userId === accounts.get(String(r.contactEmail || '').trim().toLowerCase())?.id),
      }
    }), role))
  } catch {
    return NextResponse.json(shapeForRole(registrations, role))
  }
}

const fmtDay = (d: string) => { if (!d) return ''; const [y, m, day] = d.split('-'); const dt = new Date(+y, +m - 1, +day); return isNaN(dt.getTime()) ? d : dt.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) }
function fmtDates(s?: string, e?: string) {
  if (!s) return ''
  if (e && e !== s) {
    const [sy, sm] = s.split('-'); const [ey] = e.split('-')
    if (sy === ey && sm === e.split('-')[1]) return `${fmtDay(s)}–${parseInt(e.split('-')[2])}, ${ey}`
    if (sy === ey) return `${fmtDay(s)} – ${fmtDay(e)}, ${ey}`
    return `${fmtDay(s)}, ${sy} – ${fmtDay(e)}, ${ey}`
  }
  return `${fmtDay(s)}, ${s.split('-')[0]}`
}
const jget = async (key: string) => { try { const r = await prisma.appSetting.findUnique({ where: { key } }); return r ? JSON.parse(r.value || '{}') : {} } catch { return {} } }

// Build the confirmation "response letter" and (optionally) email it to the club contact.
async function buildAndSendConfirmation(reg: any, portal?: PortalLogin, sameNameAs: RegNotifyData['sameNameAs'] = []) {
  try {
    const t: any = await prisma.tournament.findUnique({ where: { id: reg.tournamentId } })
    if (!t) return null
    // orgId / Organization are raw SQL, not Prisma schema -- reading them through
    // the typed client made `org` null on EVERY registration, which blanked the
    // org name in the letter, pointed links at whistleready.app instead of the
    // org's own domain, ignored the org Forms library, dropped the Reply-To, and
    // (the reason nobody ever got a heads-up) left the organizer notification
    // with zero recipients. See src/lib/org.ts.
    const orgId = await tournamentOrgId(reg.tournamentId)
    const org: any = await orgById(orgId)
    const orgForms = orgId ? await jget(`orgForms:${orgId}`) : {}
    let override: any = null
    try { const rr: any[] = await prisma.$queryRawUnsafe('SELECT regConfirmationOverride FROM "Tournament" WHERE id = ?', reg.tournamentId); const raw = rr?.[0]?.regConfirmationOverride; if (raw) override = JSON.parse(raw) } catch {}
    const cfg = resolveRegConfirmation(orgForms.registration, override)

    // waitlisted is carried through now. It used to be dropped right here, so the
    // letter (and the organizer's call sheet) could not tell a full-division team
    // from a confirmed one -- Fire Ants, Oct 1 2026, waitlisted with their only
    // team, were told their spot was reserved and shown a $0 total.
    const teams = (reg.teams || []).map((x: any) => ({ team: x.teamName || x.clubName || 'Team', division: x.division || '', waitlisted: !!x.waitlisted }))
    let amount = Number(reg.invoiceAmount) || 0
    // Recompute from reg.teams, NOT the display array above -- that one is
    // mapped down to {team, division} and drops waitlisted, so billing off it
    // would quote the club for teams the waiting list says we are not charging.
    if (!amount) { try { amount = calcFee((reg.teams || []).map((x: any) => ({ division: x.division || '', waitlisted: !!x.waitlisted })), parsePricing((t as any).registrationPricing)) } catch {} }
    if (reg.discountAmount) amount = Math.max(0, amount - Number(reg.discountAmount))
    // Paid online at signup? Thank them in the letter instead of dunning them.
    const received = (reg.payments || []).reduce((s: number, p: any) => s + (Number(p.amount) || 0), 0)
    const paid = amount > 0 && received >= amount

    // Public links live on the org's custom domain when it has one
    // (e.g. sunshineeventsgroup.com), matching where families actually browse.
    const base = (path: string) => tournamentAbs(org?.slug, path)
    const data: RegLetterData = {
      tournamentName: t.name || 'the tournament',
      orgName: org?.name || '',
      dates: fmtDates((t as any).startDate, (t as any).endDate),
      location: (t as any).location || '',
      clubName: reg.clubName || reg.clubContact || '',
      contactName: reg.clubContact || '',
      teams,
      amount,
      paymentMethod: reg.paymentMethod || '',
      paid,
      eventUrl: base(`/tournaments/${reg.tournamentId}/event`),
      gameDayUrl: base(`/tournaments/${reg.tournamentId}/today`),
      // Waivers are in-app now — point families at the tournament's online form.
      waiverUrl: base(`/tournaments/${reg.tournamentId}/player-waiver`),
      ...(hasHowTo(org?.slug) ? await (async () => { const vis = await getHowToVisibility(); return { waiverVideoUrl: base(howToPath('waiver', vis)), portalVideoUrl: base(howToPath('club-portal', vis)) } })() : {}),
      // The account box. Made or linked on the form just now: the portal is
      // ready, so no set-up link. A returning contact already linked to this
      // club here (lib/clubDirectorLinks): welcome back. A contact with an
      // account that is NOT linked to it gets the claim link to add the event
      // (the claim page asks for their existing password): saying "this is tied
      // to your login" there was not true. Anyone else gets the single-use claim
      // link that creates their login (best-effort; omit the CTA on failure).
      ...(await (async () => {
        if (portal?.status === 'created') return { hasAccount: true, accountCreated: true, loginUrl: `${SITE_URL}/login` }
        if (portal?.status === 'linked') return { hasAccount: true, loginUrl: `${SITE_URL}/login` }
        try {
          const existing = reg.contactEmail
            ? await prisma.user.findUnique({ where: { email: String(reg.contactEmail).toLowerCase() } })
            : null
          if (existing) {
            if (await canOpen(existing.id, reg.id)) return { hasAccount: true, loginUrl: `${SITE_URL}/login` }
            const token = await issueClaimToken(reg.id)
            return token ? { claimUrl: claimUrl(SITE_URL, token), claimForExisting: true } : { hasAccount: true, loginUrl: `${SITE_URL}/login` }
          }
        } catch {}
        const token = await issueClaimToken(reg.id)
        return token ? { claimUrl: claimUrl(SITE_URL, token) } : {}
      })()),
    }
    const letter = buildRegLetter(cfg, data)

    let emailed = false
    if (cfg.enabled && reg.contactEmail && emailEnabled()) {
      // best-effort; sendEmail never throws so registration is never blocked
      const sent = await sendEmail({
        to: reg.contactEmail,
        subject: letter.subject,
        html: letterToEmailHtml(letter, data),
        // From the tournament company, not from Whistle Ready. orgSender() also
        // points Reply-To at the org's real inbox.
        ...orgSender(org),
      })
      emailed = sent.ok
    }

    // Internal heads-up so a human can call the club director while it's warm.
    // Recipients come from the confirmation config's notifyEmails (comma-
    // separated); org site contact + org account email are the fallback.
    if (emailEnabled()) {
      const orgSite = orgId ? await jget(`orgSite:${orgId}`) : {}
      const fallback = [orgSite?.contact?.email, org?.contactEmail].filter(Boolean).join(',')
      // Base list (all-events notifyEmails, or the org fallback) plus anyone scoped
      // to THIS tournament's event via the per-person checkboxes.
      const scoped = scopedEmailsForSeries(cfg.notifyScoped, seriesLabelOf(String(t.name || '')))
      const recipients = Array.from(new Set([...String(cfg.notifyEmails || fallback || '').split(','), ...scoped]
        .map(s => s.trim().toLowerCase()).filter(s => s.includes('@'))))
      // Loud on purpose: silently sending to nobody is why new registrations
      // went unnoticed. Set "Notify your team" in the org Forms library, or give
      // the org a contactEmail.
      if (!recipients.length) console.warn('[registrations] no notification recipients for tournament', reg.tournamentId)
      if (recipients.length) {
        const notify: RegNotifyData = {
          ...data,
          contactEmail: reg.contactEmail || '',
          contactPhone: reg.contactPhone || '',
          clubBasedIn: reg.clubBasedIn || '',
          needsHotel: reg.needsHotel || '',
          notes: reg.notes || '',
          instagram: reg.instagramHandle || '',
          // Staff console link stays on whistleready.app — that's where staff log in.
          adminUrl: `${SITE_URL}/tournaments/${reg.tournamentId}/registrations`,
          sameNameAs,
        }
        await sendEmail({
          to: recipients.join(','),
          subject: organizerEmailSubject(notify),
          html: organizerEmailHtml(notify),
          ...orgSender(org),
          // Reply goes to the CLUB, not back to us -- this email is a call sheet.
          ...(reg.contactEmail ? { replyTo: reg.contactEmail } : {}),
        })
      }
    }
    // Phone push to any subscribed staff device — independent of the email
    // heads-up (best-effort; a push failure never affects the registration).
    await sendPushToOrg(orgId, {
      title: `New registration — ${reg.clubName || 'a club'}`,
      body: `${(reg.teams || []).length} team${(reg.teams || []).length === 1 ? '' : 's'} · ${t.name || 'your tournament'}`,
      url: `/tournaments/${reg.tournamentId}/registrations`,
      tag: `reg-${reg.id}`,
    })

    return { letter, data, emailed }
  } catch { return null }
}

export async function POST(req: NextRequest) {
  await ensurePaymentGuard()
  const body = await req.json()
  const {
    tournamentId, clubName, clubContact, contactEmail, contactPhone,
    clubBasedIn, clubWebsite, numTeams, needsHotel, paymentMethod, notes, teams,
    invoiceAmount, discountAmount, discountNote, clubLogoUrl, source, instagram,
    hotelName, hotelRooms, hotelNights, portalPassword,
  } = body

  const isImport = source === 'import'
  if (!tournamentId || !clubContact || (!isImport && (!contactEmail || !contactPhone))) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
  }

  // Honeypot tripped (spam bot autofilled the hidden field): pretend success,
  // write nothing, send nothing. Same play as the signup form.
  if (body.hp_extra) {
    return NextResponse.json({ id: 'ok', confirmation: null }, { status: 201 })
  }

  // The public form doesn't send invoiceAmount, which left every registration
  // invoiced at $0 on the staff page (the letter computed its own fee, hiding
  // the bug). The server now owns the number: compute from the tournament's
  // pricing whenever the caller didn't provide one.
  // WAITING LIST. A team whose division is marked full right now is recorded but
  // not billed; the organizer decides later whether it plays. Read once here, so
  // a division marked full after this registration does not retro-change its
  // invoice -- what the club was quoted is what they owe.
  let siteContent: any = null
  try {
    const row = await prisma.appSetting.findUnique({ where: { key: `tournamentSite:${tournamentId}` } })
    if (row) siteContent = JSON.parse(row.value || '{}')
  } catch { /* no status set: nothing is waitlisted */ }
  const teamRows = (teams || []).map((x: any) => ({
    ...x,
    waitlisted: isDivisionFull(cleanName(x.division), siteContent),
  }))

  let invoice = Number(invoiceAmount) || 0
  if (!invoice) {
    try {
      const t: any = await prisma.tournament.findUnique({ where: { id: tournamentId } })
      invoice = calcFee(teamRows.map((x: any) => ({ division: x.division || '', waitlisted: !!x.waitlisted })), parsePricing(t?.registrationPricing))
    } catch { /* leave 0 if pricing can't be read */ }
  }

  await ensureRegistrationColumns()
  // Names are string keys elsewhere (pools, games, waivers): trim + collapse
  // whitespace on the way in so "LaxManiax " can't become a second club.
  const club = cleanName(clubName)
  const registration = await prisma.teamRegistration.create({
    data: {
      tournamentId,
      clubName: club,
      clubContact: cleanName(clubContact),
      contactEmail: String(contactEmail || '').trim(),
      contactPhone: String(contactPhone || '').trim(),
      clubBasedIn: cleanName(clubBasedIn),
      clubWebsite: String(clubWebsite || '').trim(),
      numTeams: Number(numTeams) || 1,
      needsHotel: needsHotel === true ? 'Yes' : needsHotel === false ? 'No' : (needsHotel || 'No'),
      paymentMethod: paymentMethod || 'check',
      notes: notes || '',
      invoiceAmount: invoice,
      discountAmount: Number(discountAmount) || 0,
      discountNote: discountNote || '',
      clubLogoUrl: clubLogoUrl || '',
      teams: {
        create: teamRows.map((t: any) => ({
          clubName: cleanName(t.clubName) || club,
          teamName: cleanName(t.teamName),
          division: cleanName(t.division),
          coachName: cleanName(t.coachName),
          coachPhone: String(t.coachPhone || '').trim(),
          coachEmail: String(t.coachEmail || '').trim(),
          logoUrl: t.logoUrl || (clubLogoUrl || ''),
          waitlisted: !!t.waitlisted,
        })),
      },
    },
    include: { teams: true, payments: true },
  })

  // No access by club name any more (lib/clubAccess, Oct 4 2026): a club's past
  // directors used to be handed every new registration of its name here. Now the
  // person registering gets it (setUpPortalLogin below), as do the claim link and
  // anyone a director on it invites.
  //
  // Another live registration at this event under the same name is allowed (a new
  // director, or a different club that shares the name), but the office hears
  // about it. Waivers are filed by club name, so a portal that doesn't hold both
  // shows none under that name until the two are merged or one is renamed.
  let sameNameAs: NonNullable<RegNotifyData['sameNameAs']> = []
  if (!isImport) {
    try {
      const others = await prisma.teamRegistration.findMany({
        where: { tournamentId, deletedAt: null, id: { not: registration.id } },
        select: { clubName: true, clubContact: true, contactEmail: true, teams: { select: { id: true } } },
      })
      sameNameAs = others
        .filter(o => nameKey(o.clubName) === nameKey(club))
        .map(o => ({ contactName: o.clubContact || '', contactEmail: o.contactEmail || '', teams: o.teams.length }))
    } catch { /* the heads-up is a nicety; the registration stands */ }
  }

  // instagramHandle is a raw column (not in the Prisma schema) — write it separately.
  const ig = normalizeInstagram(instagram)
  if (ig) { try { await prisma.$executeRawUnsafe(`UPDATE "TeamRegistration" SET "instagramHandle" = ? WHERE id = ?`, ig, registration.id) } catch {} }
  // Hotel/travel answers (raw columns) -- feed grant room-night projections + the travel report.
  if (hotelName || hotelRooms || hotelNights) {
    try { await prisma.$executeRawUnsafe(`UPDATE "TeamRegistration" SET "hotelName" = ?, "hotelRooms" = ?, "hotelNights" = ? WHERE id = ?`,
      String(hotelName || '').slice(0, 120), Number(hotelRooms) || 0, Number(hotelNights) || 0, registration.id) } catch {}
  }

  // The club's portal login, made with the password on the form (lib/claim
  // setUpPortalLogin), or the session's account when the contact is signed in.
  // Before the letter, so the letter can say the portal is ready instead of
  // sending a set-up link.
  let portal: PortalLogin = { status: 'none', email: '' }
  if (!isImport) {
    const session = await getServerSession(authOptions).catch(() => null)
    portal = await setUpPortalLogin(registration, {
      password: typeof portalPassword === 'string' ? portalPassword : '',
      sessionUser: (session?.user as { id?: string; email?: string | null } | undefined) ?? null,
    })
  }

  // The contact ticked "I agree to the Terms of Use" on the form. Recorded by
  // email, so the portal login made above is not asked again at sign-in.
  if (!isImport && body.termsVersion === TERMS_VERSION && contactEmail) {
    await recordTermsAcceptance({ email: String(contactEmail), context: 'team-registration', ...requestMeta(req) })
  }

  // Public form registrations get a confirmation letter (on-screen + email); imports don't.
  const confirmation = isImport ? null : await buildAndSendConfirmation({ ...registration, instagramHandle: ig }, portal, sameNameAs)

  return NextResponse.json({ ...registration, confirmation, portal }, { status: 201 })
}
